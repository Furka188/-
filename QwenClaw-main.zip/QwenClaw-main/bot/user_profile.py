"""User profile extraction and summary helpers."""

from __future__ import annotations

from db import (
    get_user_device_profile_facts,
    get_user_profile_facts,
    upsert_user_device_profile_fact,
    upsert_user_profile_fact,
)


PROFILE_RULES = [
    ("interest", "minecraft", ["minecraft", "майнкрафт"]),
    ("interest", "roblox", ["roblox"]),
    ("interest", "youtube", ["youtube", "ютуб"]),
    ("interest", "music", ["музыка", "трек", "песня", "playlist", "плейлист"]),
    ("interest", "coding", ["код", "python", "javascript", "скрипт", "бот"]),
    ("style", "brief", ["кратко", "коротко", "без воды"]),
    ("style", "detailed", ["подробно", "детально"]),
    ("style", "step_by_step", ["пошагово", "по шагам", "план"]),
    ("task_preference", "browser_automation", ["браузер", "ютуб", "youtube", "вкладка", "сайт"]),
    ("task_preference", "desktop_automation", ["окно", "рабочий стол", "приложение", "roblox"]),
]


def learn_profile_from_text(owner_id: str, text: str):
    lowered = (text or "").lower()
    for aspect, value, needles in PROFILE_RULES:
        if any(needle in lowered for needle in needles):
            upsert_user_profile_fact(owner_id, aspect, value, score=1.0, source="message")


def learn_device_profile_from_text(owner_id: str, device_id: str, text: str):
    lowered = (text or "").lower()
    for aspect, value, needles in PROFILE_RULES:
        if any(needle in lowered for needle in needles):
            upsert_user_device_profile_fact(owner_id, device_id, aspect, value, score=1.0, source="pc_message")


def get_profile_summary(owner_id: str, limit: int = 6) -> str:
    facts = get_user_profile_facts(owner_id, limit=limit)
    if not facts:
        return ""
    lines = []
    seen: set[tuple[str, str]] = set()
    for item in facts:
        key = (item["aspect"], item["value"])
        if key in seen:
            continue
        seen.add(key)
        lines.append(f"- [{item['aspect']}] {item['value']}")
        if len(lines) >= limit:
            break
    return "\n".join(lines)


def get_device_profile_summary(owner_id: str, device_id: str, limit: int = 4) -> str:
    facts = get_user_device_profile_facts(owner_id, device_id, limit=limit)
    if not facts:
        return ""
    lines = []
    seen: set[tuple[str, str]] = set()
    for item in facts:
        key = (item["aspect"], item["value"])
        if key in seen:
            continue
        seen.add(key)
        lines.append(f"- [{item['aspect']}] {item['value']}")
        if len(lines) >= limit:
            break
    return "\n".join(lines)
