"""Lightweight trace logging for PC tasks."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from config import PROJECT_ROOT
from db import utcnow_iso

TRACE_DIR = PROJECT_ROOT / "workspace" / "pc_traces"


def append_trace(
    command_id: str,
    event: str,
    payload: dict[str, Any] | None = None,
    *,
    owner_id: str = "",
    device_id: str = "",
):
    if not command_id:
        return
    base = TRACE_DIR
    if owner_id:
        base = base / safe_segment(owner_id)
    if device_id:
        base = base / safe_segment(device_id)
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"{safe_segment(command_id)}.jsonl"
    record = {
        "ts": utcnow_iso(),
        "event": event,
        "payload": payload or {},
    }
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def safe_segment(value: str) -> str:
    text = "".join(ch for ch in (value or "").strip() if ch.isalnum() or ch in {"-", "_", "."})
    return text[:120] or "unknown"
