"""Relay server for PC clients."""

from __future__ import annotations

import asyncio
import base64
import logging
from pathlib import Path
from typing import Awaitable, Callable

from aiohttp import web

from config import PC_RELAY_ENABLED, PC_RELAY_HOST, PC_RELAY_PORT, PROJECT_ROOT
from db import (
    claim_next_pc_command,
    delete_pc_device_by_token,
    finish_pc_command,
    get_pc_command,
    get_pc_device_by_pair_token,
    get_pc_device_by_token,
    mark_pc_device_connected,
    touch_pc_device,
)
from pc_trace import append_trace

logger = logging.getLogger("pc_control")

UPLOAD_DIR = PROJECT_ROOT / "workspace" / "pc_uploads"

_on_connected: Callable[[dict], Awaitable[None]] | None = None
_on_result: Callable[[dict, dict], Awaitable[None]] | None = None
_on_progress: Callable[[dict, dict], Awaitable[None]] | None = None
_runner: web.AppRunner | None = None
_site: web.BaseSite | None = None


def set_event_handlers(
    *,
    on_connected: Callable[[dict], Awaitable[None]] | None = None,
    on_result: Callable[[dict, dict], Awaitable[None]] | None = None,
    on_progress: Callable[[dict, dict], Awaitable[None]] | None = None,
):
    global _on_connected, _on_result, _on_progress
    _on_connected = on_connected
    _on_result = on_result
    _on_progress = on_progress


async def start_pc_relay(*, client_version: str):
    global _runner, _site
    if not PC_RELAY_ENABLED or _runner is not None:
        return

    app = web.Application()
    app["client_version"] = client_version
    app.router.add_post("/pc/register", _register_handler)
    app.router.add_get("/pc/poll", _poll_handler)
    app.router.add_post("/pc/result", _result_handler)
    app.router.add_post("/pc/progress", _progress_handler)
    app.router.add_post("/pc/uninstall", _uninstall_handler)
    app.router.add_get("/pc/health", _health_handler)

    _runner = web.AppRunner(app)
    await _runner.setup()
    _site = web.TCPSite(_runner, PC_RELAY_HOST, PC_RELAY_PORT)
    await _site.start()
    logger.info("PC relay listening on %s:%s", PC_RELAY_HOST, PC_RELAY_PORT)


async def stop_pc_relay():
    global _runner, _site
    if _site is not None:
        await _site.stop()
    if _runner is not None:
        await _runner.cleanup()
    _runner = None
    _site = None


async def _health_handler(request: web.Request) -> web.Response:
    return web.json_response({"ok": True, "service": "pc-relay"})


async def _register_handler(request: web.Request) -> web.Response:
    payload = await request.json()
    pair_token = (payload.get("pair_token") or "").strip()
    device_token = (payload.get("device_token") or "").strip()
    device = get_pc_device_by_pair_token(pair_token)
    if not device or device.get("device_token") != device_token:
        return web.json_response({"ok": False, "error": "invalid_token"}, status=403)

    label = (payload.get("device_name") or "").strip() or f"ПК {device['device_id']}"
    hostname = (payload.get("hostname") or "").strip()
    platform_name = (payload.get("platform") or "").strip()
    client_version = (payload.get("client_version") or "").strip() or request.app["client_version"]
    remote_ip = request.headers.get("X-Forwarded-For", request.remote or "")

    updated = mark_pc_device_connected(
        pair_token,
        name=label[:80],
        hostname=hostname[:120],
        platform=platform_name[:120],
        client_version=client_version[:32],
        last_ip=remote_ip[:120],
    )
    if updated and _on_connected:
        asyncio.create_task(_on_connected(updated))
    return web.json_response({"ok": True, "device_id": device["device_id"]})


async def _poll_handler(request: web.Request) -> web.Response:
    device_token = (request.query.get("device_token") or "").strip()
    if not device_token:
        return web.json_response({"ok": False, "error": "missing_token"}, status=400)
    device = touch_pc_device(device_token, last_ip=(request.remote or "")[:120])
    if not device:
        return web.json_response({"ok": False, "error": "unknown_device"}, status=403)

    command = claim_next_pc_command(device_token)
    if not command:
        return web.json_response({"ok": True, "command": None, "retry_after": 4})
    return web.json_response({
        "ok": True,
        "command": {
            "command_id": command["command_id"],
            "kind": command["kind"],
            "prompt": command["prompt"],
            "created_at": command["created_at"],
        },
    })


async def _result_handler(request: web.Request) -> web.Response:
    payload = await request.json()
    device_token = (payload.get("device_token") or "").strip()
    command_id = (payload.get("command_id") or "").strip()
    ok = bool(payload.get("ok"))
    result_text = (payload.get("result_text") or "").strip()
    error_text = (payload.get("error_text") or "").strip()
    attachment_path = ""
    attachment_kind = ""
    attachment = payload.get("attachment") or {}
    if isinstance(attachment, dict):
        attachment_path, attachment_kind = _store_uploaded_attachment(attachment, command_id)

    command = finish_pc_command(
        device_token,
        command_id,
        ok=ok,
        result_text=result_text,
        error_text=error_text,
        attachment_path=attachment_path,
        attachment_kind=attachment_kind,
    )
    device = get_pc_device_by_token(device_token)
    if not command or not device:
        return web.json_response({"ok": False, "error": "unknown_command"}, status=404)
    if _on_result:
        asyncio.create_task(_on_result(device, command))
    append_trace(
        command_id,
        "result",
        {"ok": ok, "attachment_kind": attachment_kind, "result_text": result_text[:1000], "error_text": error_text[:500]},
        owner_id=command.get("owner_id", ""),
        device_id=device.get("device_id", ""),
    )
    return web.json_response({"ok": True})


async def _progress_handler(request: web.Request) -> web.Response:
    payload = await request.json()
    device_token = (payload.get("device_token") or "").strip()
    command_id = (payload.get("command_id") or "").strip()
    stage = (payload.get("stage") or "").strip()[:80]
    message = (payload.get("message") or "").strip()[:400]
    device = get_pc_device_by_token(device_token)
    command = get_pc_command(command_id) if command_id else None
    if not device or not command:
        return web.json_response({"ok": False, "error": "unknown_command"}, status=404)
    if _on_progress:
        asyncio.create_task(_on_progress(device, {"command_id": command_id, "stage": stage, "message": message}))
    append_trace(
        command_id,
        "progress",
        {"stage": stage, "message": message, "device_id": device.get("device_id")},
        owner_id=command.get("owner_id", ""),
        device_id=device.get("device_id", ""),
    )
    return web.json_response({"ok": True})


async def _uninstall_handler(request: web.Request) -> web.Response:
    payload = await request.json()
    device_token = (payload.get("device_token") or "").strip()
    pair_token = (payload.get("pair_token") or "").strip()

    device = None
    if device_token:
        device = delete_pc_device_by_token(device_token)
    elif pair_token:
        existing = get_pc_device_by_pair_token(pair_token)
        if existing:
            device = delete_pc_device_by_token(existing["device_token"])

    return web.json_response({"ok": True, "deleted": bool(device)})


def _store_uploaded_attachment(attachment: dict, command_id: str) -> tuple[str, str]:
    content_b64 = (attachment.get("content_b64") or "").strip()
    if not content_b64:
        return "", ""

    filename = Path((attachment.get("filename") or f"{command_id}.bin").strip()).name
    kind = (attachment.get("kind") or "").strip().lower()
    try:
        data = base64.b64decode(content_b64, validate=True)
    except Exception:
        logger.warning("Invalid attachment base64 for command %s", command_id)
        return "", ""

    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    target = UPLOAD_DIR / f"{command_id}_{filename}"
    target.write_bytes(data)
    return str(target), kind[:40]
