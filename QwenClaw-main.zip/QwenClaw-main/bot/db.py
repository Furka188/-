"""SQLite storage for users, sessions, history and quota."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from typing import Optional

from config import DB_PATH, SESSION_IDLE_TIMEOUT_HOURS

SCHEMA_VERSION = 10
DEFAULT_OWNER = "default"


def utcnow_iso() -> str:
    return datetime.utcnow().isoformat()


def get_db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    conn = get_db()
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version < SCHEMA_VERSION:
        _migrate(conn, version)
    conn.close()


def _column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r[1] == column for r in rows)


def _migrate(conn: sqlite3.Connection, from_version: int):
    if from_version < 1:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                summary TEXT DEFAULT '',
                status TEXT DEFAULT 'idle',
                created_at TEXT NOT NULL,
                last_message_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                text TEXT NOT NULL,
                session_id TEXT,
                created_at TEXT NOT NULL
            );

            PRAGMA user_version = 1;
            """
        )
        from_version = 1

    if from_version < 2:
        if not _column_exists(conn, "sessions", "favorite"):
            conn.execute("ALTER TABLE sessions ADD COLUMN favorite INTEGER DEFAULT 0")
        conn.execute("PRAGMA user_version = 2")
        from_version = 2

    if from_version < 3:
        if not _column_exists(conn, "sessions", "owner_id"):
            conn.execute(f"ALTER TABLE sessions ADD COLUMN owner_id TEXT DEFAULT '{DEFAULT_OWNER}'")
        if not _column_exists(conn, "history", "owner_id"):
            conn.execute(f"ALTER TABLE history ADD COLUMN owner_id TEXT DEFAULT '{DEFAULT_OWNER}'")
        conn.execute("PRAGMA user_version = 3")
        from_version = 3

    if from_version < 4:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS auth_bindings (
                chat_id INTEGER PRIMARY KEY,
                owner_id TEXT NOT NULL,
                authorized_at TEXT NOT NULL
            )
            """
        )
        conn.execute("PRAGMA user_version = 4")
        from_version = 4

    if from_version < 5:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS quota_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_owner_last ON sessions(owner_id, last_message_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_history_owner_created ON history(owner_id, created_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_quota_owner_created ON quota_events(owner_id, created_at DESC)")
        conn.execute("PRAGMA user_version = 5")
        from_version = 5

    if from_version < 6:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS pc_devices (
                device_id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL,
                chat_id INTEGER NOT NULL,
                pair_token TEXT NOT NULL UNIQUE,
                device_token TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                hostname TEXT DEFAULT '',
                platform TEXT DEFAULT '',
                client_version TEXT DEFAULT '',
                relay_base_url TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                confirmed_at TEXT,
                last_seen_at TEXT,
                last_ip TEXT DEFAULT ''
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS pc_commands (
                command_id TEXT PRIMARY KEY,
                device_id TEXT NOT NULL,
                owner_id TEXT NOT NULL,
                kind TEXT NOT NULL DEFAULT 'chat',
                prompt TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'queued',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                result_text TEXT DEFAULT '',
                error_text TEXT DEFAULT '',
                FOREIGN KEY(device_id) REFERENCES pc_devices(device_id)
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pc_devices_owner_created ON pc_devices(owner_id, created_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pc_commands_device_status_created ON pc_commands(device_id, status, created_at ASC)")
        conn.execute("PRAGMA user_version = 6")
        from_version = 6

    if from_version < 7:
        if not _column_exists(conn, "pc_commands", "attachment_path"):
            conn.execute("ALTER TABLE pc_commands ADD COLUMN attachment_path TEXT DEFAULT ''")
        if not _column_exists(conn, "pc_commands", "attachment_kind"):
            conn.execute("ALTER TABLE pc_commands ADD COLUMN attachment_kind TEXT DEFAULT ''")
        conn.execute("PRAGMA user_version = 7")
        from_version = 7

    if from_version < 8:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_preferences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id TEXT NOT NULL,
                category TEXT NOT NULL,
                value TEXT NOT NULL,
                weight REAL NOT NULL DEFAULT 1,
                source TEXT DEFAULT '',
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_user_preferences_owner_category ON user_preferences(owner_id, category, updated_at DESC)")
        conn.execute("PRAGMA user_version = 8")
        from_version = 8

    if from_version < 9:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id TEXT NOT NULL,
                aspect TEXT NOT NULL,
                value TEXT NOT NULL,
                score REAL NOT NULL DEFAULT 1,
                source TEXT DEFAULT '',
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_user_profiles_owner_aspect ON user_profiles(owner_id, aspect, updated_at DESC)")
        conn.execute("PRAGMA user_version = 9")
        from_version = 9

    if from_version < 10:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_device_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                aspect TEXT NOT NULL,
                value TEXT NOT NULL,
                score REAL NOT NULL DEFAULT 1,
                source TEXT DEFAULT '',
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_user_device_profiles_owner_device_aspect "
            "ON user_device_profiles(owner_id, device_id, aspect, updated_at DESC)"
        )
        conn.execute("PRAGMA user_version = 10")

    conn.commit()


# --- Auth bindings ---

def bind_chat_user(chat_id: int, owner_id: str):
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO auth_bindings (chat_id, owner_id, authorized_at) VALUES (?, ?, ?)",
        (chat_id, owner_id, utcnow_iso()),
    )
    conn.commit()
    conn.close()


def get_bound_user(chat_id: int) -> Optional[str]:
    conn = get_db()
    row = conn.execute("SELECT owner_id FROM auth_bindings WHERE chat_id = ?", (chat_id,)).fetchone()
    conn.close()
    return row[0] if row else None


def unbind_chat_user(chat_id: int):
    conn = get_db()
    conn.execute("DELETE FROM auth_bindings WHERE chat_id = ?", (chat_id,))
    conn.commit()
    conn.close()


# --- Session CRUD ---

def create_session(owner_id: str, session_id: str, name: str) -> dict:
    conn = get_db()
    now = utcnow_iso()
    conn.execute(
        "INSERT OR IGNORE INTO sessions (session_id, owner_id, name, status, created_at, last_message_at) "
        "VALUES (?, ?, ?, 'idle', ?, ?)",
        (session_id, owner_id, name, now, now),
    )
    conn.commit()
    conn.close()
    return {"session_id": session_id, "owner_id": owner_id, "name": name, "status": "idle"}


def get_session(owner_id: str, session_id: str) -> Optional[dict]:
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM sessions WHERE session_id = ? AND owner_id = ?",
        (session_id, owner_id),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def update_session(owner_id: str, session_id: str, **kwargs):
    if not kwargs:
        return
    conn = get_db()
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    vals = list(kwargs.values()) + [session_id, owner_id]
    conn.execute(f"UPDATE sessions SET {sets} WHERE session_id = ? AND owner_id = ?", vals)
    conn.commit()
    conn.close()


def get_active_sessions(owner_id: str) -> list[dict]:
    conn = get_db()
    cutoff = (datetime.utcnow() - timedelta(hours=SESSION_IDLE_TIMEOUT_HOURS)).isoformat()
    rows = conn.execute(
        "SELECT * FROM sessions WHERE owner_id = ? AND status != 'done' AND last_message_at > ? "
        "ORDER BY favorite DESC, last_message_at DESC",
        (owner_id, cutoff),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_favorite_sessions(owner_id: str) -> list[dict]:
    conn = get_db()
    cutoff = (datetime.utcnow() - timedelta(hours=SESSION_IDLE_TIMEOUT_HOURS)).isoformat()
    rows = conn.execute(
        "SELECT * FROM sessions WHERE owner_id = ? AND status != 'done' AND favorite = 1 AND last_message_at > ? "
        "ORDER BY last_message_at DESC",
        (owner_id, cutoff),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def toggle_session_favorite(owner_id: str, session_id: str) -> Optional[dict]:
    session = get_session(owner_id, session_id)
    if not session:
        return None
    favorite = 0 if session.get("favorite") else 1
    update_session(owner_id, session_id, favorite=favorite)
    return get_session(owner_id, session_id)


def set_session_active(owner_id: str, session_id: str):
    update_session(owner_id, session_id, status="active", last_message_at=utcnow_iso())


def set_session_idle(owner_id: str, session_id: str, summary: str = ""):
    kwargs = {"status": "idle", "last_message_at": utcnow_iso()}
    if summary:
        kwargs["summary"] = summary[:200]
    update_session(owner_id, session_id, **kwargs)


def set_session_done(owner_id: str, session_id: str):
    update_session(owner_id, session_id, status="done")


def search_history(owner_id: str, query: str, limit: int = 8) -> list[dict]:
    term = f"%{query.strip()}%"
    conn = get_db()
    rows = conn.execute(
        """
        SELECT h.session_id, s.name, h.role, h.text, h.created_at
        FROM history h
        LEFT JOIN sessions s ON s.session_id = h.session_id AND s.owner_id = h.owner_id
        WHERE h.owner_id = ? AND h.text LIKE ?
        ORDER BY h.created_at DESC
        LIMIT ?
        """,
        (owner_id, term, limit),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_recent_history(owner_id: str, role: str | None = None, limit: int = 12) -> list[dict]:
    conn = get_db()
    if role:
        rows = conn.execute(
            """
            SELECT session_id, role, text, created_at
            FROM history
            WHERE owner_id = ? AND role = ?
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (owner_id, role, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT session_id, role, text, created_at
            FROM history
            WHERE owner_id = ?
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (owner_id, limit),
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def upsert_user_preference(owner_id: str, category: str, value: str, *, weight: float = 1.0, source: str = ""):
    normalized_category = (category or "").strip()[:40]
    normalized_value = " ".join((value or "").split()).strip()[:200]
    if not normalized_category or not normalized_value:
        return
    conn = get_db()
    existing = conn.execute(
        """
        SELECT id, weight FROM user_preferences
        WHERE owner_id = ? AND category = ? AND value = ?
        ORDER BY updated_at DESC
        LIMIT 1
        """,
        (owner_id, normalized_category, normalized_value),
    ).fetchone()
    now = utcnow_iso()
    if existing:
        conn.execute(
            "UPDATE user_preferences SET weight = ?, source = ?, updated_at = ? WHERE id = ?",
            (max(float(existing["weight"]), weight), source[:120], now, existing["id"]),
        )
    else:
        conn.execute(
            """
            INSERT INTO user_preferences (owner_id, category, value, weight, source, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (owner_id, normalized_category, normalized_value, weight, source[:120], now),
        )
    conn.commit()
    conn.close()


def get_user_preferences(owner_id: str, *, category: str | None = None, limit: int = 10) -> list[dict]:
    conn = get_db()
    if category:
        rows = conn.execute(
            """
            SELECT owner_id, category, value, weight, source, updated_at
            FROM user_preferences
            WHERE owner_id = ? AND category = ?
            ORDER BY weight DESC, updated_at DESC
            LIMIT ?
            """,
            (owner_id, category, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT owner_id, category, value, weight, source, updated_at
            FROM user_preferences
            WHERE owner_id = ?
            ORDER BY weight DESC, updated_at DESC
            LIMIT ?
            """,
            (owner_id, limit),
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def upsert_user_profile_fact(owner_id: str, aspect: str, value: str, *, score: float = 1.0, source: str = ""):
    normalized_aspect = (aspect or "").strip()[:40]
    normalized_value = " ".join((value or "").split()).strip()[:200]
    if not normalized_aspect or not normalized_value:
        return
    conn = get_db()
    existing = conn.execute(
        """
        SELECT id, score FROM user_profiles
        WHERE owner_id = ? AND aspect = ? AND value = ?
        ORDER BY updated_at DESC
        LIMIT 1
        """,
        (owner_id, normalized_aspect, normalized_value),
    ).fetchone()
    now = utcnow_iso()
    if existing:
        conn.execute(
            "UPDATE user_profiles SET score = ?, source = ?, updated_at = ? WHERE id = ?",
            (max(float(existing["score"]), score), source[:120], now, existing["id"]),
        )
    else:
        conn.execute(
            """
            INSERT INTO user_profiles (owner_id, aspect, value, score, source, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (owner_id, normalized_aspect, normalized_value, score, source[:120], now),
        )
    conn.commit()
    conn.close()


def get_user_profile_facts(owner_id: str, *, aspect: str | None = None, limit: int = 10) -> list[dict]:
    conn = get_db()
    if aspect:
        rows = conn.execute(
            """
            SELECT owner_id, aspect, value, score, source, updated_at
            FROM user_profiles
            WHERE owner_id = ? AND aspect = ?
            ORDER BY score DESC, updated_at DESC
            LIMIT ?
            """,
            (owner_id, aspect, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT owner_id, aspect, value, score, source, updated_at
            FROM user_profiles
            WHERE owner_id = ?
            ORDER BY score DESC, updated_at DESC
            LIMIT ?
            """,
            (owner_id, limit),
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def upsert_user_device_profile_fact(
    owner_id: str,
    device_id: str,
    aspect: str,
    value: str,
    *,
    score: float = 1.0,
    source: str = "",
):
    normalized_device = (device_id or "").strip()[:80]
    normalized_aspect = (aspect or "").strip()[:40]
    normalized_value = " ".join((value or "").split()).strip()[:200]
    if not normalized_device or not normalized_aspect or not normalized_value:
        return
    conn = get_db()
    existing = conn.execute(
        """
        SELECT id, score FROM user_device_profiles
        WHERE owner_id = ? AND device_id = ? AND aspect = ? AND value = ?
        ORDER BY updated_at DESC
        LIMIT 1
        """,
        (owner_id, normalized_device, normalized_aspect, normalized_value),
    ).fetchone()
    now = utcnow_iso()
    if existing:
        conn.execute(
            "UPDATE user_device_profiles SET score = ?, source = ?, updated_at = ? WHERE id = ?",
            (max(float(existing["score"]), score), source[:120], now, existing["id"]),
        )
    else:
        conn.execute(
            """
            INSERT INTO user_device_profiles (owner_id, device_id, aspect, value, score, source, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (owner_id, normalized_device, normalized_aspect, normalized_value, score, source[:120], now),
        )
    conn.commit()
    conn.close()


def get_user_device_profile_facts(
    owner_id: str,
    device_id: str,
    *,
    aspect: str | None = None,
    limit: int = 10,
) -> list[dict]:
    conn = get_db()
    normalized_device = (device_id or "").strip()[:80]
    if aspect:
        rows = conn.execute(
            """
            SELECT owner_id, device_id, aspect, value, score, source, updated_at
            FROM user_device_profiles
            WHERE owner_id = ? AND device_id = ? AND aspect = ?
            ORDER BY score DESC, updated_at DESC
            LIMIT ?
            """,
            (owner_id, normalized_device, aspect, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT owner_id, device_id, aspect, value, score, source, updated_at
            FROM user_device_profiles
            WHERE owner_id = ? AND device_id = ?
            ORDER BY score DESC, updated_at DESC
            LIMIT ?
            """,
            (owner_id, normalized_device, limit),
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# --- History ---

def save_message(owner_id: str, role: str, text: str, session_id: str | None = None):
    conn = get_db()
    conn.execute(
        "INSERT INTO history (owner_id, role, text, session_id, created_at) VALUES (?, ?, ?, ?, ?)",
        (owner_id, role, text[:5000], session_id, utcnow_iso()),
    )
    conn.commit()
    conn.close()


# --- Quota ---

def prune_quota_events(owner_id: str, window_hours: int):
    cutoff = (datetime.utcnow() - timedelta(hours=window_hours)).isoformat()
    conn = get_db()
    conn.execute("DELETE FROM quota_events WHERE owner_id = ? AND created_at < ?", (owner_id, cutoff))
    conn.commit()
    conn.close()


def record_request(owner_id: str):
    conn = get_db()
    conn.execute("INSERT INTO quota_events (owner_id, created_at) VALUES (?, ?)", (owner_id, utcnow_iso()))
    conn.commit()
    conn.close()


def get_quota_usage(owner_id: str, window_hours: int) -> int:
    cutoff = (datetime.utcnow() - timedelta(hours=window_hours)).isoformat()
    conn = get_db()
    row = conn.execute(
        "SELECT COUNT(*) FROM quota_events WHERE owner_id = ? AND created_at >= ?",
        (owner_id, cutoff),
    ).fetchone()
    conn.close()
    return int(row[0] if row else 0)


def quota_remaining(owner_id: str, max_requests: int, window_hours: int) -> tuple[int, int]:
    prune_quota_events(owner_id, window_hours)
    used = get_quota_usage(owner_id, window_hours)
    return max(0, max_requests - used), used


# --- PC devices ---

def create_pc_device(
    owner_id: str,
    chat_id: int,
    device_id: str,
    pair_token: str,
    device_token: str,
    name: str,
    relay_base_url: str,
) -> dict:
    now = utcnow_iso()
    conn = get_db()
    conn.execute(
        """
        INSERT INTO pc_devices (
            device_id, owner_id, chat_id, pair_token, device_token, name, status,
            relay_base_url, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)
        """,
        (device_id, owner_id, chat_id, pair_token, device_token, name, relay_base_url, now),
    )
    conn.commit()
    conn.close()
    return get_pc_device(owner_id, device_id) or {}


def get_pc_devices(owner_id: str) -> list[dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM pc_devices WHERE owner_id = ? ORDER BY created_at DESC",
        (owner_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_pc_device(owner_id: str, device_id: str) -> Optional[dict]:
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM pc_devices WHERE owner_id = ? AND device_id = ?",
        (owner_id, device_id),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_pc_device_by_pair_token(pair_token: str) -> Optional[dict]:
    conn = get_db()
    row = conn.execute("SELECT * FROM pc_devices WHERE pair_token = ?", (pair_token,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_pc_device_by_token(device_token: str) -> Optional[dict]:
    conn = get_db()
    row = conn.execute("SELECT * FROM pc_devices WHERE device_token = ?", (device_token,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_pc_device(owner_id: str, device_id: str, **kwargs):
    if not kwargs:
        return
    conn = get_db()
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    vals = list(kwargs.values()) + [owner_id, device_id]
    conn.execute(f"UPDATE pc_devices SET {sets} WHERE owner_id = ? AND device_id = ?", vals)
    conn.commit()
    conn.close()


def update_pc_device_by_token(device_token: str, **kwargs):
    if not kwargs:
        return
    conn = get_db()
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    vals = list(kwargs.values()) + [device_token]
    conn.execute(f"UPDATE pc_devices SET {sets} WHERE device_token = ?", vals)
    conn.commit()
    conn.close()


def mark_pc_device_connected(
    pair_token: str,
    *,
    name: str,
    hostname: str,
    platform: str,
    client_version: str,
    last_ip: str,
) -> Optional[dict]:
    device = get_pc_device_by_pair_token(pair_token)
    if not device:
        return None
    conn = get_db()
    now = utcnow_iso()
    conn.execute(
        """
        UPDATE pc_devices
        SET status = 'connected',
            name = ?,
            hostname = ?,
            platform = ?,
            client_version = ?,
            confirmed_at = COALESCE(confirmed_at, ?),
            last_seen_at = ?,
            last_ip = ?
        WHERE pair_token = ?
        """,
        (name, hostname, platform, client_version, now, now, last_ip, pair_token),
    )
    conn.commit()
    conn.close()
    return get_pc_device_by_pair_token(pair_token)


def touch_pc_device(device_token: str, *, status: str = "connected", last_ip: str = "") -> Optional[dict]:
    device = get_pc_device_by_token(device_token)
    if not device:
        return None
    kwargs = {"status": status, "last_seen_at": utcnow_iso()}
    if last_ip:
        kwargs["last_ip"] = last_ip
    update_pc_device_by_token(device_token, **kwargs)
    return get_pc_device_by_token(device_token)


def delete_pc_device(owner_id: str, device_id: str) -> Optional[dict]:
    device = get_pc_device(owner_id, device_id)
    if not device:
        return None
    conn = get_db()
    conn.execute("DELETE FROM pc_commands WHERE device_id = ?", (device_id,))
    conn.execute("DELETE FROM pc_devices WHERE owner_id = ? AND device_id = ?", (owner_id, device_id))
    conn.commit()
    conn.close()
    return device


def delete_pc_device_by_token(device_token: str) -> Optional[dict]:
    device = get_pc_device_by_token(device_token)
    if not device:
        return None
    conn = get_db()
    conn.execute("DELETE FROM pc_commands WHERE device_id = ?", (device["device_id"],))
    conn.execute("DELETE FROM pc_devices WHERE device_token = ?", (device_token,))
    conn.commit()
    conn.close()
    return device


# --- PC commands ---

def create_pc_command(owner_id: str, device_id: str, command_id: str, prompt: str, kind: str = "chat") -> dict:
    now = utcnow_iso()
    conn = get_db()
    conn.execute(
        """
        INSERT INTO pc_commands (command_id, device_id, owner_id, kind, prompt, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'queued', ?, ?)
        """,
        (command_id, device_id, owner_id, kind, prompt[:12000], now, now),
    )
    conn.commit()
    conn.close()
    return get_pc_command(command_id) or {}


def get_pc_command(command_id: str) -> Optional[dict]:
    conn = get_db()
    row = conn.execute("SELECT * FROM pc_commands WHERE command_id = ?", (command_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def claim_next_pc_command(device_token: str) -> Optional[dict]:
    device = get_pc_device_by_token(device_token)
    if not device:
        return None
    conn = get_db()
    row = conn.execute(
        """
        SELECT * FROM pc_commands
        WHERE device_id = ? AND status = 'queued'
        ORDER BY created_at ASC
        LIMIT 1
        """,
        (device["device_id"],),
    ).fetchone()
    if not row:
        conn.close()
        return None
    now = utcnow_iso()
    conn.execute(
        "UPDATE pc_commands SET status = 'running', updated_at = ? WHERE command_id = ?",
        (now, row["command_id"]),
    )
    conn.commit()
    conn.close()
    touch_pc_device(device_token)
    return get_pc_command(row["command_id"])


def finish_pc_command(
    device_token: str,
    command_id: str,
    *,
    ok: bool,
    result_text: str = "",
    error_text: str = "",
    attachment_path: str = "",
    attachment_kind: str = "",
) -> Optional[dict]:
    device = get_pc_device_by_token(device_token)
    if not device:
        return None
    status = "done" if ok else "failed"
    conn = get_db()
    conn.execute(
        """
        UPDATE pc_commands
        SET status = ?, updated_at = ?, result_text = ?, error_text = ?, attachment_path = ?, attachment_kind = ?
        WHERE command_id = ? AND device_id = ?
        """,
        (
            status,
            utcnow_iso(),
            result_text[:20000],
            error_text[:8000],
            attachment_path[:500],
            attachment_kind[:40],
            command_id,
            device["device_id"],
        ),
    )
    conn.commit()
    conn.close()
    touch_pc_device(device_token)
    return get_pc_command(command_id)
