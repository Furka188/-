"""Execution contracts and supervisor heuristics for PC missions."""

from __future__ import annotations

from dataclasses import dataclass

from pc_task_router import route_pc_task


@dataclass(frozen=True)
class PcMissionContract:
    task_type: str
    summary: str
    success_checks: tuple[str, ...]
    preferred_tools: tuple[str, ...]
    requires_visual_context: bool


def build_pc_mission_contract(prompt: str) -> PcMissionContract:
    routed = route_pc_task(prompt)
    text = (prompt or "").lower()

    if routed.task_type == "browser":
        checks = ["нужный сайт или страница открыты", "активное окно похоже на браузер", "URL или экран подтверждают результат"]
        tools = ["ensure-browser", "focus-address", "navigate-url", "youtube-search", "inspect"]
        summary = "Browser mission: работай через браузерный слой и подтверждай результат URL или экраном."
        if "youtube" in text or "ютуб" in text:
            checks = ["YouTube открыт", "поиск или видео действительно открыты", "экран подтверждает нужный контент"]
        return PcMissionContract(routed.task_type, summary, tuple(checks), tuple(tools), True)

    if routed.task_type == "desktop":
        return PcMissionContract(
            task_type="desktop",
            summary="Desktop mission: сначала приведи окна в нужное состояние, потом выполняй целевое действие.",
            success_checks=(
                "активное окно соответствует цели",
                "мешающее окно скрыто, свернуто или переключено",
                "экран подтверждает изменение состояния",
            ),
            preferred_tools=("desktop", "switch-window", "minimize-window", "open-search", "inspect"),
            requires_visual_context=True,
        )

    if routed.task_type == "shell":
        return PcMissionContract(
            task_type="shell",
            summary="Shell mission: предпочитай команды и проверяй stdout, stderr и код возврата.",
            success_checks=("команда завершилась ожидаемо", "stdout/stderr подтверждают результат"),
            preferred_tools=("shell",),
            requires_visual_context=False,
        )

    if routed.task_type == "inspect":
        return PcMissionContract(
            task_type="inspect",
            summary="Inspect mission: собери и верни структурированное состояние экрана.",
            success_checks=("активное окно определено", "видимый текст и препятствия собраны"),
            preferred_tools=("inspect", "ocr", "screenshot"),
            requires_visual_context=True,
        )

    return PcMissionContract(
        task_type="general",
        summary="General mission: выбери самый надёжный путь между desktop, browser и shell и подтверждай ключевые шаги.",
        success_checks=(
            "выбран устойчивый способ выполнения",
            "после важного шага есть проверка",
            "итог подтверждён экраном, URL или выводом команд",
        ),
        preferred_tools=("inspect", "desktop", "ensure-browser", "shell"),
        requires_visual_context=True,
    )


def format_pc_mission_contract(prompt: str) -> str:
    contract = build_pc_mission_contract(prompt)
    checks = "; ".join(contract.success_checks)
    tools = ", ".join(contract.preferred_tools)
    visual = "yes" if contract.requires_visual_context else "no"
    return (
        f"Supervisor: {contract.summary}\n"
        f"Success checks: {checks}\n"
        f"Preferred tools: {tools}\n"
        f"Needs visual context: {visual}"
    )
