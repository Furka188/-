"""Local assistant actions for Android/Termux device control."""

import asyncio
import json
from html import escape
from typing import Any


class AssistantActionError(RuntimeError):
    """Raised when a device action cannot be completed."""


async def phone_status() -> str:
    battery = await battery_status()
    wifi = await wifi_info()
    volume = await volume_info()

    lines = ["<b>Телефон</b>", ""]
    lines.append(f"Батарея: {battery.get('percentage', '?')}%")
    lines.append(f"Зарядка: {'да' if battery.get('plugged') != 'UNPLUGGED' else 'нет'}")

    ssid = wifi.get("ssid")
    if ssid:
        lines.append(f"Wi-Fi: {ssid}")
    else:
        lines.append("Wi-Fi: нет данных")

    music = next((item for item in volume if item.get("stream") == "music"), None)
    if music:
        lines.append(f"Громкость media: {music.get('volume')}/{music.get('max_volume')}")

    return "\n".join(lines)


async def battery_status() -> dict[str, Any]:
    return await _run_json("termux-battery-status")


async def wifi_info() -> dict[str, Any]:
    return await _run_json("termux-wifi-connectioninfo")


async def device_info() -> dict[str, Any]:
    return await _run_json("termux-telephony-deviceinfo")


async def location_info() -> dict[str, Any]:
    return await _run_json("termux-location", timeout=12)


async def volume_info() -> list[dict[str, Any]]:
    return await _run_json("termux-volume")


async def clipboard_get() -> str:
    result = await _run_text("termux-clipboard-get")
    return result or "[буфер пуст]"


async def clipboard_set(text: str) -> str:
    if not text.strip():
        raise AssistantActionError("Нужен текст для буфера обмена.")
    await _run_text("termux-clipboard-set", text)
    return "Текст сохранён в буфер обмена."


async def speak_text(text: str) -> str:
    if not text.strip():
        raise AssistantActionError("Нужен текст для озвучивания.")
    await _run_text("termux-tts-speak", text)
    return "Текст озвучен."


async def torch_set(enabled: bool) -> str:
    await _run_text("termux-torch", "on" if enabled else "off")
    return f"Фонарик {'включён' if enabled else 'выключен'}."


async def wifi_set(enabled: bool) -> str:
    await _run_text("termux-wifi-enable", "true" if enabled else "false")
    return f"Wi-Fi {'включён' if enabled else 'выключен'}."


async def set_brightness(value: str) -> str:
    normalized = value.strip().lower()
    if normalized != "auto":
        try:
            brightness = int(normalized)
        except ValueError as exc:
            raise AssistantActionError("Яркость должна быть числом 0-255 или auto.") from exc
        if brightness < 0 or brightness > 255:
            raise AssistantActionError("Яркость должна быть в диапазоне 0-255.")
        normalized = str(brightness)

    await _run_text("termux-brightness", normalized)
    return f"Яркость установлена: {normalized}."


async def set_volume(stream: str, value: str) -> str:
    stream_name = stream.strip().lower()
    streams = {item.get("stream"): item for item in await volume_info()}
    if stream_name not in streams:
        available = ", ".join(sorted(streams))
        raise AssistantActionError(f"Неизвестный поток. Доступно: {available}")

    try:
        volume = int(value)
    except ValueError as exc:
        raise AssistantActionError("Громкость должна быть целым числом.") from exc

    max_volume = int(streams[stream_name].get("max_volume", 0))
    if volume < 0 or volume > max_volume:
        raise AssistantActionError(f"Для {stream_name} допустимо 0-{max_volume}.")

    await _run_text("termux-volume", stream_name, str(volume))
    return f"Громкость {stream_name}: {volume}/{max_volume}."


async def open_url(url: str) -> str:
    normalized = url.strip()
    if not normalized.startswith(("http://", "https://")):
        normalized = f"https://{normalized}"
    await _run_text("termux-open-url", normalized)
    return f"Открыл: {normalized}"


def format_json_block(title: str, data: Any) -> str:
    body = escape(json.dumps(data, ensure_ascii=False, indent=2))
    return f"<b>{escape(title)}</b>\n<pre>{body}</pre>"


async def _run_json(*args: str, timeout: int = 8) -> Any:
    output = await _run_text(*args, timeout=timeout)
    try:
        return json.loads(output)
    except json.JSONDecodeError as exc:
        raise AssistantActionError(f"Не удалось разобрать ответ {args[0]}.") from exc


async def _run_text(*args: str, timeout: int = 8) -> str:
    try:
        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:
        raise AssistantActionError(f"Команда не найдена: {args[0]}") from exc

    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError as exc:
        proc.kill()
        raise AssistantActionError(f"Команда зависла: {args[0]}") from exc

    if proc.returncode != 0:
        error_text = stderr.decode("utf-8", errors="replace").strip() or "unknown error"
        raise AssistantActionError(error_text)

    return stdout.decode("utf-8", errors="replace").strip()
