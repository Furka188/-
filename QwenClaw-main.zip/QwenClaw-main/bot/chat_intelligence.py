"""Lightweight intent analysis for normal and PC chat flows."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ChatAnalysis:
    intent: str
    suggested_mode: str
    style_hint: str
    clarification_request: str
    confidence: str


def analyze_chat_request(text: str, *, has_attachments: bool = False) -> ChatAnalysis:
    normalized = " ".join((text or "").split()).strip()
    lowered = normalized.lower()
    words = [word for word in lowered.replace(",", " ").replace(".", " ").split() if word]

    if has_attachments:
        return ChatAnalysis(
            intent="attachment",
            suggested_mode="deep",
            style_hint="Учитывай вложения как главный источник контекста и опирайся на факты из них.",
            clarification_request="",
            confidence="high",
        )

    if any(token in lowered for token in {"python", "javascript", "код", "скрипт", "ошибка", "bug", "traceback", "stack"}):
        return ChatAnalysis(
            intent="code",
            suggested_mode="code",
            style_hint="Дай технический ответ с командами, конфигами и конкретными шагами.",
            clarification_request="",
            confidence="high",
        )

    if any(token in lowered for token in {"план", "пошагово", "шаги", "roadmap", "strategy"}):
        return ChatAnalysis(
            intent="plan",
            suggested_mode="plan",
            style_hint="Сначала дай короткий план, затем детали только по необходимости.",
            clarification_request="",
            confidence="high",
        )

    if any(token in lowered for token in {"объясни", "что это", "почему", "как работает", "суть"}):
        return ChatAnalysis(
            intent="explain",
            suggested_mode="deep",
            style_hint="Объясняй простыми словами, но без потери сути.",
            clarification_request="",
            confidence="medium",
        )

    vague_markers = {
        "что-нибудь", "что нибудь", "что-то", "что то", "нормально", "как-нибудь", "как нибудь",
        "сам реши", "что лучше", "что выбрать", "что посоветуешь",
    }
    broad_verbs = {"сделай", "напиши", "подбери", "найди", "придумай", "создай", "помоги"}
    specific_markers = {"код", "план", "сравни", "объясни", "таблица", "список", "настрой", "почини", "ютуб", "roblox", "брауз"}
    vague = any(marker in lowered for marker in vague_markers)
    if len(words) <= 3 and any(word in broad_verbs for word in words):
        vague = True
    if vague and not any(token in lowered for token in specific_markers):
        return ChatAnalysis(
            intent="ambiguous",
            suggested_mode="normal",
            style_hint="Сначала уточни задачу, потом отвечай.",
            clarification_request=(
                "Уточни запрос: какой именно результат тебе нужен, в каком формате и для какой цели. "
                "Тогда отвечу точнее и без лишних догадок."
            ),
            confidence="medium",
        )

    if len(normalized) < 90:
        return ChatAnalysis(
            intent="quick",
            suggested_mode="brief",
            style_hint="Отвечай коротко и по делу.",
            clarification_request="",
            confidence="medium",
        )

    return ChatAnalysis(
        intent="general",
        suggested_mode="normal",
        style_hint="Дай практичный ответ с фокусом на полезный итог.",
        clarification_request="",
        confidence="medium",
    )
