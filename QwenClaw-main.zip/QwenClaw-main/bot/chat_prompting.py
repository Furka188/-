"""Prompting helpers for the main Telegram chat."""

from __future__ import annotations

import re

from chat_intelligence import analyze_chat_request
from db import get_recent_history, get_user_preferences, upsert_user_preference
from user_profile import get_profile_summary, learn_profile_from_text

REPLY_MODES = {
    "normal": "",
    "brief": "Ответь коротко, по делу, без лишней воды.",
    "deep": "Ответь подробно, структурно и с важными деталями.",
    "plan": "Сначала дай чёткий пошаговый план, затем при необходимости детали.",
    "code": "Сфокусируйся на коде, командах, конфигурации и технических шагах.",
}

QUICK_TEMPLATES = {
    "brief": "Ответь максимально коротко и по делу.",
    "deep": "Ответь подробно и структурно.",
    "plan": "Сначала дай чёткий пошаговый план.",
    "code": "Сконцентрируйся на коде, командах и конфигурации.",
    "explain": "Объясни простыми словами, что это и как это работает.",
    "fix": "Найди проблему и предложи конкретное исправление.",
    "commands": "Дай только нужные команды и короткие пояснения.",
    "summary": "Сделай краткую выжимку из ключевых пунктов.",
}


def apply_reply_mode(text: str, mode: str) -> str:
    instruction = REPLY_MODES.get(mode, "")
    return text if not instruction else f"{instruction}\n\nЗапрос пользователя:\n{text}"


def apply_template(text: str, template: str | None) -> str:
    if not template:
        return text
    instruction = QUICK_TEMPLATES.get(template)
    return text if not instruction else f"{instruction}\n\n{text}"


def build_chat_prompt(owner_id: str, text: str, mode: str, template: str | None, media) -> str:
    text = (text or "").strip()
    analysis = analyze_chat_request(text, has_attachments=bool(getattr(media, "attachments", None)))
    compact = should_compact_prompt(text=text, mode=mode, template=template, media=media)
    user_context = recent_user_context(owner_id, limit=3 if compact else 5, item_chars=100 if compact else 160)
    profile = get_profile_summary(owner_id, limit=3 if compact else 5)
    wrapped = apply_template(apply_reply_mode(text, mode), template)
    system = build_chat_system_prompt(analysis.intent, compact=compact)
    response_rules = build_chat_response_rules(analysis.intent, mode=mode, template=template)
    parts = [system]
    if analysis.style_hint:
        parts.append(
            f"Автоанализ запроса: intent={analysis.intent}; confidence={analysis.confidence}; "
            f"style={analysis.style_hint}"
        )
    parts.append(response_rules)
    if user_context:
        label = "Контекст пользователя" if compact else "Недавний контекст и предпочтения пользователя"
        parts.append(f"{label}:\n" + user_context)
    if profile:
        parts.append("Профиль пользователя:\n" + profile)
    if getattr(media, "attachments", None):
        parts.append("В запросе есть приложенные локальные файлы, доступные по путям `@...` внутри текста.")
    parts.append("Формат: если запрос практический, дай результат или шаги; если объяснение, дай ясную суть и ключевые детали; если код, дай рабочее решение.")
    parts.append("Запрос пользователя:\n" + wrapped)
    return "\n\n".join(parts)


def build_chat_system_prompt(intent: str, *, compact: bool) -> str:
    if compact:
        return "Ты ассистент пользователя в Telegram. Отвечай точно, полезно и без лишнего текста."
    variants = {
        "code": (
            "Ты технический ассистент пользователя в Telegram. "
            "Когда запрос связан с кодом, конфигами, ошибками или командами, давай рабочее решение, "
            "а не абстрактные советы. Ставь корректность и применимость выше красоты формулировок."
        ),
        "plan": (
            "Ты ассистент по планированию. "
            "Сначала быстро структурируй задачу, затем выдай наиболее рациональный пошаговый план, "
            "без лишней теории и повторов."
        ),
        "explain": (
            "Ты ассистент-объяснитель. "
            "Разъясняй суть ясно, компактно и без упрощений, которые ломают смысл. "
            "Начинай с интуитивного объяснения, затем добавляй важные детали."
        ),
        "quick": (
            "Ты быстрый практичный ассистент. "
            "Если запрос простой, отвечай коротко, но не теряй главное. "
            "Не раздувай ответ ради формы."
        ),
        "attachment": (
            "Ты ассистент пользователя в Telegram. "
            "Основной источник истины здесь вложения и приложенный контекст. "
            "Опирайся на них, не додумывай содержимое и явно отмечай, если данных не хватает."
        ),
        "general": (
            "Ты основной ассистент пользователя в Telegram. "
            "Твоя задача: быстро понять намерение пользователя и дать лучший практически полезный ответ. "
            "Прикладные запросы закрывай готовым результатом, командами, текстом, планом или решением, а не общими рассуждениями. "
            "Если есть вложения, транскрипция голоса или контекст пользователя, используй их как часть задачи. "
            "Если данных хватает не полностью, делай только разумные допущения и коротко помечай их."
        ),
    }
    return variants.get(intent, variants["general"])


def build_chat_response_rules(intent: str, *, mode: str, template: str | None) -> str:
    base = (
        "Правила ответа: сначала отвечай по существу; не пересказывай запрос; не пиши длинные дисклеймеры; "
        "если можно ответить коротко без потери смысла, отвечай коротко; если нужен выбор, сравни варианты и дай лучший."
    )
    intent_rules = {
        "code": "Для кода: предпочитай рабочие команды, патчи, примеры и проверяемые шаги; если есть риск, назови его явно.",
        "plan": "Для плана: начни с 3-7 шагов в правильном порядке; добавляй детали только там, где есть реальная неопределённость.",
        "explain": "Для объяснения: сначала дай краткую суть, затем 2-4 ключевые детали или примера.",
        "quick": "Для короткого ответа: 1-3 абзаца или краткий список, только если он реально нужен.",
        "attachment": "Для работы с вложениями: ссылайся только на то, что действительно видно в приложенных данных.",
        "general": "Для общего запроса: выбери самый полезный формат ответа вместо универсальной болтовни.",
    }
    mode_rule = ""
    if mode == "code" or template == "code":
        mode_rule = "Режим code: ожидается технически точный, прикладной и проверяемый ответ."
    elif mode == "plan" or template == "plan":
        mode_rule = "Режим plan: сначала шаги, потом уточняющие детали."
    elif mode == "deep" or template == "deep":
        mode_rule = "Режим deep: полнота важна, но без воды и повторов."
    elif mode == "brief" or template == "brief":
        mode_rule = "Режим brief: отвечай минимально достаточным объёмом."
    return " ".join(part for part in [base, intent_rules.get(intent, intent_rules["general"]), mode_rule] if part)


def should_compact_prompt(text: str, mode: str, template: str | None, media) -> bool:
    if mode in {"deep", "plan", "code"}:
        return False
    if template in {"deep", "plan", "code", "fix"}:
        return False
    if getattr(media, "attachments", None):
        return False
    compact_text = " ".join((text or "").split())
    if len(compact_text) > 240:
        return False
    return bool(re.fullmatch(r"[\w\sа-яА-ЯёЁ.,!?()/%:+-]{1,240}", compact_text))


def recent_user_context(owner_id: str, limit: int = 5, item_chars: int = 180) -> str:
    stored = get_user_preferences(owner_id, limit=max(3, limit))
    rows = get_recent_history(owner_id, role="user", limit=10)
    items: list[str] = []
    seen: set[str] = set()
    for pref in stored:
        label = shrink_text(f"[{pref['category']}] {pref['value']}", item_chars)
        norm = label.lower()
        if norm in seen:
            continue
        seen.add(norm)
        items.append(f"- {label}")
        if len(items) >= limit:
            return "\n".join(items)
    for row in rows:
        text = shrink_text(" ".join((row.get("text") or "").split()).strip(), item_chars)
        if not text:
            continue
        normalized = text.lower()
        if normalized in seen:
            continue
        seen.add(normalized)
        items.append(f"- {text}")
        if len(items) >= limit:
            break
    return "\n".join(items)


def shrink_text(text: str, limit: int) -> str:
    text = " ".join((text or "").split()).strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "…"


def learn_preferences_from_text(owner_id: str, text: str):
    lowered = (text or "").lower()
    rules = [
        ("content", ["ютуб", "youtube", "видео", "let's play", "летсплей", "стрим"]),
        ("games", ["roblox", "minecraft", "майнкрафт", "игра", "игры"]),
        ("music", ["музыка", "трек", "песня", "playlist", "плейлист"]),
        ("coding", ["код", "python", "javascript", "программа", "скрипт", "бот"]),
    ]
    for category, needles in rules:
        for needle in needles:
            if needle in lowered:
                upsert_user_preference(owner_id, category, needle, weight=1.0, source="message")
    learn_profile_from_text(owner_id, text)
