"""PC client bootstrap generation and command delivery."""

from __future__ import annotations

import logging
import secrets
import textwrap
import uuid
from pathlib import Path

from config import PC_PUBLIC_BASE_URL, PC_RELAY_PORT, PROJECT_ROOT
from db import (
    create_pc_command,
    create_pc_device,
    get_pc_device,
    get_pc_devices,
)
from pc_prompting import build_pc_bootstrap_caption as render_pc_bootstrap_caption
from pc_prompting import build_pc_task_prompt
from pc_relay import set_event_handlers, start_pc_relay, stop_pc_relay
from pc_trace import append_trace

logger = logging.getLogger("pc_control")

CLIENT_VERSION = "1.1"
CLIENT_DIR = PROJECT_ROOT / "workspace" / "pc_clients"


def get_relay_base_url() -> str:
    if PC_PUBLIC_BASE_URL:
        return PC_PUBLIC_BASE_URL
    return f"http://127.0.0.1:{PC_RELAY_PORT}"


def provision_pc_pairing(owner_id: str, chat_id: int) -> dict:
    device_id = uuid.uuid4().hex[:10]
    pair_token = secrets.token_urlsafe(24)
    device_token = secrets.token_urlsafe(32)
    relay_base_url = get_relay_base_url()
    device = create_pc_device(
        owner_id=owner_id,
        chat_id=chat_id,
        device_id=device_id,
        pair_token=pair_token,
        device_token=device_token,
        name=f"ПК {device_id}",
        relay_base_url=relay_base_url,
    )

    CLIENT_DIR.mkdir(parents=True, exist_ok=True)
    script_path = CLIENT_DIR / f"qwenclaw_pc_{device_id}.py"
    script_path.write_text(_build_client_script(device), encoding="utf-8")
    device["script_path"] = str(script_path)
    return device


def queue_pc_chat(owner_id: str, device_id: str, prompt: str) -> dict:
    command_id = uuid.uuid4().hex[:8]
    command = create_pc_command(owner_id, device_id, command_id, build_pc_task_prompt(owner_id, prompt, device_id=device_id), kind="chat")
    append_trace(command_id, "queued", {"kind": "chat", "owner_id": owner_id, "device_id": device_id, "prompt": prompt[:500]}, owner_id=owner_id, device_id=device_id)
    return command


def queue_pc_inspect(owner_id: str, device_id: str) -> dict:
    command_id = uuid.uuid4().hex[:8]
    prompt = (
        "Сделай осмотр текущего экрана и пришли краткий отчёт. "
        "Нужно определить активное окно, видимое состояние интерфейса и ключевой текст на экране."
    )
    command = create_pc_command(owner_id, device_id, command_id, prompt, kind="inspect")
    append_trace(command_id, "queued", {"kind": "inspect", "owner_id": owner_id, "device_id": device_id}, owner_id=owner_id, device_id=device_id)
    return command


def queue_pc_camera(owner_id: str, device_id: str, prompt: str = "", *, describe: bool = False) -> dict:
    command_id = uuid.uuid4().hex[:8]
    kind = "camera_describe" if describe else "camera_snapshot"
    if not prompt:
        prompt = "Опиши, что видно с камеры ПК." if describe else "Сделай снимок камеры ПК и отправь его."
    command = create_pc_command(owner_id, device_id, command_id, prompt, kind=kind)
    append_trace(command_id, "queued", {"kind": kind, "owner_id": owner_id, "device_id": device_id, "prompt": prompt[:500]}, owner_id=owner_id, device_id=device_id)
    return command


def build_pc_bootstrap_caption(device: dict) -> str:
    relay_url = device.get("relay_base_url") or get_relay_base_url()
    return render_pc_bootstrap_caption(device, relay_url)


def _build_client_script(device: dict) -> str:
    relay_url = device.get("relay_base_url") or get_relay_base_url()
    script = textwrap.dedent(
        f"""\
        #!/usr/bin/env python3
        import json
        import os
        import platform
        import re
        import shlex
        import shutil
        import socket
        import subprocess
        import sys
        import time
        import base64
        import webbrowser
        import urllib.error
        import urllib.parse
        import urllib.request
        from pathlib import Path

        RELAY_BASE_URL = {relay_url!r}
        DEVICE_ID = {device["device_id"]!r}
        DEVICE_TOKEN = {device["device_token"]!r}
        PAIR_TOKEN = {device["pair_token"]!r}
        CLIENT_VERSION = {CLIENT_VERSION!r}
        POLL_INTERVAL = 4
        DEFAULT_QWEN_BIN = os.environ.get("QWEN_PC_BIN", "qwen")
        TASK_WORK_DIR = Path(os.environ.get("QWEN_PC_WORK_DIR", str(Path.home())))
        TOOL_ROOT = Path.home() / ".qwenclaw" / DEVICE_ID
        SCREEN_DIR = TOOL_ROOT / "screens"
        CAMERA_DIR = TOOL_ROOT / "camera"
        STATE_DIR = TOOL_ROOT / "state"
        COMPACT_TIMEOUT = int(os.environ.get("QWEN_PC_TIMEOUT", "1200"))
        DEEP_TIMEOUT = int(os.environ.get("QWEN_PC_DEEP_TIMEOUT", "1800"))
        RESULT_SOFT_LIMIT = int(os.environ.get("QWEN_PC_RESULT_LIMIT", "12000"))
        TESSERACT_LANG = os.environ.get("QWEN_PC_TESSERACT_LANG", "rus+eng")
        CDP_PORT = int(os.environ.get("QWEN_PC_CDP_PORT", "9222"))
        EXPLICIT_SHELL_PREFIXES = (
            "cmd:",
            "shell:",
            "sh:",
            "bash:",
            "powershell:",
            "pwsh:",
        )
        FAST_COMMAND_PATTERNS = (
            r"^(pwd|cd|ls|dir|whoami|hostname|date|time)$",
            r"^(pwd|ls|dir|whoami|hostname|git status)$",
            r"^(python|python3|pip|node|npm|pnpm|yarn|git)\\b",
            r"^(where|which|echo|cat|type|ipconfig|ifconfig|uname|ver|systeminfo|tasklist|ps)\\b",
        )


        def post_json(path, payload, timeout=20):
            url = RELAY_BASE_URL + path
            data = json.dumps(payload).encode("utf-8")
            request = urllib.request.Request(
                url,
                data=data,
                headers={{"Content-Type": "application/json"}},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))


        def send_progress(command_id, stage, message):
            try:
                post_json(
                    "/pc/progress",
                    {{
                        "device_token": DEVICE_TOKEN,
                        "command_id": command_id,
                        "stage": stage,
                        "message": message,
                    }},
                    timeout=10,
                )
            except Exception:
                pass


        def get_json(path, params=None, timeout=60):
            url = RELAY_BASE_URL + path
            if params:
                url += "?" + urllib.parse.urlencode(params)
            with urllib.request.urlopen(url, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))


        def self_delete():
            try:
                script_path = Path(__file__).resolve()
                os.remove(script_path)
                print("Клиент удалён:", script_path)
            except OSError as exc:
                print("Не удалось удалить файл клиента:", exc)


        def ensure_work_dir():
            TASK_WORK_DIR.mkdir(parents=True, exist_ok=True)
            return TASK_WORK_DIR


        def ensure_tool_dirs():
            SCREEN_DIR.mkdir(parents=True, exist_ok=True)
            CAMERA_DIR.mkdir(parents=True, exist_ok=True)
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            return TOOL_ROOT


        def task_state_path(command_id):
            ensure_tool_dirs()
            return STATE_DIR / f"{{command_id}}.json"


        def load_task_state(command_id):
            path = task_state_path(command_id)
            if not path.exists():
                return {{
                    "command_id": command_id,
                    "attempts": 0,
                    "steps": [],
                    "last_window": "",
                    "last_url": "",
                    "fallbacks": [],
                }}
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                return {{
                    "command_id": command_id,
                    "attempts": 0,
                    "steps": [],
                    "last_window": "",
                    "last_url": "",
                    "fallbacks": [],
                }}


        def save_task_state(command_id, state):
            path = task_state_path(command_id)
            path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


        def task_step(command_id, name, details=""):
            state = load_task_state(command_id)
            state["attempts"] = int(state.get("attempts", 0)) + 1
            state["last_window"] = active_window_title() or state.get("last_window", "")
            if details:
                state["steps"].append({{"name": name, "details": details[:300]}})
            else:
                state["steps"].append({{"name": name}})
            state["steps"] = state["steps"][-20:]
            save_task_state(command_id, state)


        def task_note_url(command_id, url):
            state = load_task_state(command_id)
            state["last_url"] = (url or "")[:300]
            save_task_state(command_id, state)


        def task_note_fallback(command_id, reason):
            state = load_task_state(command_id)
            state["fallbacks"].append((reason or "")[:200])
            state["fallbacks"] = state["fallbacks"][-10:]
            save_task_state(command_id, state)


        def summarize_task_state(command_id):
            state = load_task_state(command_id)
            attempts = int(state.get("attempts", 0) or 0)
            last_window = (state.get("last_window") or "").strip()
            last_url = (state.get("last_url") or "").strip()
            steps = [step.get("name", "?") for step in state.get("steps", [])[-4:]]
            fallbacks = [item for item in state.get("fallbacks", [])[-2:] if item]
            if not attempts and not last_window and not last_url and not steps and not fallbacks:
                return ""
            parts = [f"attempts={{attempts}}"]
            if last_window:
                parts.append(f"window={{last_window[:80]}}")
            if last_url:
                parts.append(f"url={{last_url[:120]}}")
            if steps:
                parts.append(f"steps={{' > '.join(steps)}}")
            if fallbacks:
                parts.append(f"fallbacks={{' | '.join(fallbacks)[:120]}}")
            return "; ".join(parts)


        def extract_task_type(prompt):
            match = re.search(r"Тип(?:\\s+задачи)?\\s*:\\s*([a-z_]+)", prompt or "", re.I)
            return (match.group(1).strip().lower() if match else "general")[:24]


        def extract_success_checks(prompt):
            match = re.search(r"Success checks:\\s*(.+)", prompt or "", re.I)
            if not match:
                return []
            checks = [item.strip(" -") for item in match.group(1).split(";")]
            return [item[:120] for item in checks if item][:4]


        def screen_state_snapshot():
            active_window = active_window_title() or ""
            ocr_ok, screen_text, _ = run_ocr()
            apps = detect_apps_from_text(active_window, screen_text or "")
            obstacles = detect_obstacles(active_window, screen_text or "")
            url = detect_url(screen_text or "")
            state_guess = guess_screen_state(active_window, screen_text or "", apps, obstacles)
            return {{
                "active_window": active_window[:120],
                "screen_text": (screen_text or "").strip()[:700],
                "detected_apps": apps[:6],
                "obstacles": obstacles[:6],
                "url": url[:200],
                "state_guess": state_guess[:80],
            }}


        def summarize_live_context(snapshot):
            if not snapshot:
                return ""
            parts = []
            if snapshot.get("active_window"):
                parts.append(f"window={{snapshot['active_window']}}")
            if snapshot.get("url"):
                parts.append(f"url={{snapshot['url']}}")
            if snapshot.get("state_guess"):
                parts.append(f"state={{snapshot['state_guess']}}")
            if snapshot.get("detected_apps"):
                parts.append("apps=" + ",".join(snapshot["detected_apps"][:4]))
            if snapshot.get("obstacles"):
                parts.append("obstacles=" + ",".join(snapshot["obstacles"][:4]))
            if snapshot.get("screen_text"):
                parts.append(f"text={{snapshot['screen_text'][:220]}}")
            return "; ".join(parts)


        def should_collect_live_context(prompt):
            task_type = extract_task_type(prompt)
            return task_type in {{"browser", "desktop", "general", "inspect"}}


        def verification_brief(prompt):
            checks = extract_success_checks(prompt)
            if not checks:
                return ""
            return "Проверь в конце: " + "; ".join(checks)


        def local_agent_profile(task_type):
            profiles = {{
                "browser": (
                    "Локальный browser-профиль: сначала используй browser-status, browser-tabs, navigate-url и URL-проверку. "
                    "OCR и координатные клики только если browser-layer не дал нужного контроля."
                ),
                "desktop": (
                    "Локальный desktop-профиль: сначала активное окно, window-management хоткеи, inspect и проверка интерфейса. "
                    "Клики по координатам только как fallback."
                ),
                "shell": (
                    "Локальный shell-профиль: предпочитай команды, exit code, stdout и stderr. "
                    "GUI используй только если задача явно про окно или приложение."
                ),
                "inspect": (
                    "Локальный inspect-профиль: собери состояние экрана, окна, URL, вкладок и препятствий без лишних действий."
                ),
                "general": (
                    "Локальный general-профиль: сначала выбери самый устойчивый путь между browser, shell и desktop, "
                    "затем действуй с проверкой результата."
                ),
            }}
            return profiles.get(task_type, profiles["general"])


        def local_agent_output_rules(task_type):
            common = "Ответ строго в формате: План:, Действия:, Проверка:, Итог:."
            specifics = {{
                "browser": "В Проверке обязательно укажи URL, вкладку, заголовок страницы или состояние браузера.",
                "desktop": "В Проверке обязательно укажи активное окно или заметное изменение интерфейса.",
                "shell": "В Проверке обязательно укажи exit code и краткий итог stdout/stderr.",
                "inspect": "В Итоге верни структурированное состояние, а не описание рассуждений.",
                "general": "В Проверке укажи, каким источником подтверждён результат: экран, URL, окно или вывод команды.",
            }}
            return common + " " + specifics.get(task_type, specifics["general"])


        def mission_header(prompt, command_id=""):
            live_context = ""
            if should_collect_live_context(prompt):
                snapshot = screen_state_snapshot()
                live_context = summarize_live_context(snapshot)
                if command_id and live_context:
                    task_step(command_id, "live_context", live_context[:180])
            verify = verification_brief(prompt)
            blocks = []
            if live_context:
                blocks.append("Live context:\\\\n" + live_context)
            if verify:
                blocks.append(verify)
            return "\\\\n\\\\n".join(blocks)


        def command_preview(text, limit=160):
            text = (text or "").strip().replace("\\r", " ").replace("\\n", " ")
            return text if len(text) <= limit else text[: limit - 1] + "…"


        def tool_result(ok, **payload):
            data = {{"ok": ok, **payload}}
            return json.dumps(data, ensure_ascii=False)


        def encode_attachment(path, *, kind="file"):
            file_path = Path(path).expanduser()
            if not file_path.exists():
                return {{}}
            return {{
                "filename": file_path.name,
                "kind": kind,
                "content_b64": base64.b64encode(file_path.read_bytes()).decode("ascii"),
            }}


        def default_camera_path():
            ensure_tool_dirs()
            return CAMERA_DIR / f"camera_{{int(time.time())}}.jpg"


        def capture_camera_image(target_path=""):
            ensure_tool_dirs()
            path = Path(target_path).expanduser() if target_path else default_camera_path()
            path.parent.mkdir(parents=True, exist_ok=True)

            try:
                import cv2  # type: ignore
                cap = cv2.VideoCapture(0)
                if cap and cap.isOpened():
                    ok, frame = cap.read()
                    cap.release()
                    if ok:
                        cv2.imwrite(str(path), frame)
                        if path.exists():
                            return True, str(path), ""
                elif cap:
                    cap.release()
            except Exception:
                pass

            if os.name == "nt" and shutil.which("ffmpeg"):
                for source in ("video=Integrated Camera", "video=USB Camera", "video=HD WebCam"):
                    proc = subprocess.run(
                        ["ffmpeg", "-y", "-f", "dshow", "-i", source, "-frames:v", "1", str(path)],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    if proc.returncode == 0 and path.exists():
                        return True, str(path), ""

            if sys.platform == "darwin" and shutil.which("ffmpeg"):
                proc = subprocess.run(
                    ["ffmpeg", "-y", "-f", "avfoundation", "-i", "0:none", "-frames:v", "1", str(path)],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if proc.returncode == 0 and path.exists():
                    return True, str(path), ""
            if sys.platform.startswith("linux") and shutil.which("ffmpeg"):
                video_device = "/dev/video0"
                if Path(video_device).exists():
                    proc = subprocess.run(
                        ["ffmpeg", "-y", "-f", "video4linux2", "-i", video_device, "-frames:v", "1", str(path)],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    if proc.returncode == 0 and path.exists():
                        return True, str(path), ""

            return False, "", "Не удалось получить кадр с камеры. Установите opencv-python или настройте ffmpeg/камеру."


        def load_pyautogui():
            try:
                import pyautogui  # type: ignore
                pyautogui.FAILSAFE = False
                pyautogui.PAUSE = 0.15
                return pyautogui, ""
            except Exception as exc:
                return None, str(exc)


        def load_imagegrab():
            try:
                from PIL import ImageGrab  # type: ignore
                return ImageGrab, ""
            except Exception as exc:
                return None, str(exc)


        def canonical_key_name(key):
            raw = (key or "").strip().lower().replace("_", "-")
            aliases = {{
                "win": "winleft",
                "windows": "winleft",
                "meta": "winleft",
                "super": "winleft",
                "cmd": "command",
                "commandkey": "command",
                "ctrl": "ctrl",
                "control": "ctrl",
                "altgr": "altright",
                "option": "alt",
                "return": "enter",
                "esc": "esc",
                "pgup": "pageup",
                "pgdn": "pagedown",
                "del": "delete",
                "ins": "insert",
                "spacebar": "space",
            }}
            return aliases.get(raw, raw)


        def desktop_hotkey():
            if sys.platform == "darwin":
                return ["command", "f3"]
            return ["winleft", "d"]


        def search_hotkey():
            if sys.platform == "darwin":
                return ["command", "space"]
            if os.name == "nt":
                return ["winleft", "s"]
            return ["alt", "f2"]


        def browser_hotkey():
            if sys.platform == "darwin":
                return ["command", "space"]
            if os.name == "nt":
                return ["winleft", "r"]
            return ["alt", "f2"]


        def close_window_hotkey():
            if sys.platform == "darwin":
                return ["command", "q"]
            return ["alt", "f4"]


        def switch_window_hotkey(reverse=False):
            if sys.platform == "darwin":
                return ["command", "shift", "tab"] if reverse else ["command", "tab"]
            return ["alt", "shift", "tab"] if reverse else ["alt", "tab"]


        def minimize_window_hotkey():
            if sys.platform == "darwin":
                return ["command", "m"]
            return ["winleft", "down"]


        def normalize_hotkey_args(args):
            parts = []
            for arg in args:
                if "+" in arg:
                    parts.extend(chunk for chunk in arg.split("+") if chunk)
                else:
                    parts.append(arg)
            return [canonical_key_name(part) for part in parts if str(part).strip()]


        def execute_hotkey(pyautogui, keys):
            keys = normalize_hotkey_args(keys)
            if len(keys) < 2:
                return False, "Нужно минимум 2 клавиши"
            pyautogui.hotkey(*keys)
            return True, keys


        def open_browser_app(preferred=""):
            preferred = (preferred or "").strip().lower()
            for item, mode in browser_launch_candidates(preferred):
                try:
                    if mode == "mac-open":
                        subprocess.Popen(
                            ["open", "-a", item, "--args", f"--remote-debugging-port={{CDP_PORT}}", "--new-window", "about:blank"],
                            cwd=str(ensure_work_dir()),
                        )
                        return True, f"Запущен браузер: {{item}}"
                    if mode == "linux-xdg":
                        subprocess.Popen(["xdg-open", "about:blank"], cwd=str(ensure_work_dir()))
                        return True, "Запущен браузер через xdg-open"
                    if mode == "plain":
                        subprocess.Popen([item], cwd=str(ensure_work_dir()))
                        return True, f"Запущен браузер: {{item}}"
                    if mode == "cdp":
                        subprocess.Popen(
                            [item, f"--remote-debugging-port={{CDP_PORT}}", "--new-window", "about:blank"],
                            cwd=str(ensure_work_dir()),
                        )
                        return True, f"Запущен браузер с CDP: {{item}}"
                except Exception:
                    continue
            return False, "Не удалось запустить браузер стандартными способами"


        def browser_launch_candidates(preferred=""):
            preferred = (preferred or "").strip().lower()
            items = []

            def add(name, mode):
                if not name:
                    return
                key = (name.lower(), mode)
                if key not in seen:
                    seen.add(key)
                    items.append((name, mode))

            seen = set()
            if os.name == "nt":
                ordered = [preferred] if preferred else []
                ordered.extend(["chrome", "msedge", "brave", "firefox"])
                for item in ordered:
                    if not item:
                        continue
                    add(item, "cdp" if item in {"chrome", "msedge", "brave"} else "plain")
                return items
            if sys.platform == "darwin":
                ordered = [preferred] if preferred else []
                ordered.extend(["Google Chrome", "Brave Browser", "Safari", "Firefox"])
                for item in ordered:
                    if not item:
                        continue
                    add(item, "mac-open")
                return items

            ordered = [preferred] if preferred else []
            ordered.extend(["google-chrome", "chromium", "brave-browser", "firefox", "xdg-open"])
            for item in ordered:
                if not item:
                    continue
                if item == "xdg-open":
                    add(item, "linux-xdg")
                else:
                    add(item, "cdp" if item in {"google-chrome", "chromium", "brave-browser"} else "plain")
            return items


        def cdp_base_urls():
            ports = []
            for item in (CDP_PORT, 9222, 9223, 9333):
                if item not in ports:
                    ports.append(item)
            return [f"http://127.0.0.1:{{port}}" for port in ports]


        def cdp_fetch_json(path, timeout=2.5):
            last_error = ""
            for base in cdp_base_urls():
                try:
                    with urllib.request.urlopen(base + path, timeout=timeout) as response:
                        return base, json.loads(response.read().decode("utf-8"))
                except Exception as exc:
                    last_error = str(exc)
                    continue
            return "", last_error


        def cdp_browser_status():
            base, payload = cdp_fetch_json("/json/version")
            if not base or not isinstance(payload, dict):
                return {{}}
            browser = (payload.get("Browser") or "").strip()
            user_agent = (payload.get("User-Agent") or "").strip()
            return {{
                "base_url": base,
                "browser": browser[:120],
                "user_agent": user_agent[:200],
                "ok": True,
            }}


        def cdp_list_tabs():
            base, payload = cdp_fetch_json("/json/list")
            if not base or not isinstance(payload, list):
                return []
            tabs = []
            for item in payload:
                if not isinstance(item, dict):
                    continue
                tabs.append({{
                    "id": (item.get("id") or "")[:120],
                    "type": (item.get("type") or "")[:40],
                    "title": (item.get("title") or "")[:240],
                    "url": (item.get("url") or "")[:500],
                    "base_url": base,
                }})
            return tabs


        def cdp_active_tab():
            tabs = cdp_list_tabs()
            for tab in tabs:
                if tab.get("type") == "page" and tab.get("url") and tab.get("url") != "about:blank":
                    return tab
            for tab in tabs:
                if tab.get("type") == "page":
                    return tab
            return {{}}


        def cdp_new_tab(url):
            target = (url or "about:blank").strip() or "about:blank"
            encoded = urllib.parse.quote(target, safe=":/?&=#%+")
            for base in cdp_base_urls():
                try:
                    with urllib.request.urlopen(base + "/json/new?" + encoded, timeout=4) as response:
                        payload = json.loads(response.read().decode("utf-8"))
                    if isinstance(payload, dict):
                        return True, {{
                            "id": (payload.get("id") or "")[:120],
                            "title": (payload.get("title") or "")[:240],
                            "url": (payload.get("url") or target)[:500],
                            "base_url": base,
                        }}
                except Exception:
                    continue
            return False, {{}}


        def cdp_activate_tab(tab_id):
            tab_id = (tab_id or "").strip()
            if not tab_id:
                return False
            for base in cdp_base_urls():
                try:
                    with urllib.request.urlopen(base + "/json/activate/" + urllib.parse.quote(tab_id, safe=""), timeout=3):
                        return True
                except Exception:
                    continue
            return False


        def is_browser_window(title):
            lowered = (title or "").lower()
            return any(token in lowered for token in ["chrome", "firefox", "edge", "safari", "opera", "brave", "browser"])


        def wait_for_window(predicate, timeout=8.0, interval=0.4):
            deadline = time.time() + timeout
            while time.time() < deadline:
                title = active_window_title()
                if predicate(title):
                    return True, title
                time.sleep(interval)
            return False, active_window_title()


        def safe_press_key(key):
            pyautogui, error = load_pyautogui()
            if pyautogui is None:
                return False, f"pyautogui недоступен: {{error}}"
            key = canonical_key_name(key)
            pyautogui.press(key)
            return True, key


        def safe_hotkey_action(keys):
            pyautogui, error = load_pyautogui()
            if pyautogui is None:
                return False, f"pyautogui недоступен: {{error}}"
            ok, payload = execute_hotkey(pyautogui, keys)
            if not ok:
                return False, payload
            return True, payload


        def safe_type_text(text, *, replace=False):
            pyautogui, error = load_pyautogui()
            if pyautogui is None:
                return False, f"pyautogui недоступен: {{error}}"
            if replace:
                ok, payload = safe_hotkey_action(["command", "a"] if sys.platform == "darwin" else ["ctrl", "a"])
                if not ok:
                    return False, payload
            pyautogui.write(text, interval=0.01)
            return True, text


        def ensure_browser_window(preferred="", command_id=""):
            if command_id:
                task_step(command_id, "ensure_browser_window", preferred or "default")
            cdp_status = cdp_browser_status()
            if cdp_status.get("ok"):
                return True, f"Браузер доступен через CDP: {{cdp_status.get('browser') or cdp_status.get('base_url')}}"
            title = active_window_title()
            if is_browser_window(title):
                return True, f"Браузер уже активен: {{title}}"
            ok, message = open_browser_app(preferred)
            if not ok:
                return False, message
            if command_id:
                send_progress(command_id, "browser", "Открываю или фокусирую браузер.")
            deadline = time.time() + 12.0
            while time.time() < deadline:
                status = cdp_browser_status()
                if status.get("ok"):
                    return True, f"Браузер доступен через CDP: {{status.get('browser') or status.get('base_url')}}"
                time.sleep(0.5)
            matched, title = wait_for_window(is_browser_window, timeout=10.0)
            if matched:
                return True, f"Браузер активен: {{title}}"
            return True, message


        def focus_address_bar(command_id=""):
            if command_id:
                task_step(command_id, "focus_address_bar")
            ok, payload = safe_hotkey_action(["command", "l"] if sys.platform == "darwin" else ["ctrl", "l"])
            if not ok:
                return False, payload
            if command_id:
                send_progress(command_id, "browser", "Фокусирую адресную строку браузера.")
            time.sleep(0.4)
            return True, payload


        def navigate_url(url, command_id=""):
            if command_id:
                task_step(command_id, "navigate_url", url)
            ok, message = ensure_browser_window(command_id=command_id)
            if not ok:
                if command_id:
                    task_note_fallback(command_id, message)
                return False, message
            cdp_ok, tab = cdp_new_tab(url)
            if cdp_ok:
                cdp_activate_tab(tab.get("id", ""))
                if command_id:
                    send_progress(command_id, "browser", f"Открываю страницу через CDP: {{url[:120]}}")
                    task_note_url(command_id, tab.get("url") or url)
                time.sleep(1.4)
                return True, f"Открыта страница через CDP: {{tab.get('url') or url}}"
            ok, payload = focus_address_bar(command_id=command_id)
            if not ok:
                return False, payload
            ok, payload = safe_type_text(url, replace=True)
            if not ok:
                return False, payload
            ok, payload = safe_press_key("enter")
            if not ok:
                return False, payload
            if command_id:
                send_progress(command_id, "browser", f"Открываю страницу: {{url[:120]}}")
                task_note_url(command_id, url)
            time.sleep(2.5)
            return True, f"Открыта страница: {{url}}"


        def extract_url_from_prompt(prompt):
            match = re.search(r"(https?://\\S+)", prompt or "", re.I)
            return match.group(1)[:500] if match else ""


        def extract_youtube_query(prompt):
            text = " ".join((prompt or "").split()).strip()
            lowered = text.lower()
            markers = ["найди ", "поиск ", "search ", "включи ", "play "]
            for marker in markers:
                pos = lowered.find(marker)
                if pos >= 0:
                    query = text[pos + len(marker):].strip(" .,:;!?")
                    if query:
                        return query[:200]
            return ""


        def maybe_prepare_browser_task(prompt, command_id=""):
            lowered = (prompt or "").lower()
            explicit_url = extract_url_from_prompt(prompt)
            if explicit_url:
                ok, message = navigate_url(explicit_url, command_id=command_id)
                if not ok:
                    if command_id:
                        task_note_fallback(command_id, message)
                    return False, "", message
                return True, f"Подготовка выполнена: уже открыт URL {{explicit_url}}.", ""

            browserish = any(token in lowered for token in ["youtube", "ютуб", "браузер", "сайт", "вкладк", "страниц", "ссылка", "url"])
            if not browserish:
                return None, "", ""

            if "youtube" in lowered or "ютуб" in lowered:
                query = extract_youtube_query(prompt)
                target_url = "https://www.youtube.com"
                if query:
                    target_url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query)
                ok, message = navigate_url(target_url, command_id=command_id)
                if not ok:
                    if command_id:
                        task_note_fallback(command_id, message)
                    return False, "", message
                note = f"Подготовка выполнена: браузер уже открыт на {{target_url}}."
                return True, note, ""

            ok, message = ensure_browser_window(command_id=command_id)
            if not ok:
                if command_id:
                    task_note_fallback(command_id, message)
                return False, "", message
            return True, "Подготовка выполнена: браузер уже открыт или сфокусирован.", ""


        def default_screenshot_path():
            ensure_tool_dirs()
            return SCREEN_DIR / f"screen_{{int(time.time())}}.png"


        def save_screenshot(target_path=""):
            ensure_tool_dirs()
            path = Path(target_path).expanduser() if target_path else default_screenshot_path()
            path.parent.mkdir(parents=True, exist_ok=True)

            pyautogui, _ = load_pyautogui()
            if pyautogui is not None:
                shot = pyautogui.screenshot()
                shot.save(path)
                return True, str(path), ""

            imagegrab, _ = load_imagegrab()
            if imagegrab is not None:
                shot = imagegrab.grab(all_screens=True)
                shot.save(path)
                return True, str(path), ""

            if sys.platform == "darwin" and shutil.which("screencapture"):
                proc = subprocess.run(["screencapture", "-x", str(path)], capture_output=True, text=True, timeout=60)
                if proc.returncode == 0 and path.exists():
                    return True, str(path), ""
                return False, "", (proc.stderr or "screencapture failed").strip()

            if shutil.which("gnome-screenshot"):
                proc = subprocess.run(["gnome-screenshot", "-f", str(path)], capture_output=True, text=True, timeout=60)
                if proc.returncode == 0 and path.exists():
                    return True, str(path), ""
                return False, "", (proc.stderr or "gnome-screenshot failed").strip()

            if shutil.which("scrot"):
                proc = subprocess.run(["scrot", str(path)], capture_output=True, text=True, timeout=60)
                if proc.returncode == 0 and path.exists():
                    return True, str(path), ""
                return False, "", (proc.stderr or "scrot failed").strip()

            return False, "", "Не удалось сделать скриншот. Установите pyautogui+Pillow, либо gnome-screenshot/scrot."


        def get_screen_size():
            pyautogui, _ = load_pyautogui()
            if pyautogui is not None:
                size = pyautogui.size()
                return int(size.width), int(size.height)

            imagegrab, _ = load_imagegrab()
            if imagegrab is not None:
                shot = imagegrab.grab()
                return int(shot.size[0]), int(shot.size[1])

            return 1920, 1080


        def normalize_coord(value, limit):
            raw = float(value)
            if 0 <= raw <= 1:
                return int(round(raw * limit))
            return int(round(raw))


        def normalize_point(x, y):
            width, height = get_screen_size()
            return normalize_coord(x, width), normalize_coord(y, height), width, height


        def active_window_title():
            try:
                if sys.platform == "darwin" and shutil.which("osascript"):
                    script = 'tell application "System Events" to get name of first application process whose frontmost is true'
                    proc = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=15)
                    if proc.returncode == 0:
                        return (proc.stdout or "").strip()
                if os.name == "nt":
                    proc = subprocess.run(
                        [
                            "powershell",
                            "-NoProfile",
                            "-Command",
                            "(Get-Process | Where-Object {{$_.MainWindowTitle}} | Sort-Object StartTime -Descending | Select-Object -First 1 -ExpandProperty MainWindowTitle)",
                        ],
                        capture_output=True,
                        text=True,
                        timeout=20,
                    )
                    if proc.returncode == 0:
                        return (proc.stdout or "").strip()
                if shutil.which("xdotool"):
                    proc = subprocess.run(
                        ["xdotool", "getactivewindow", "getwindowname"],
                        capture_output=True,
                        text=True,
                        timeout=15,
                    )
                    if proc.returncode == 0:
                        return (proc.stdout or "").strip()
            except Exception:
                pass
            return ""


        def run_ocr(target_path=""):
            ok, path, error = save_screenshot(target_path) if not target_path else (True, str(Path(target_path).expanduser()), "")
            if not ok:
                return False, "", error
            tesseract = shutil.which("tesseract")
            if not tesseract:
                return False, "", "Не найден tesseract. Установите tesseract-ocr для чтения текста с экрана."
            proc = subprocess.run(
                [tesseract, path, "stdout", "-l", TESSERACT_LANG],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if proc.returncode != 0:
                return False, "", (proc.stderr or "tesseract failed").strip()
            return True, proc.stdout.strip(), path


        def detect_apps_from_text(active_window, screen_text):
            corpus = f"{{active_window}}\\n{{screen_text}}".lower()
            apps = []
            patterns = [
                ("browser", ["chrome", "firefox", "edge", "opera", "safari", "browser"]),
                ("youtube", ["youtube"]),
                ("roblox", ["roblox"]),
                ("code_editor", ["vscode", "visual studio code", "pycharm", "terminal"]),
                ("explorer", ["explorer", "finder", "files"]),
            ]
            for name, needles in patterns:
                if any(needle in corpus for needle in needles):
                    apps.append(name)
            return apps


        def detect_obstacles(active_window, screen_text):
            corpus = f"{{active_window}}\\n{{screen_text}}".lower()
            obstacles = []
            if any(token in corpus for token in ["error", "ошибка", "не удалось", "failed"]):
                obstacles.append("error_dialog")
            if any(token in corpus for token in ["loading", "загрузка", "подождите", "please wait"]):
                obstacles.append("loading_state")
            if "roblox" in corpus:
                obstacles.append("foreground_game")
            if any(token in corpus for token in ["sign in", "login", "войти", "вход"]):
                obstacles.append("auth_gate")
            return obstacles


        def detect_url(screen_text):
            tab = cdp_active_tab()
            if tab.get("url"):
                return tab["url"][:300]
            match = re.search(r"(https?://\\S+|www\\.\\S+|youtube\\.com\\S*)", screen_text or "", re.I)
            return match.group(1)[:300] if match else ""


        def guess_screen_state(active_window, screen_text, apps, obstacles):
            corpus = f"{{active_window}}\\n{{screen_text}}".lower()
            tab = cdp_active_tab()
            tab_url = (tab.get("url") or "").lower()
            tab_title = (tab.get("title") or "").lower()
            corpus = corpus + "\\n" + tab_url + "\\n" + tab_title
            if "youtube" in corpus:
                if any(token in corpus for token in ["search", "поиск", "recommended", "рекоменд"]):
                    return "browser_on_youtube_home"
                if any(token in corpus for token in ["pause", "пауза", "subscribe", "подписаться"]):
                    return "browser_on_youtube_video"
            if "roblox" in corpus:
                return "game_in_foreground"
            if "auth_gate" in obstacles:
                return "login_required"
            if "browser" in apps:
                return "browser_active"
            if "explorer" in apps:
                return "file_manager_active"
            return "unknown"


        def build_inspect_report():
            shot_ok, path, shot_error = save_screenshot()
            ocr_ok, text, ocr_meta = run_ocr(path if shot_ok else "")
            active_window = active_window_title() or "не определено"
            apps = detect_apps_from_text(active_window, text or "")
            obstacles = detect_obstacles(active_window, text or "")
            url = detect_url(text or "")
            browser_status = cdp_browser_status()
            tabs = cdp_list_tabs()
            active_tab = cdp_active_tab()
            state_guess = guess_screen_state(active_window, text or "", apps, obstacles)
            structured = {{
                "active_window": active_window,
                "screen_text": (text or "").strip()[:4000],
                "possible_ui_elements": [],
                "detected_apps": apps,
                "dialogs": [item for item in obstacles if item.endswith("_dialog")],
                "obstacles": obstacles,
                "url": url,
                "state_guess": state_guess,
                "browser": {{
                    "cdp": bool(browser_status.get("ok")),
                    "engine": browser_status.get("browser", ""),
                    "active_tab": {{
                        "title": active_tab.get("title", ""),
                        "url": active_tab.get("url", ""),
                    }},
                    "tabs": [
                        {{"title": item.get("title", ""), "url": item.get("url", ""), "type": item.get("type", "")}}
                        for item in tabs[:5]
                    ],
                }},
            }}
            payload = {{
                "ok": shot_ok,
                "result_text": json.dumps(structured, ensure_ascii=False, indent=2),
                "error_text": shot_error or ("" if ocr_ok else ocr_meta),
            }}
            if shot_ok:
                payload["attachment"] = encode_attachment(path, kind="image")
            return payload


        def build_camera_snapshot_report():
            ok, path, error = capture_camera_image()
            payload = {{
                "ok": ok,
                "result_text": "Снимок с камеры получен." if ok else "",
                "error_text": error,
            }}
            if ok:
                payload["attachment"] = encode_attachment(path, kind="image")
            return payload


        def describe_camera_scene(prompt, command_id=""):
            ok, path, error = capture_camera_image()
            if not ok:
                return False, "", error, {{}}
            if command_id:
                task_step(command_id, "camera_describe", path)
                send_progress(command_id, "camera", "Получаю кадр с камеры и описываю его.")
            camera_prompt = (
                "Опиши, что видно на изображении с камеры ПК. "
                "Сфокусируйся на людях, предметах, обстановке и важных деталях. "
                "Если виден экран, скажи это отдельно.\\n\\n"
                f"Запрос пользователя:\\n{{prompt}}\\n\\n@{{path}}"
            )
            ok2, result_text, error_text = run_qwen_task(camera_prompt, command_id)
            return ok2, result_text, error_text, encode_attachment(path, kind="image")


        def open_target(target):
            target = (target or "").strip()
            if not target:
                return False, "Пустой target"
            if re.match(r"^https?://", target, re.I):
                webbrowser.open(target)
                return True, f"Открыто в браузере: {{target}}"

            path = Path(target).expanduser()
            if not path.exists():
                return False, f"Путь не найден: {{path}}"

            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.run(["open", str(path)], check=True, timeout=30)
            else:
                subprocess.run(["xdg-open", str(path)], check=True, timeout=30)
            return True, f"Открыто: {{path}}"


        def run_computer_tool(argv):
            ensure_tool_dirs()
            if not argv:
                print(tool_result(False, error="Нужна команда tool"))
                return 1

            action = argv[0].lower()
            args = argv[1:]

            try:
                if action in {{"screen", "screenshot"}}:
                    ok, path, error = save_screenshot(args[0] if args else "")
                    print(tool_result(ok, path=path, error=error, window=active_window_title()))
                    return 0 if ok else 1

                if action == "ocr":
                    ok, text, meta = run_ocr(args[0] if args else "")
                    payload = {{"text": text, "error": "" if ok else meta}}
                    if ok:
                        payload["path"] = meta
                    print(tool_result(ok, **payload))
                    return 0 if ok else 1

                if action == "inspect":
                    shot_ok, path, shot_error = save_screenshot(args[0] if args else "")
                    ocr_ok, text, ocr_meta = run_ocr(path if shot_ok else "")
                    print(tool_result(
                        shot_ok,
                        path=path,
                        ocr_text=text if ocr_ok else "",
                        window=active_window_title(),
                        error=shot_error or ("" if ocr_ok else ocr_meta),
                    ))
                    return 0 if shot_ok else 1

                if action == "camera-snapshot":
                    payload = build_camera_snapshot_report()
                    print(tool_result(
                        bool(payload.get("ok")),
                        result=payload.get("result_text", ""),
                        error=payload.get("error_text", ""),
                        attachment=payload.get("attachment", {{}}),
                    ))
                    return 0 if payload.get("ok") else 1

                if action == "camera-describe":
                    query = " ".join(args).strip() or "Опиши, что видно на камере."
                    ok, result_text, error_text, attachment = describe_camera_scene(query)
                    print(tool_result(ok, result=result_text, error=error_text, attachment=attachment))
                    return 0 if ok else 1

                if action == "screen-size":
                    width, height = get_screen_size()
                    print(tool_result(True, width=width, height=height))
                    return 0

                if action == "cursor":
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    x, y = pyautogui.position()
                    width, height = get_screen_size()
                    print(tool_result(True, x=int(x), y=int(y), width=width, height=height))
                    return 0

                if action in {{"click", "move"}}:
                    if len(args) < 2:
                        print(tool_result(False, error="Нужны x y"))
                        return 1
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    x, y, width, height = normalize_point(args[0], args[1])
                    if action == "move":
                        pyautogui.moveTo(x, y, duration=0.2)
                    else:
                        button = args[2] if len(args) >= 3 else "left"
                        pyautogui.click(x=x, y=y, button=button)
                    print(tool_result(True, action=action, x=x, y=y, width=width, height=height))
                    return 0

                if action == "doubleclick":
                    if len(args) < 2:
                        print(tool_result(False, error="Нужны x y"))
                        return 1
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    x, y, width, height = normalize_point(args[0], args[1])
                    pyautogui.doubleClick(x=x, y=y)
                    print(tool_result(True, action=action, x=x, y=y, width=width, height=height))
                    return 0

                if action == "type":
                    if not args:
                        print(tool_result(False, error="Нужен текст"))
                        return 1
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    text = " ".join(args)
                    pyautogui.write(text, interval=0.01)
                    print(tool_result(True, typed=text))
                    return 0

                if action == "press":
                    if not args:
                        print(tool_result(False, error="Нужна клавиша"))
                        return 1
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    key = canonical_key_name(args[0])
                    pyautogui.press(key)
                    print(tool_result(True, key=key))
                    return 0

                if action == "hotkey":
                    if len(args) < 2:
                        print(tool_result(False, error="Нужно минимум 2 клавиши"))
                        return 1
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    ok, payload = execute_hotkey(pyautogui, args)
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, keys=payload))
                    return 0

                if action in {{"desktop", "show-desktop", "minimize-all"}}:
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    ok, payload = execute_hotkey(pyautogui, desktop_hotkey())
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, action=action, keys=payload))
                    return 0

                if action in {{"switch-window", "next-window", "alt-tab"}}:
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    reverse = any(str(arg).lower() in {{"reverse", "prev", "previous", "back"}} for arg in args)
                    ok, payload = execute_hotkey(pyautogui, switch_window_hotkey(reverse=reverse))
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, action=action, reverse=reverse, keys=payload))
                    return 0

                if action in {{"close-window", "quit-app"}}:
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    ok, payload = execute_hotkey(pyautogui, close_window_hotkey())
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, action=action, keys=payload))
                    return 0

                if action in {{"minimize-window", "hide-window"}}:
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    ok, payload = execute_hotkey(pyautogui, minimize_window_hotkey())
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, action=action, keys=payload))
                    return 0

                if action in {{"open-search", "search", "start-menu"}}:
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    ok, payload = execute_hotkey(pyautogui, search_hotkey())
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, action=action, keys=payload))
                    return 0

                if action in {{"open-browser", "browser"}}:
                    ok, message = open_browser_app(args[0] if args else "")
                    print(tool_result(ok, message=message if ok else "", error="" if ok else message))
                    return 0 if ok else 1

                if action in {{"browser-status", "cdp-status"}}:
                    status = cdp_browser_status()
                    active_tab = cdp_active_tab()
                    ok = bool(status.get("ok"))
                    print(tool_result(ok, status=status, active_tab=active_tab, tabs=cdp_list_tabs()[:5], error="" if ok else "CDP недоступен"))
                    return 0 if ok else 1

                if action in {{"browser-tabs", "tabs"}}:
                    tabs = cdp_list_tabs()
                    print(tool_result(bool(tabs), tabs=tabs[:10], count=len(tabs), error="" if tabs else "Не удалось получить список вкладок"))
                    return 0 if tabs else 1

                if action == "ensure-browser":
                    ok, message = ensure_browser_window(args[0] if args else "")
                    print(tool_result(ok, message=message if ok else "", error="" if ok else message, window=active_window_title(), browser_status=cdp_browser_status()))
                    return 0 if ok else 1

                if action == "navigate-url":
                    if not args:
                        print(tool_result(False, error="Нужен URL"))
                        return 1
                    ok, message = navigate_url(args[0])
                    inspect_payload = build_inspect_report()
                    print(tool_result(
                        ok,
                        message=message if ok else "",
                        error="" if ok else message,
                        inspect=inspect_payload.get("result_text", ""),
                    ))
                    return 0 if ok else 1

                if action == "youtube-search":
                    query = " ".join(args).strip()
                    if not query:
                        print(tool_result(False, error="Нужен поисковый запрос для YouTube"))
                        return 1
                    ok, note, error = maybe_prepare_browser_task(f"youtube найди {{query}}")
                    print(tool_result(ok is True, message=note if ok else "", error=error))
                    return 0 if ok else 1

                if action in {{"focus-address", "address-bar"}}:
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    ok, payload = execute_hotkey(pyautogui, ["ctrl", "l"] if sys.platform != "darwin" else ["command", "l"])
                    if not ok:
                        print(tool_result(False, error=payload))
                        return 1
                    print(tool_result(True, action=action, keys=payload))
                    return 0

                if action == "scroll":
                    amount = int(float(args[0])) if args else -500
                    pyautogui, error = load_pyautogui()
                    if pyautogui is None:
                        print(tool_result(False, error=f"pyautogui недоступен: {{error}}"))
                        return 1
                    pyautogui.scroll(amount)
                    print(tool_result(True, amount=amount))
                    return 0

                if action == "wait":
                    seconds = float(args[0]) if args else 1.0
                    time.sleep(max(0.0, seconds))
                    print(tool_result(True, waited=seconds))
                    return 0

                if action == "open":
                    ok, message = open_target(" ".join(args))
                    print(tool_result(ok, message=message if ok else "", error="" if ok else message))
                    return 0 if ok else 1

                print(tool_result(False, error=f"Неизвестный tool action: {{action}}"))
                return 1
            except Exception as exc:
                print(tool_result(False, error=str(exc), action=action))
                return 1


        def startup_targets():
            script_path = Path(__file__).resolve()
            windows_startup = Path(os.getenv("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup"
            linux_autostart = Path.home() / ".config/autostart"
            mac_launchagents = Path.home() / "Library/LaunchAgents"
            return {{
                "windows_dir": windows_startup,
                "windows_cmd": windows_startup / f"qwenclaw_{{DEVICE_ID}}.cmd",
                "linux_dir": linux_autostart,
                "linux_desktop": linux_autostart / f"qwenclaw_{{DEVICE_ID}}.desktop",
                "mac_dir": mac_launchagents,
                "mac_plist": mac_launchagents / f"com.qwenclaw.{{DEVICE_ID}}.plist",
                "script_path": script_path,
            }}


        def install_autostart():
            targets = startup_targets()
            script_path = targets["script_path"]

            if sys.platform.startswith("win"):
                startup_dir = targets["windows_dir"]
                startup_dir.mkdir(parents=True, exist_ok=True)
                cmd_path = targets["windows_cmd"]
                cmd_path.write_text(
                    f'@echo off\\r\\n"{{sys.executable}}" "{{script_path}}"\\r\\n',
                    encoding="utf-8",
                )
                return f"Автозапуск включён: {{cmd_path}}"

            if sys.platform == "darwin":
                launch_dir = targets["mac_dir"]
                launch_dir.mkdir(parents=True, exist_ok=True)
                plist_path = targets["mac_plist"]
                plist_path.write_text(
                    f'''<?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
            <key>Label</key>
            <string>com.qwenclaw.{{DEVICE_ID}}</string>
            <key>ProgramArguments</key>
            <array>
                <string>{{sys.executable}}</string>
                <string>{{script_path}}</string>
            </array>
            <key>RunAtLoad</key>
            <true/>
        </dict>
        </plist>
        ''',
                    encoding="utf-8",
                )
                return f"Автозапуск включён: {{plist_path}}"

            autostart_dir = targets["linux_dir"]
            autostart_dir.mkdir(parents=True, exist_ok=True)
            desktop_path = targets["linux_desktop"]
            desktop_path.write_text(
                f'''[Desktop Entry]
        Type=Application
        Name=QwenClaw {{DEVICE_ID}}
        Exec={{sys.executable}} {{script_path}}
        X-GNOME-Autostart-enabled=true
        ''',
                encoding="utf-8",
            )
            return f"Автозапуск включён: {{desktop_path}}"


        def remove_autostart():
            targets = startup_targets()
            for key in ("windows_cmd", "linux_desktop", "mac_plist"):
                path = targets[key]
                try:
                    if path.exists():
                        path.unlink()
                except OSError as exc:
                    print("Не удалось удалить автозапуск:", exc)


        def consent_prompt():
            print("Ваш ПК подключается к QwenClaw.")
            print("Клиент работает как проводник между ботом и этим ПК.")
            print(f"ID клиента: {{DEVICE_ID}}")
            print("Разрешить доступ этому клиенту? y = разрешаю, c = запрещаю и удалить клиент.")
            while True:
                choice = input("Введите y или c: ").strip().lower()
                if choice in {{"y", "c"}}:
                    return choice
                print("Нужно ввести только y или c.")


        def register():
            payload = {{
                "pair_token": PAIR_TOKEN,
                "device_token": DEVICE_TOKEN,
                "device_name": socket.gethostname(),
                "hostname": socket.gethostname(),
                "platform": platform.platform(),
                "client_version": CLIENT_VERSION,
            }}
            return post_json("/pc/register", payload)


        def uninstall_and_delete():
            try:
                post_json("/pc/uninstall", {{"pair_token": PAIR_TOKEN, "device_token": DEVICE_TOKEN}}, timeout=10)
            except Exception as exc:
                print("Relay uninstall error:", exc)
            remove_autostart()
            self_delete()


        def run_qwen_task(prompt, command_id=""):
            if command_id:
                task_step(command_id, "run_qwen_task")
            ok, result_text, error_text = run_local_task(prompt)
            if ok is not None:
                return ok, result_text, error_text

            preflight_ok, preflight_note, preflight_error = maybe_prepare_browser_task(prompt, command_id=command_id)
            if preflight_ok is False:
                if command_id:
                    task_note_fallback(command_id, preflight_error)
                return False, "", preflight_error
            if preflight_ok is True and preflight_note:
                prompt = preflight_note + "\\n\\nТекущая задача после подготовки:\\n" + prompt

            header = mission_header(prompt, command_id=command_id)
            if header:
                prompt = header + "\\n\\n" + prompt

            if command_id:
                send_progress(command_id, "compact", "Запускаю быстрый проход с минимально достаточным планом.")
            ok, result_text, error_text = run_qwen_pass(prompt, mode="compact")
            if ok and not result_needs_retry(result_text):
                return True, maybe_trim_result(result_text), ""

            if command_id:
                send_progress(command_id, "deep", "Быстрый проход недостаточен, перехожу к углублённому выполнению.")
            retry_ok, retry_text, retry_error = run_qwen_pass(prompt, mode="deep")
            if retry_ok:
                return True, maybe_trim_result(retry_text), ""
            if ok and result_text:
                return True, maybe_trim_result(result_text), ""
            return False, maybe_trim_result(retry_text or result_text), retry_error or error_text


        def run_qwen_pass(prompt, mode="compact"):
            qwen_bin = DEFAULT_QWEN_BIN
            if shutil.which(qwen_bin) is None:
                return False, "", f"Не найден {{qwen_bin}}. Установите Qwen CLI на этом ПК."

            wrapped_prompt = build_agent_prompt(prompt, mode=mode, command_id=command_id)
            timeout = COMPACT_TIMEOUT if mode == "compact" else DEEP_TIMEOUT
            cmd = [qwen_bin, "-p", wrapped_prompt, "--output-format", "json", "--yolo", "--auth-type", "qwen-oauth"]
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=str(ensure_work_dir()),
            )
            raw = (proc.stdout or "").strip()
            if proc.returncode != 0:
                return False, raw, (proc.stderr or "Qwen завершился с ошибкой").strip()

            parsed = parse_qwen_result(raw)
            if parsed:
                return True, parsed, ""
            if raw:
                return True, raw, ""
            return False, "", (proc.stderr or "Qwen не вернул результат").strip()


        def build_agent_prompt(prompt, mode="compact", command_id=""):
            work_dir = ensure_work_dir()
            script_path = Path(__file__).resolve()
            task_state = summarize_task_state(command_id) if command_id else ""
            task_type = extract_task_type(prompt)
            profile = "экономный проход" if mode == "compact" else "углублённый проход"
            extra = (
                "Сначала пробуй самый короткий путь решения. Не делай лишних шагов. "
                "Если нужна команда, выполни только минимально достаточный набор."
                if mode == "compact"
                else "Если первый проход не справился, добей задачу до рабочего результата. "
                "Проверяй вывод команд, исправляй ошибки и доводи до завершения."
            )
            state_block = f"Текущее состояние: {{task_state}}\\n" if task_state else ""
            local_profile = local_agent_profile(task_type)
            output_rules = local_agent_output_rules(task_type)
            return (
                "Ты локальный агент управления ПК. Твоя цель: надёжно завершать задачи на этом компьютере с минимальной хрупкостью.\\n\\n"
                f"Профиль: {{profile}}. {{extra}}\\n"
                f"Тип локальной миссии: {{task_type}}. {{local_profile}}\\n"
                "Правила работы: сначала оцени состояние, затем сделай короткий рабочий план, затем выполняй шаги с проверкой. "
                "Предпочитай самый устойчивый слой: shell или browser/CDP, затем хоткеи, и только потом координатные клики. "
                "GUI-задачи не выполняй вслепую: используй inspect, OCR, активное окно, URL, вкладки браузера и вывод tools. "
                "Не повторяй один и тот же сбойный шаг без новой тактики. Перед финалом сверь результат с success checks из supervisor-блока.\\n"
                "Tools, которые можно вызывать через shell:\\n"
                f"- python {{shlex.quote(str(script_path))}} tool inspect | screenshot | ocr\\n"
                f"- python {{shlex.quote(str(script_path))}} tool camera-snapshot | camera-describe 'что видно'\\n"
                f"- python {{shlex.quote(str(script_path))}} tool ensure-browser | open-browser | focus-address | browser-status | browser-tabs\\n"
                f"- python {{shlex.quote(str(script_path))}} tool navigate-url https://example.com\\n"
                f"- python {{shlex.quote(str(script_path))}} tool youtube-search minecraft letsplay\\n"
                f"- python {{shlex.quote(str(script_path))}} tool desktop | switch-window | minimize-window | close-window | open-search\\n"
                f"- python {{shlex.quote(str(script_path))}} tool click 0.5 0.5 | doubleclick 0.5 0.5 | type 'текст'\\n"
                f"- python {{shlex.quote(str(script_path))}} tool press enter | hotkey win+d | scroll -600 | open https://example.com | wait 2\\n"
                "Координаты 0..1 относительные. После важного шага делай проверку. "
                "Если есть browser-status или browser-tabs, используй их как более надёжный источник, чем OCR.\\n"
                f"{{output_rules}} "
                "В разделе Проверка опиши, чем именно подтверждён результат. Если задача не завершена, в Итог пиши честный блокер и ближайший рабочий следующий шаг.\\n\\n"
                f"Окружение: cwd={{work_dir}}; os={{platform.platform()}}; host={{socket.gethostname()}}; python={{sys.version.split()[0]}}\\n"
                f"{{state_block}}"
                f"Запрос пользователя:\\n{{prompt}}"
            )


        def maybe_trim_result(text):
            text = (text or "").strip()
            if len(text) <= RESULT_SOFT_LIMIT:
                return text
            head = text[:RESULT_SOFT_LIMIT].rstrip()
            return head + "\\n\\n[Результат сокращён на клиенте: вывод был слишком длинным.]"


        def result_needs_retry(text):
            text = (text or "").strip()
            if not text:
                return True
            if len(text) < 60:
                return True
            weak_markers = (
                "не могу",
                "не удалось",
                "недостаточно данных",
                "нужно больше информации",
                "я не могу выполнить",
                "я не имею доступа",
                "как ai",
                "как языковая модель",
            )
            lowered = text.lower()
            if any(marker in lowered for marker in weak_markers):
                return True
            required_sections = ("план:", "действия:", "проверка:", "итог:")
            present = sum(1 for section in required_sections if section in lowered)
            return present < 3


        def run_local_task(prompt):
            command = extract_shell_command(prompt)
            if not command:
                return None, "", ""
            return run_shell_command(command)


        def extract_shell_command(prompt):
            text = (prompt or "").strip()
            if not text:
                return ""
            lowered = text.lower()
            for prefix in EXPLICIT_SHELL_PREFIXES:
                if lowered.startswith(prefix):
                    return text[len(prefix):].strip()
            if "\\n" in text:
                return ""
            compact = re.sub(r"\\s+", " ", text.strip())
            lowered_compact = compact.lower()
            if any(re.match(pattern, lowered_compact) for pattern in FAST_COMMAND_PATTERNS):
                return compact
            return ""


        def run_shell_command(command):
            shell, flag = resolve_shell()
            header = f"[local-shell] {{command_preview(command)}}"
            proc = subprocess.run(
                [shell, flag, command],
                capture_output=True,
                text=True,
                timeout=240,
                cwd=str(ensure_work_dir()),
            )
            stdout = (proc.stdout or "").strip()
            stderr = (proc.stderr or "").strip()
            parts = [header, f"exit_code={{proc.returncode}}"]
            if stdout:
                parts.append("stdout:\\n" + stdout)
            if stderr:
                parts.append("stderr:\\n" + stderr)
            text = "\\n\\n".join(parts).strip()
            return proc.returncode == 0, maybe_trim_result(text), stderr


        def resolve_shell():
            if os.name == "nt":
                pwsh = shutil.which("pwsh")
                if pwsh:
                    return pwsh, "-Command"
                return os.environ.get("COMSPEC", "cmd.exe"), "/c"
            return os.environ.get("SHELL", "/bin/sh"), "-lc"


        def parse_qwen_result(raw):
            raw = (raw or "").strip()
            if not raw:
                return ""
            try:
                data = json.loads(raw)
                if isinstance(data, list):
                    for item in reversed(data):
                        if isinstance(item, dict) and item.get("type") == "result":
                            return item.get("result", "")
                if isinstance(data, dict):
                    return data.get("result", "")
            except json.JSONDecodeError:
                pass

            for line in raw.splitlines():
                line = line.strip()
                if not line or line[0] not in "[{{":
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(data, list):
                    for item in reversed(data):
                        if isinstance(item, dict) and item.get("type") == "result":
                            return item.get("result", "")
                if isinstance(data, dict) and "result" in data:
                    return data.get("result", "")
            return raw


        def main():
            choice = consent_prompt()
            if choice == "c":
                uninstall_and_delete()
                return

            try:
                response = register()
                if not response.get("ok"):
                    print("Подключение отклонено relay:", response)
                    return
            except Exception as exc:
                print("Не удалось зарегистрировать ПК:", exc)
                return

            try:
                print(install_autostart())
            except Exception as exc:
                print("Не удалось включить автозапуск:", exc)

            print("Ваш ПК подключён к QwenClaw.")
            print("Окно будет появляться при каждом запуске клиента.")
            print("Ожидаю задачи от бота...")

            while True:
                try:
                    payload = get_json("/pc/poll", {{"device_token": DEVICE_TOKEN}}, timeout=90)
                except urllib.error.HTTPError as exc:
                    print("Relay HTTP error:", exc)
                    time.sleep(POLL_INTERVAL)
                    continue
                except Exception as exc:
                    print("Ошибка опроса relay:", exc)
                    time.sleep(POLL_INTERVAL)
                    continue

                command = payload.get("command")
                if not command:
                    time.sleep(int(payload.get("retry_after", POLL_INTERVAL)))
                    continue

                prompt = command.get("prompt", "")
                command_id = command.get("command_id", "")
                kind = command.get("kind", "chat")
                print("\\nПолучена задача:", command_id)
                print(prompt)

                try:
                    if kind == "inspect":
                        send_progress(command_id, "inspect", "Осматриваю экран и читаю видимый текст.")
                        inspect_payload = build_inspect_report()
                        ok = bool(inspect_payload.get("ok"))
                        result_text = inspect_payload.get("result_text", "")
                        error_text = inspect_payload.get("error_text", "")
                        attachment = inspect_payload.get("attachment", {{}})
                    elif kind == "camera_snapshot":
                        send_progress(command_id, "camera", "Получаю снимок с камеры.")
                        camera_payload = build_camera_snapshot_report()
                        ok = bool(camera_payload.get("ok"))
                        result_text = camera_payload.get("result_text", "")
                        error_text = camera_payload.get("error_text", "")
                        attachment = camera_payload.get("attachment", {{}})
                    elif kind == "camera_describe":
                        ok, result_text, error_text, attachment = describe_camera_scene(prompt, command_id)
                    else:
                        send_progress(command_id, "planning", "Смотрю текущее состояние ПК и строю план выполнения.")
                        ok, result_text, error_text = run_qwen_task(prompt, command_id)
                        attachment = {{}}
                except Exception as exc:
                    ok, result_text, error_text = False, "", str(exc)
                    attachment = {{}}

                try:
                    send_progress(command_id, "finalizing", "Отправляю итог выполнения в Telegram.")
                    post_json(
                        "/pc/result",
                        {{
                            "device_token": DEVICE_TOKEN,
                            "command_id": command_id,
                            "ok": ok,
                            "result_text": result_text,
                            "error_text": error_text,
                            "attachment": attachment,
                        }},
                    )
                except Exception as exc:
                    print("Не удалось отправить результат:", exc)
                    time.sleep(POLL_INTERVAL)


        if __name__ == "__main__":
            if len(sys.argv) > 1 and sys.argv[1] == "tool":
                raise SystemExit(run_computer_tool(sys.argv[2:]))
            main()
        """
    )
    return script
