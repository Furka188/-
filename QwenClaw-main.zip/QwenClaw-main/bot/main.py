"""QwenBot — Personal AI assistant via Telegram + Qwen Code CLI."""

import asyncio
from html import escape
import logging
import sys
from datetime import datetime
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    BotCommand,
    FSInputFile,
)
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.exceptions import TelegramBadRequest

from app_startup import start_runtime
import config
from assistant_actions import (
    AssistantActionError,
    battery_status,
    clipboard_get,
    clipboard_set,
    device_info,
    format_json_block,
    location_info,
    open_url,
    phone_status,
    set_brightness,
    set_volume,
    speak_text,
    torch_set,
    wifi_info,
    wifi_set,
)
from chat_intelligence import analyze_chat_request
from chat_prompting import (
    QUICK_TEMPLATES,
    REPLY_MODES,
    build_chat_prompt as compose_chat_prompt,
    learn_preferences_from_text,
)
from config import BOT_TOKEN, LEGACY_ADMIN_CHAT_ID, MESSAGE_QUEUE_MAX, USER_REQUEST_LIMIT, USER_REQUEST_WINDOW_HOURS
from db import (
    bind_chat_user,
    create_session,
    delete_pc_device,
    get_active_sessions,
    get_bound_user,
    get_favorite_sessions,
    get_pc_device,
    get_pc_devices,
    get_quota_usage,
    get_session,
    quota_remaining,
    record_request,
    save_message,
    search_history,
    set_session_active,
    set_session_done,
    set_session_idle,
    toggle_session_favorite,
    unbind_chat_user,
    update_session,
)
from qwen_runner import (
    active_count,
    cancel_task,
    get_task_snapshot,
    is_busy,
    queue_length,
    run_qwen,
)
from formatting import md_to_telegram_html, split_message
from media import prepare_message_media
from pc_control import build_pc_bootstrap_caption, provision_pc_pairing, queue_pc_camera, queue_pc_chat, queue_pc_inspect
from pc_prompting import build_pc_clarification_request
from scheduler import _load_schedules
from user_profile import learn_device_profile_from_text

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("bot")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Track which session user is focused on
user_focus: dict[int, str] = {}  # chat_id -> session_id

# Track pending setup/auth state
_awaiting_setup: dict[int, str] = {}  # chat_id -> what we're waiting for (e.g. "groq_key")
_awaiting_password: set[int] = set()
chat_reply_mode: dict[int, str] = {}  # chat_id -> mode
session_reply_mode: dict[str, str] = {}  # session_id -> mode
pending_template: dict[int, str] = {}  # chat_id -> one-shot template
pc_selected_device: dict[int, str] = {}  # chat_id -> device_id for PC panel
pc_chat_device: dict[int, str] = {}  # chat_id -> device_id when messages go to PC
pc_progress_cache: dict[str, tuple[str, str, datetime]] = {}  # command_id -> (stage, message, ts)

SESSIONS_PER_PAGE = 5
DEFAULT_REPLY_MODE = "normal"
# ==================== Security ====================

def _is_password_mode() -> bool:
    return config.password_auth_enabled()


def _owner_id(chat_id: int) -> str | None:
    if _is_password_mode():
        return get_bound_user(chat_id)
    if LEGACY_ADMIN_CHAT_ID and chat_id == LEGACY_ADMIN_CHAT_ID:
        return "admin"
    return None


def _is_allowed_chat(chat_id: int) -> bool:
    return _owner_id(chat_id) is not None


def is_admin(message: Message) -> bool:
    return _is_allowed_chat(message.chat.id)


def is_admin_cb(callback: CallbackQuery) -> bool:
    return _is_allowed_chat(callback.message.chat.id)


def _auth_text() -> str:
    if _is_password_mode():
        return (
            "<b>QwenClaw</b>\n\n"
            "Введи пароль профиля одним сообщением. После входа откроется меню.\n\n"
            "Поддерживается несколько профилей, история и лимиты разделены."
        )
    return "<b>QwenClaw</b>\n\nДоступ не настроен. Добавь USER_PASSWORDS или TELEGRAM_CHAT_ID в .env."


def build_auth_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="ℹ️ Что это", callback_data="auth_info")]])


def build_pc_menu(owner_id: str, selected_device_id: str | None = None) -> InlineKeyboardMarkup:
    devices = get_pc_devices(owner_id)
    buttons: list[list[InlineKeyboardButton]] = []

    if devices:
        for device in devices[:8]:
            marker = "👉 " if device["device_id"] == selected_device_id else ""
            status = "🟢" if device.get("status") == "connected" else "🟡"
            label = device.get("name") or f"ПК {device['device_id']}"
            buttons.append([InlineKeyboardButton(
                text=f"{marker}{status} {label[:32]}",
                callback_data=f"pc_select:{device['device_id']}",
            )])

        target_id = selected_device_id or devices[0]["device_id"]
        buttons.append([
            InlineKeyboardButton(text="💬 Чат", callback_data=f"pc_chat:{target_id}"),
            InlineKeyboardButton(text="🗑 Удалить с ПК", callback_data=f"pc_delete:{target_id}"),
        ])

    buttons.append([InlineKeyboardButton(text="🔗 Подключить ПК", callback_data="pc_connect")])
    buttons.append([InlineKeyboardButton(text="ℹ️ Что доступно", callback_data="pc_info")])
    buttons.append([InlineKeyboardButton(text="🏠 Меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def build_pc_chat_keyboard(device_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🖥 Управление ПК", callback_data="pc_menu"),
            InlineKeyboardButton(text="📸 Экран", callback_data=f"pc_inspect:{device_id}"),
            InlineKeyboardButton(text="📷 Камера", callback_data=f"pc_camera:{device_id}"),
            InlineKeyboardButton(text="🛑 Выйти из чата", callback_data="pc_chat_exit"),
        ],
        [InlineKeyboardButton(text="🗑 Удалить с ПК", callback_data=f"pc_delete:{device_id}")],
    ])


# ==================== Keyboards ====================

def build_main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="💬 Чат", callback_data="menu"),
            InlineKeyboardButton(text="🖥 ПК", callback_data="pc_menu"),
        ],
        [
            InlineKeyboardButton(text="➕ Новый диалог", callback_data="new_session"),
            InlineKeyboardButton(text="👉 Текущий", callback_data="current_session"),
        ],
        [
            InlineKeyboardButton(text="📋 Диалоги", callback_data="sessions:0"),
            InlineKeyboardButton(text="⭐ Избранное", callback_data="favorites"),
        ],
        [
            InlineKeyboardButton(text="⚡ Шаблоны", callback_data="templates"),
            InlineKeyboardButton(text="🎛 Режим", callback_data="reply_mode"),
        ],
        [
            InlineKeyboardButton(text="⚙️ Задачи", callback_data="tasks"),
            InlineKeyboardButton(text="📊 Статус", callback_data="status"),
        ],
        [
            InlineKeyboardButton(text="🧠 Ассистент", callback_data="assistant"),
            InlineKeyboardButton(text="❓ Справка", callback_data="help"),
        ],
        [
            InlineKeyboardButton(text="🗑 Закрыть всё", callback_data="close_all"),
            InlineKeyboardButton(text="🔒 Выйти", callback_data="logout"),
        ],
    ])


def build_templates_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Коротко", callback_data="template:brief"),
            InlineKeyboardButton(text="Подробно", callback_data="template:deep"),
        ],
        [
            InlineKeyboardButton(text="План", callback_data="template:plan"),
            InlineKeyboardButton(text="Код", callback_data="template:code"),
        ],
        [
            InlineKeyboardButton(text="Объясни", callback_data="template:explain"),
            InlineKeyboardButton(text="Исправь", callback_data="template:fix"),
        ],
        [
            InlineKeyboardButton(text="Команды", callback_data="template:commands"),
            InlineKeyboardButton(text="Суммарно", callback_data="template:summary"),
        ],
        [InlineKeyboardButton(text="🏠 Меню", callback_data="menu")],
    ])


def build_mode_menu(current_mode: str) -> InlineKeyboardMarkup:
    labels = {
        "normal": "Обычный",
        "brief": "Коротко",
        "deep": "Подробно",
        "plan": "План",
        "code": "Код",
    }

    def item(mode: str) -> InlineKeyboardButton:
        prefix = "• " if mode == current_mode else ""
        return InlineKeyboardButton(text=f"{prefix}{labels[mode]}", callback_data=f"mode:{mode}")

    return InlineKeyboardMarkup(inline_keyboard=[
        [item("normal"), item("brief")],
        [item("deep"), item("plan")],
        [item("code")],
        [InlineKeyboardButton(text="🏠 Меню", callback_data="menu")],
    ])


def build_assistant_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="\ud83d\udcf1 \u0421\u0442\u0430\u0442\u0443\u0441", callback_data="phone:status"),
            InlineKeyboardButton(text="\ud83d\udd0b \u0411\u0430\u0442\u0430\u0440\u0435\u044f", callback_data="phone:battery"),
            InlineKeyboardButton(text="\ud83d\udcf6 Wi-Fi", callback_data="phone:wifi"),
        ],
        [
            InlineKeyboardButton(text="\ud83d\udccd \u041b\u043e\u043a\u0430\u0446\u0438\u044f", callback_data="phone:location"),
            InlineKeyboardButton(text="\ud83d\udcfb \u0423\u0441\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e", callback_data="phone:device"),
            InlineKeyboardButton(text="\ud83d\udccb \u0411\u0443\u0444\u0435\u0440", callback_data="phone:clipboard_get"),
        ],
        [
            InlineKeyboardButton(text="\ud83d\udd26 ON", callback_data="phone:torch:on"),
            InlineKeyboardButton(text="\ud83d\udd26 OFF", callback_data="phone:torch:off"),
            InlineKeyboardButton(text="\ud83d\udcf6 OFF", callback_data="phone:wifi:off"),
        ],
        [
            InlineKeyboardButton(text="\ud83d\udcf6 ON", callback_data="phone:wifi:on"),
            InlineKeyboardButton(text="\ud83d\udee0 \u041c\u0435\u043d\u044e", callback_data="menu"),
        ],
    ])


def build_task_keyboard(request_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="\u23f9 \u0421\u0442\u043e\u043f", callback_data=f"cancel_task:{request_id}"),
            InlineKeyboardButton(text="\ud83d\udcca \u0421\u0442\u0430\u0442\u0443\u0441", callback_data="status"),
        ],
        [
            InlineKeyboardButton(text="\ud83d\udc49 \u0422\u0435\u043a\u0443\u0449\u0438\u0439", callback_data="current_session"),
            InlineKeyboardButton(text="\ud83d\udccb \u0421\u0435\u0441\u0441\u0438\u0438", callback_data="sessions:0"),
        ],
        [
            InlineKeyboardButton(text="\u2699 \u0417\u0430\u0434\u0430\u0447\u0438", callback_data="tasks"),
            InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu"),
        ]
    ])


def build_result_keyboard(session_id: str | None = None) -> InlineKeyboardMarkup:
    buttons = [
        [
            InlineKeyboardButton(text="➕ Новый", callback_data="new_session"),
            InlineKeyboardButton(text="👉 Текущий", callback_data="current_session"),
        ],
        [
            InlineKeyboardButton(text="🎛 Режим", callback_data="reply_mode"),
            InlineKeyboardButton(text="📋 Диалоги", callback_data="sessions:0"),
        ],
    ]
    if session_id:
        buttons.insert(1, [
            InlineKeyboardButton(text="⭐ Избранное", callback_data=f"favorite:{session_id}"),
            InlineKeyboardButton(text="❌ Закрыть диалог", callback_data=f"close:{session_id}"),
        ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def build_sessions_keyboard(sessions: list[dict], page: int = 0, focus_id: str = None) -> InlineKeyboardMarkup:
    total = len(sessions)
    start = page * SESSIONS_PER_PAGE
    end = start + SESSIONS_PER_PAGE
    page_sessions = sessions[start:end]

    buttons = []
    for s in page_sessions:
        icon = {"active": "\u26a1", "idle": "\ud83d\udca4"}.get(s["status"], "\u2753")
        marker = "\ud83d\udc49 " if s["session_id"] == focus_id else ""
        favorite = "⭐ " if s.get("favorite") else ""
        name = s["name"][:28] + ".." if len(s["name"]) > 28 else s["name"]

        buttons.append([
            InlineKeyboardButton(
                text=f"{marker}{favorite}{icon} {name}",
                callback_data=f'switch:{s["session_id"]}',
            ),
            InlineKeyboardButton(text="\u274c", callback_data=f'close:{s["session_id"]}'),
        ])

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="\u2b05 \u041d\u0430\u0437\u0430\u0434", callback_data=f"sessions:{page - 1}"))
    if end < total:
        nav.append(InlineKeyboardButton(text="\u0412\u043f\u0435\u0440\u0451\u0434 \u27a1", callback_data=f"sessions:{page + 1}"))
    if nav:
        buttons.append(nav)

    buttons.append([InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ==================== Text extraction ====================

async def extract_text(message: Message):
    """Prepare message text plus multimodal attachments for Qwen.

    Returns:
        MediaPayload with text, attachments, cleanup paths and transcript info.
    """
    return await prepare_message_media(message, bot)


# ==================== Commands ====================

@dp.message(Command("start"))
async def cmd_start(message: Message):
    if not is_admin(message):
        if _is_password_mode():
            _awaiting_password.add(message.chat.id)
            await message.reply(_auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
        return

    owner_id = _owner_id(message.chat.id) or "unknown"
    remaining, used = quota_remaining(owner_id, USER_REQUEST_LIMIT, USER_REQUEST_WINDOW_HOURS)
    voice_status = "✅ Groq" if config.GROQ_API_KEY else "⚠️ off"
    await message.reply(
        f"<b>QwenClaw</b>\n\n"
        f"Профиль: <code>{escape(owner_id)}</code>\n"
        f"Лимит: {used}/{USER_REQUEST_LIMIT} за {USER_REQUEST_WINDOW_HOURS}ч\n"
        f"Осталось: {remaining}\n"
        f"Голос: {voice_status}",
        parse_mode=ParseMode.HTML,
        reply_markup=build_main_menu(),
    )

@dp.message(Command("menu"))
async def cmd_menu(message: Message):
    if not is_admin(message):
        if _is_password_mode():
            _awaiting_password.add(message.chat.id)
            await message.reply(_auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
        return
    await _send_home(message.chat.id)


@dp.message(Command("new"))
async def cmd_new(message: Message):
    if not is_admin(message):
        return
    user_focus[message.chat.id] = "__force_new__"
    await message.reply(
        "Отправь первое сообщение. Оно начнёт новый диалог.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="\u274c \u041e\u0442\u043c\u0435\u043d\u0430", callback_data="cancel_new")],
        ]),
    )


@dp.message(Command("sessions"))
async def cmd_sessions(message: Message):
    if not is_admin(message):
        return
    owner_id = _owner_id(callback.message.chat.id)
    sessions = get_active_sessions(owner_id) if owner_id else []
    if not sessions:
        await message.reply(
            "Активных диалогов нет.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="\u2795 \u041d\u043e\u0432\u0430\u044f", callback_data="new_session")],
                [InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu")],
            ]),
        )
        return

    focus_id = user_focus.get(message.chat.id)
    await message.reply(
        f"<b>Диалоги</b> ({len(sessions)} активных)",
        parse_mode=ParseMode.HTML,
        reply_markup=build_sessions_keyboard(sessions, 0, focus_id),
    )


@dp.message(Command("help"))
async def cmd_help(message: Message):
    if not is_admin(message):
        return
    await message.reply(_help_text(), parse_mode=ParseMode.HTML, reply_markup=build_main_menu())


@dp.message(Command("mode"))
async def cmd_mode(message: Message):
    if not is_admin(message):
        return
    current_mode = _get_current_mode(message.chat.id)
    await message.reply(
        _mode_text(current_mode),
        parse_mode=ParseMode.HTML,
        reply_markup=build_mode_menu(current_mode),
    )


@dp.message(Command("favorites"))
async def cmd_favorites(message: Message):
    if not is_admin(message):
        return
    await _send_favorites(message.chat.id)


@dp.message(Command("find"))
@dp.message(Command("search"))
async def cmd_search(message: Message):
    if not is_admin(message):
        return
    query = _command_args(message)
    if not query:
        await message.reply("Использование: /find слово или фраза", reply_markup=build_main_menu())
        return
    await _send_search_results(message.chat.id, query)


@dp.message(Command("status"))
async def cmd_status(message: Message):
    if not is_admin(message):
        return
    await _send_status(message.chat.id)


@dp.message(Command("tasks"))
async def cmd_tasks(message: Message):
    if not is_admin(message):
        return
    await _send_tasks_panel(message.chat.id)


@dp.message(Command("assistant"))
@dp.message(Command("phone"))
async def cmd_assistant(message: Message):
    if not is_admin(message):
        return
    await message.reply(
        "<b>Ассистент телефона</b>\n\n"
        "Быстрые действия доступны кнопками ниже.\n"
        "Текстовые команды: /say, /clip, /open, /wifi, /torch, /brightness, /volume, /location",
        parse_mode=ParseMode.HTML,
        reply_markup=build_assistant_menu(),
    )


@dp.message(Command("pc"))
async def cmd_pc(message: Message):
    if not is_admin(message):
        return
    selected_device_id = pc_selected_device.get(message.chat.id)
    await message.reply(
        "<b>Управление ПК</b>\n\nОткрой список устройств или выпусти новый python-клиент для подключения.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_menu(_owner_id(message.chat.id) or "unknown", selected_device_id),
    )


@dp.message(Command("say"))
async def cmd_say(message: Message):
    if not is_admin(message):
        return
    await _run_assistant_text_action(message, speak_text, _command_args(message))


@dp.message(Command("clip"))
async def cmd_clip(message: Message):
    if not is_admin(message):
        return
    await _run_assistant_text_action(message, clipboard_set, _command_args(message))


@dp.message(Command("open"))
async def cmd_open(message: Message):
    if not is_admin(message):
        return
    await _run_assistant_text_action(message, open_url, _command_args(message))


@dp.message(Command("wifi"))
async def cmd_wifi(message: Message):
    if not is_admin(message):
        return
    arg = _command_args(message).lower()
    if arg not in {"on", "off"}:
        await message.reply("Использование: /wifi on|off")
        return
    await _run_assistant_text_action(message, wifi_set, arg == "on")


@dp.message(Command("torch"))
async def cmd_torch(message: Message):
    if not is_admin(message):
        return
    arg = _command_args(message).lower()
    if arg not in {"on", "off"}:
        await message.reply("Использование: /torch on|off")
        return
    await _run_assistant_text_action(message, torch_set, arg == "on")


@dp.message(Command("brightness"))
async def cmd_brightness(message: Message):
    if not is_admin(message):
        return
    args = _command_args(message)
    if not args:
        await message.reply("Использование: /brightness 0..255|auto")
        return
    await _run_assistant_text_action(message, set_brightness, args)


@dp.message(Command("volume"))
async def cmd_volume(message: Message):
    if not is_admin(message):
        return
    args = _command_args(message).split()
    if len(args) != 2:
        await message.reply("Использование: /volume <stream> <value>")
        return
    await _run_assistant_text_action(message, set_volume, args[0], args[1])


@dp.message(Command("location"))
async def cmd_location(message: Message):
    if not is_admin(message):
        return
    await _run_assistant_json_action(message, "Локация", location_info)


@dp.message(Command("update"))
async def cmd_update(message: Message):
    if not is_admin(message):
        return

    status_msg = await message.reply("Checking for updates...")

    try:
        # git fetch and check
        proc = await asyncio.create_subprocess_exec(
            "git", "fetch", "origin", "main",
            cwd=str(config.PROJECT_ROOT),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()

        # Check if behind
        proc = await asyncio.create_subprocess_exec(
            "git", "rev-list", "--count", "HEAD..origin/main",
            cwd=str(config.PROJECT_ROOT),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        behind = int(stdout.decode().strip() or "0")

        if behind == 0:
            await status_msg.edit_text("Already up to date.")
            return

        await status_msg.edit_text(
            f"Found {behind} new commit(s). Updating...",
        )

        # git pull
        proc = await asyncio.create_subprocess_exec(
            "git", "pull", "origin", "main",
            cwd=str(config.PROJECT_ROOT),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()

        if proc.returncode != 0:
            error = stderr.decode()[:500]
            await status_msg.edit_text(f"Update failed:\n<pre>{error}</pre>", parse_mode=ParseMode.HTML)
            return

        # pip install (in case requirements changed)
        proc = await asyncio.create_subprocess_exec(
            str(config.PROJECT_ROOT / ".venv" / "bin" / "pip"),
            "install", "-q", "-r",
            str(config.PROJECT_ROOT / "bot" / "requirements.txt"),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()

        await status_msg.edit_text(
            f"Updated ({behind} commits). Restarting...",
        )

        # Restart via systemd
        proc = await asyncio.create_subprocess_exec(
            "sudo", "systemctl", "restart", "qwenbot",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        # If restart works, bot process dies here and comes back up

    except Exception as e:
        logger.error(f"Update failed: {e}", exc_info=True)
        try:
            await status_msg.edit_text(f"Update error: {e}")
        except Exception:
            pass


@dp.message(Command("setup"))
async def cmd_setup(message: Message):
    if not is_admin(message):
        return

    buttons = []
    if not config.GROQ_API_KEY:
        buttons.append([InlineKeyboardButton(text="\ud83c\udf99 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c Groq \u043a\u043b\u044e\u0447 (\u0433\u043e\u043b\u043e\u0441)", callback_data="setup:groq")])
    else:
        buttons.append([InlineKeyboardButton(text="\ud83d\udd04 \u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c Groq \u043a\u043b\u044e\u0447", callback_data="setup:groq")])

    buttons.append([InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu")])

    voice_status = "on" if config.GROQ_API_KEY else "off"
    await message.reply(
        f"<b>Setup</b>\n\nVoice messages: {voice_status}",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )


@dp.callback_query(F.data == "setup:groq")
async def cb_setup_groq(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    _awaiting_setup[callback.message.chat.id] = "groq_key"
    await callback.message.edit_text(
        "<b>Groq API key setup</b>\n\n"
        "1. Go to https://console.groq.com/keys\n"
        "2. Create a free API key\n"
        "3. Send it here\n\n"
        "The key looks like: <code>gsk_...</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="\u274c \u041e\u0442\u043c\u0435\u043d\u0430", callback_data="setup:cancel")],
        ]),
    )
    await callback.answer()


@dp.callback_query(F.data == "setup:cancel")
async def cb_setup_cancel(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    _awaiting_setup.pop(callback.message.chat.id, None)
    await callback.message.edit_text("Настройка отменена.", reply_markup=build_main_menu())
    await callback.answer()


# ==================== Callback handlers ====================

@dp.callback_query(F.data == "menu")
async def cb_menu(callback: CallbackQuery):
    if not is_admin_cb(callback):
        if _is_password_mode():
            await callback.message.edit_text(_auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
        await callback.answer()
        return
    await _send_home(callback.message.chat.id, edit_message=callback.message)
    await callback.answer()


@dp.callback_query(F.data == "auth_info")
async def cb_auth_info(callback: CallbackQuery):
    await callback.message.edit_text(
        "<b>Вход</b>\n\n"
        "Отправь одним сообщением пароль нужного профиля. История, сессии и лимиты разделяются по профилям.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_auth_menu(),
    )
    await callback.answer()

@dp.callback_query(F.data == "logout")
async def cb_logout(callback: CallbackQuery):
    unbind_chat_user(callback.message.chat.id)
    user_focus.pop(callback.message.chat.id, None)
    _awaiting_password.add(callback.message.chat.id)
    await callback.message.edit_text(_auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
    await callback.answer("Выход выполнен")


@dp.callback_query(F.data == "pc_menu")
async def cb_pc_menu(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    selected_device_id = pc_selected_device.get(callback.message.chat.id)
    devices = get_pc_devices(owner_id)
    if not selected_device_id and devices:
        selected_device_id = devices[0]["device_id"]
        pc_selected_device[callback.message.chat.id] = selected_device_id
    selected = get_pc_device(owner_id, selected_device_id) if selected_device_id else None
    device_text = "Устройств пока нет. Нажми «Подключить ПК», чтобы получить уникальный python-клиент."
    if selected:
        last_seen = selected.get("last_seen_at") or "ещё не выходил на связь"
        device_text = (
            f"Выбрано: <b>{md_to_telegram_html(selected.get('name') or selected['device_id'])}</b>\n"
            f"ID: <code>{selected['device_id']}</code>\n"
            f"Статус: {md_to_telegram_html(selected.get('status') or 'unknown')}\n"
            f"Хост: {md_to_telegram_html(selected.get('hostname') or '—')}\n"
            f"Платформа: {md_to_telegram_html(selected.get('platform') or '—')}\n"
            f"Последний пинг: <code>{md_to_telegram_html(last_seen)}</code>"
        )
    await callback.message.edit_text(
        "<b>ПК</b>\n\n"
        "Каждый выданный python-файл имеет свой ID и токены для связи именно с этим ботом.\n\n"
        f"{device_text}",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_menu(owner_id, selected_device_id),
    )
    await callback.answer()

@dp.callback_query(F.data == "pc_info")
async def cb_pc_info(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    await callback.message.edit_text(
        "<b>Что доступно сейчас</b>\n\n"
        "• отдельный python-клиент под каждое подключение\n"
        "• уникальный ID и токен на каждый выданный файл\n"
        "• автозапуск клиента на ПК на уровне пользователя\n"
        "• обязательный запрос разрешения при каждом запуске\n"
        "• удаление связки и самоудаление клиента при вводе <code>c</code>\n"
        "• чат с ПК через relay и локальный Qwen CLI на стороне ПК\n"
        "• голосовые сообщения работают через обычную транскрипцию бота и уходят в ПК-чат как текст\n"
        "• лимиты 500 запросов на профиль с окном 24 часа\n\n"
        "Скрытый фоновый съём экрана, камера и невидимый контроль без локального подтверждения не включаются.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_menu(owner_id, pc_selected_device.get(callback.message.chat.id)),
    )
    await callback.answer()


@dp.callback_query(F.data == "pc_connect")
async def cb_pc_connect(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return

    device = provision_pc_pairing(owner_id, callback.message.chat.id)
    pc_selected_device[callback.message.chat.id] = device["device_id"]

    await bot.send_document(
        callback.message.chat.id,
        FSInputFile(device["script_path"]),
        caption=build_pc_bootstrap_caption(device),
        parse_mode=ParseMode.HTML,
    )
    await callback.message.edit_text(
        "<b>Файл подготовлен</b>\n\n"
        f"Для устройства <code>{device['device_id']}</code> отправлен отдельный python-клиент.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_menu(owner_id, device["device_id"]),
    )
    await callback.answer("Файл отправлен")


@dp.callback_query(F.data.startswith("pc_select:"))
async def cb_pc_select(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    device_id = callback.data.split(":", 1)[1]
    device = get_pc_device(owner_id, device_id)
    if not device:
        await callback.answer("Устройство не найдено", show_alert=True)
        return
    pc_selected_device[callback.message.chat.id] = device_id
    await cb_pc_menu(callback)


@dp.callback_query(F.data.startswith("pc_chat:"))
async def cb_pc_chat(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    device_id = callback.data.split(":", 1)[1]
    device = get_pc_device(owner_id, device_id)
    if not device:
        await callback.answer("Устройство не найдено", show_alert=True)
        return
    pc_selected_device[callback.message.chat.id] = device_id
    pc_chat_device[callback.message.chat.id] = device_id
    await callback.message.edit_text(
        f"<b>Чат с ПК</b>\n\n"
        f"Устройство: <b>{md_to_telegram_html(device.get('name') or device_id)}</b>\n"
        "Теперь все текстовые, голосовые, фото и видео сообщения будут уходить в локальный агент на ПК, пока ты не выйдешь из этого режима.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_chat_keyboard(device_id),
    )
    await callback.answer("Режим ПК-чата включён")


@dp.callback_query(F.data.startswith("pc_inspect:"))
async def cb_pc_inspect(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    device_id = callback.data.split(":", 1)[1]
    device = get_pc_device(owner_id, device_id)
    if not device:
        await callback.answer("Устройство не найдено", show_alert=True)
        return
    command = queue_pc_inspect(owner_id, device_id)
    await callback.message.reply(
        f"<b>Запрошен снимок экрана</b>\n\n"
        f"Устройство: <b>{md_to_telegram_html(device.get('name') or device_id)}</b>\n"
        f"Команда: <code>{command['command_id']}</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_chat_keyboard(device_id),
    )
    await callback.answer("Запрос отправлен")


@dp.callback_query(F.data.startswith("pc_camera:"))
async def cb_pc_camera(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    device_id = callback.data.split(":", 1)[1]
    device = get_pc_device(owner_id, device_id)
    if not device:
        await callback.answer("Устройство не найдено", show_alert=True)
        return
    command = queue_pc_camera(owner_id, device_id)
    await callback.message.reply(
        f"<b>Запрошен снимок камеры</b>\n\n"
        f"Устройство: <b>{md_to_telegram_html(device.get('name') or device_id)}</b>\n"
        f"Команда: <code>{command['command_id']}</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_chat_keyboard(device_id),
    )
    await callback.answer("Камера запрошена")


@dp.callback_query(F.data == "pc_chat_exit")
async def cb_pc_chat_exit(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    pc_chat_device.pop(callback.message.chat.id, None)
    await cb_pc_menu(callback)


@dp.callback_query(F.data.startswith("pc_delete:"))
async def cb_pc_delete(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    device_id = callback.data.split(":", 1)[1]
    device = get_pc_device(owner_id, device_id)
    if not device:
        await callback.answer("Устройство не найдено", show_alert=True)
        return
    await callback.message.edit_text(
        f"<b>Удалить устройство?</b>\n\n"
        f"{md_to_telegram_html(device.get('name') or device_id)}\n"
        "Команды будут очищены. На стороне ПК клиент удалится сам при следующем запуске и вводе c.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="🗑 Удалить", callback_data=f"pc_delete_confirm:{device_id}"),
                InlineKeyboardButton(text="↩ Назад", callback_data="pc_menu"),
            ],
        ]),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("pc_delete_confirm:"))
async def cb_pc_delete_confirm(callback: CallbackQuery):
    if not is_admin_cb(callback):
        await callback.answer()
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    device_id = callback.data.split(":", 1)[1]
    device = delete_pc_device(owner_id, device_id)
    if not device:
        await callback.answer("Устройство уже удалено", show_alert=True)
        return
    if pc_selected_device.get(callback.message.chat.id) == device_id:
        pc_selected_device.pop(callback.message.chat.id, None)
    if pc_chat_device.get(callback.message.chat.id) == device_id:
        pc_chat_device.pop(callback.message.chat.id, None)
    await callback.message.edit_text(
        f"Устройство <code>{device_id}</code> удалено.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_menu(owner_id, pc_selected_device.get(callback.message.chat.id)),
    )
    await callback.answer("Устройство удалено")

@dp.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await callback.message.edit_text(_help_text(), parse_mode=ParseMode.HTML, reply_markup=build_main_menu())
    await callback.answer()


@dp.callback_query(F.data == "reply_mode")
async def cb_reply_mode(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    current_mode = _get_current_mode(callback.message.chat.id)
    await callback.message.edit_text(
        _mode_text(current_mode),
        parse_mode=ParseMode.HTML,
        reply_markup=build_mode_menu(current_mode),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("mode:"))
async def cb_mode_set(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    mode = callback.data.split(":", 1)[1]
    if mode not in REPLY_MODES:
        await callback.answer("Неизвестный режим", show_alert=True)
        return

    focus_id = user_focus.get(callback.message.chat.id)
    if focus_id and focus_id != "__force_new__":
        session_reply_mode[focus_id] = mode
    else:
        chat_reply_mode[callback.message.chat.id] = mode

    await callback.message.edit_text(
        _mode_text(mode),
        parse_mode=ParseMode.HTML,
        reply_markup=build_mode_menu(mode),
    )
    await callback.answer(f"Режим: {mode}")


@dp.callback_query(F.data == "current_session")
async def cb_current_session(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await _send_current_session(callback.message.chat.id, edit_message=callback.message)
    await callback.answer()


@dp.callback_query(F.data == "favorites")
async def cb_favorites(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await _send_favorites(callback.message.chat.id, edit_message=callback.message)
    await callback.answer()


@dp.callback_query(F.data == "templates")
async def cb_templates(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await callback.message.edit_text(
        "<b>Быстрые шаблоны</b>\n\nВыбери шаблон. Он применится к следующему сообщению один раз.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_templates_menu(),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("template:"))
async def cb_template_set(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    template = callback.data.split(":", 1)[1]
    if template not in QUICK_TEMPLATES:
        await callback.answer("Неизвестный шаблон", show_alert=True)
        return
    pending_template[callback.message.chat.id] = template
    await callback.message.edit_text(
        f"<b>Шаблон включён</b>\n\nСледующее сообщение будет отправлено с шаблоном: <b>{template}</b>.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_templates_menu(),
    )
    await callback.answer(f"Шаблон: {template}")


@dp.callback_query(F.data == "assistant")
async def cb_assistant(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await callback.message.edit_text(
        "<b>Ассистент телефона</b>\n\n"
        "Управление устройством идёт локально через Termux API.",
        parse_mode=ParseMode.HTML,
        reply_markup=build_assistant_menu(),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("sessions:"))
async def cb_sessions(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    page = int(callback.data.split(":")[1])
    sessions = get_active_sessions(owner_id)

    if not sessions:
        await callback.message.edit_text(
            "Активных диалогов нет.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="\u2795 \u041d\u043e\u0432\u0430\u044f", callback_data="new_session")],
                [InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu")],
            ]),
        )
        await callback.answer()
        return

    focus_id = user_focus.get(callback.message.chat.id)
    await callback.message.edit_text(
        f"<b>Диалоги</b> ({len(sessions)} активных)",
        parse_mode=ParseMode.HTML,
        reply_markup=build_sessions_keyboard(sessions, page, focus_id),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("switch:"))
async def cb_switch(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    session_id = callback.data.split(":", 1)[1]
    session = get_session(owner_id, session_id)
    if not session:
        await callback.answer("Диалог не найден", show_alert=True)
        return

    user_focus[callback.message.chat.id] = session_id
    created = datetime.fromisoformat(session["created_at"]).strftime("%d.%m %H:%M")
    summary = session.get("summary", "") or "No description"
    if summary == "No description":
        summary = "Без описания"

    await callback.message.edit_text(
        f"<b>{session['name']}</b>\n\n"
        f"Статус: {session['status']}\n"
        f"Создан: {created}\n\n"
        f"<i>{summary[:150]}</i>\n\n"
        f"Диалог выбран. Отправь сообщение, чтобы продолжить.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="\ud83d\udccb \u0414\u0438\u0430\u043b\u043e\u0433\u0438", callback_data="sessions:0")],
            [InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu")],
        ]),
    )
    await callback.answer(f"Диалог: {session['name'][:30]}")


@dp.callback_query(F.data.startswith("close:"))
async def cb_close(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    session_id = callback.data.split(":", 1)[1]
    session = get_session(owner_id, session_id)
    if not session:
        await callback.answer("Диалог не найден", show_alert=True)
        return

    set_session_done(owner_id, session_id)

    if user_focus.get(callback.message.chat.id) == session_id:
        user_focus.pop(callback.message.chat.id, None)

    await callback.answer(f"Закрыт: {session['name'][:30]}", show_alert=True)

    owner_id = _owner_id(callback.message.chat.id)
    sessions = get_active_sessions(owner_id) if owner_id else []
    if sessions:
        focus_id = user_focus.get(callback.message.chat.id)
        await callback.message.edit_text(
            f"<b>Диалоги</b> ({len(sessions)} активных)\n"
            f"Закрыт: {session['name']}",
            parse_mode=ParseMode.HTML,
            reply_markup=build_sessions_keyboard(sessions, 0, focus_id),
        )
    else:
        await callback.message.edit_text(
            f"Закрыт: {session['name']}\nАктивных диалогов больше нет.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="\u2795 \u041d\u043e\u0432\u0430\u044f", callback_data="new_session")],
                [InlineKeyboardButton(text="\ud83c\udfe0 \u041c\u0435\u043d\u044e", callback_data="menu")],
            ]),
        )


@dp.callback_query(F.data == "new_session")
async def cb_new_session(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    user_focus[callback.message.chat.id] = "__force_new__"
    await callback.message.edit_text(
        "Отправь первое сообщение. Оно станет названием диалога.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="\u274c \u041e\u0442\u043c\u0435\u043d\u0430", callback_data="cancel_new")],
        ]),
    )
    await callback.answer()


@dp.callback_query(F.data == "cancel_new")
async def cb_cancel_new(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    user_focus.pop(callback.message.chat.id, None)
    await callback.message.edit_text("Отменено.", reply_markup=build_main_menu())
    await callback.answer()


@dp.callback_query(F.data == "close_all")
async def cb_close_all(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    sessions = get_active_sessions(owner_id)
    if not sessions:
        await callback.answer("Нет активных диалогов", show_alert=True)
        return

    await callback.message.edit_text(
        f"<b>Закрыть все {len(sessions)} диалогов?</b>\nЭто действие нельзя отменить.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="\u2705 \u0414\u0430, \u0437\u0430\u043a\u0440\u044b\u0442\u044c", callback_data="confirm_close_all"),
                InlineKeyboardButton(text="\u274c \u041e\u0442\u043c\u0435\u043d\u0430", callback_data="menu"),
            ],
        ]),
    )
    await callback.answer()


@dp.callback_query(F.data == "confirm_close_all")
async def cb_confirm_close_all(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    sessions = get_active_sessions(owner_id)
    for s in sessions:
        set_session_done(owner_id, s["session_id"])
    user_focus.pop(callback.message.chat.id, None)

    await callback.message.edit_text(
        f"Закрыто диалогов: {len(sessions)}.",
        reply_markup=build_main_menu(),
    )
    await callback.answer()


@dp.callback_query(F.data == "status")
async def cb_status(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await _send_status(callback.message.chat.id, edit_message=callback.message)
    await callback.answer()


@dp.callback_query(F.data == "tasks")
async def cb_tasks(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    await _send_tasks_panel(callback.message.chat.id, edit_message=callback.message)
    await callback.answer()


@dp.callback_query(F.data.startswith("cancel_task:"))
async def cb_cancel_task(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return

    request_id = callback.data.split(":", 1)[1]
    state = cancel_task(request_id, _owner_id(callback.message.chat.id))
    if state is None:
        await callback.answer("Задача уже завершена", show_alert=True)
        return

    try:
        await callback.message.edit_text(
            f"Задача <code>{request_id}</code> остановлена ({state}).",
            reply_markup=build_main_menu(),
            parse_mode=ParseMode.HTML,
        )
    except TelegramBadRequest:
        pass
    await callback.answer("Остановлено")


@dp.callback_query(F.data.startswith("favorite:"))
async def cb_favorite(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return
    owner_id = _owner_id(callback.message.chat.id)
    if not owner_id:
        await callback.answer()
        return
    session_id = callback.data.split(":", 1)[1]
    session = toggle_session_favorite(owner_id, session_id)
    if not session:
        await callback.answer("Диалог не найден", show_alert=True)
        return
    label = "добавлен в избранное" if session.get("favorite") else "убран из избранного"
    await _send_current_session(callback.message.chat.id, edit_message=callback.message)
    await callback.answer(label)


@dp.callback_query(F.data.startswith("phone:"))
async def cb_phone(callback: CallbackQuery):
    if not is_admin_cb(callback):
        return

    action = callback.data.split(":")
    try:
        if action[1] == "status":
            text = await phone_status()
        elif action[1] == "battery":
            text = format_json_block("Батарея", await battery_status())
        elif action[1] == "wifi" and len(action) == 2:
            text = format_json_block("Wi-Fi", await wifi_info())
        elif action[1] == "wifi" and len(action) == 3:
            text = await wifi_set(action[2] == "on")
        elif action[1] == "location":
            text = format_json_block("Локация", await location_info())
        elif action[1] == "device":
            text = format_json_block("Устройство", await device_info())
        elif action[1] == "clipboard_get":
            clip = await clipboard_get()
            text = f"<b>Буфер обмена</b>\n<pre>{escape(clip)}</pre>"
        elif action[1] == "torch" and len(action) == 3:
            text = await torch_set(action[2] == "on")
        else:
            text = "Неизвестное действие."
    except AssistantActionError as exc:
        text = f"Ошибка: {md_to_telegram_html(str(exc))}"

    await callback.message.edit_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=build_assistant_menu(),
    )
    await callback.answer()


@dp.callback_query(F.data == "noop")
async def cb_noop(callback: CallbackQuery):
    await callback.answer("Выполняется...")


# ==================== Main message handler ====================

@dp.message()
async def handle_message(message: Message):
    """Main handler: auth -> extract text -> route to session -> run Qwen."""

    if message.text and message.text.startswith("/"):
        return

    # Password auth for multi-user mode.
    if not is_admin(message):
        if _is_password_mode() and message.text:
            user_id = config.resolve_user_by_password(message.text.strip())
            if user_id:
                bind_chat_user(message.chat.id, user_id)
                _awaiting_password.discard(message.chat.id)
                await _send_home(message.chat.id)
            else:
                _awaiting_password.add(message.chat.id)
                await message.reply("Неверный пароль. Попробуй ещё раз.", reply_markup=build_auth_menu())
        elif _is_password_mode():
            _awaiting_password.add(message.chat.id)
            await message.reply(_auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
        return

    owner_id = _owner_id(message.chat.id)
    if not owner_id:
        return

    # Setup flow
    setup_state = _awaiting_setup.get(message.chat.id)
    if setup_state == "groq_key" and message.text:
        key = message.text.strip()
        if key.startswith("gsk_") and len(key) > 20:
            config.set_env_var("GROQ_API_KEY", key)
            config.reload_groq_key()
            _awaiting_setup.pop(message.chat.id, None)
            await message.reply(
                "Groq API key saved. Voice messages enabled.",
                reply_markup=build_main_menu(),
            )
        else:
            await message.reply(
                "Invalid key. It should start with <code>gsk_</code>",
                parse_mode=ParseMode.HTML,
            )
        return

    normalized = (message.text or "").strip().lower()
    if normalized in {"чат", "меню"}:
        await _send_home(message.chat.id)
        return
    if normalized in {"пк", "управление пк"}:
        selected_device_id = pc_selected_device.get(message.chat.id)
        await message.reply(
            "<b>ПК</b>\n\n"
            "Открой панель управления подключёнными устройствами или выпусти новый python-клиент для ПК.",
            parse_mode=ParseMode.HTML,
            reply_markup=build_pc_menu(owner_id, selected_device_id),
        )
        return

    media = await extract_text(message)
    text = media.text

    if text is None and (message.voice or message.audio):
        await message.reply(
            "Голосовые требуют Groq API ключ. Открой /setup.",
            reply_markup=build_main_menu(),
        )
        return

    if not text:
        await message.reply("Отправь текст, фото, голосовое, видео или кружок.")
        return

    pc_text = text
    if media.attachments:
        pc_text += "\n\n[В запросе были вложения. Этот relay передаёт на ПК текст и транскрипцию; сами файлы на ПК не отправляются.]"

    if await _maybe_handle_pc_chat(message, owner_id, pc_text):
        for path in media.cleanup_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                pass
        return

    if await _maybe_handle_local_assistant(message, text):
        for path in media.cleanup_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                pass
        return

    if media.transcript and (message.voice or message.audio):
        await message.reply(
            f"<i>🎙 Голос:</i> {md_to_telegram_html(media.transcript)}",
            parse_mode=ParseMode.HTML,
        )

    if media.attachments:
        text = text + "\n\n" + " ".join(f"@{path}" for path in media.attachments)

    remaining, used = quota_remaining(owner_id, USER_REQUEST_LIMIT, USER_REQUEST_WINDOW_HOURS)
    if remaining <= 0:
        for path in media.cleanup_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                pass
        await message.reply(
            f"Лимит исчерпан: {used}/{USER_REQUEST_LIMIT} за {USER_REQUEST_WINDOW_HOURS}ч. Попробуй позже.",
            reply_markup=build_main_menu(),
        )
        return

    force_new = user_focus.get(message.chat.id) == "__force_new__"
    if force_new:
        user_focus.pop(message.chat.id, None)
        session_id = None
        session_name = _derive_session_name(text)
    else:
        focus_id = user_focus.get(message.chat.id)
        if focus_id and focus_id != "__force_new__":
            session = get_session(owner_id, focus_id)
            if session and session["status"] != "done":
                session_id = focus_id
                session_name = session["name"]
            else:
                session_id = None
                session_name = _derive_session_name(text)
        else:
            session_id = None
            session_name = _derive_session_name(text)

    effective_mode = _get_current_mode(message.chat.id, session_id)
    template = pending_template.pop(message.chat.id, None)
    analysis = analyze_chat_request(text, has_attachments=bool(getattr(media, "attachments", None)))
    if analysis.clarification_request and not template:
        save_message(owner_id, "user", text, session_id)
        save_message(owner_id, "assistant", analysis.clarification_request, session_id)
        learn_preferences_from_text(owner_id, text)
        await message.reply(analysis.clarification_request, reply_markup=build_main_menu())
        return

    auto_mode = analysis.suggested_mode if effective_mode == "normal" and not template else effective_mode
    prompt = compose_chat_prompt(owner_id, text, auto_mode, template, media)

    status_text = f"Продолжаю: <b>{session_name}</b>" if session_id else f"Новый диалог: <i>{session_name}</i>"
    if template:
        status_text += f"\nШаблон: <code>{template}</code>"
    elif auto_mode != effective_mode:
        status_text += f"\nАвторежим: <code>{auto_mode}</code>"

    status_msg = await message.reply(
        status_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⏳ Запуск...", callback_data="noop")],
        ]),
    )

    if session_id:
        set_session_active(owner_id, session_id)

    async def on_result(result_text: str, returned_session_id: str | None):
        target_session_id = returned_session_id or session_id
        try:
            if returned_session_id:
                user_focus[message.chat.id] = returned_session_id
                if not session_id:
                    existing = get_session(owner_id, returned_session_id)
                    if not existing:
                        create_session(owner_id, returned_session_id, session_name)
                session_reply_mode.setdefault(returned_session_id, auto_mode)
                _refresh_session_name(owner_id, returned_session_id, text, result_text or "")
                set_session_idle(owner_id, returned_session_id, summary=(result_text or "")[:200])
            elif session_id:
                session_reply_mode.setdefault(session_id, auto_mode)
                _refresh_session_name(owner_id, session_id, text, result_text or "")
                set_session_idle(owner_id, session_id, summary=(result_text or "")[:200])

            save_message(owner_id, "assistant", result_text or "", target_session_id)

            try:
                await status_msg.delete()
            except TelegramBadRequest:
                pass

            if result_text:
                html = md_to_telegram_html(result_text)
                chunks = split_message(html)
                for i, chunk in enumerate(chunks):
                    try:
                        await bot.send_message(message.chat.id, chunk, parse_mode=ParseMode.HTML)
                    except TelegramBadRequest as exc:
                        logger.warning("HTML parse failed, sending plain text: %s", exc)
                        await bot.send_message(message.chat.id, result_text[:4000] if i == 0 else chunk[:4000])
                        break

            await bot.send_message(
                message.chat.id,
                "•••",
                reply_markup=build_result_keyboard(target_session_id),
            )
        finally:
            for path in media.cleanup_paths:
                try:
                    Path(path).unlink(missing_ok=True)
                except OSError:
                    pass

    result = await run_qwen(
        prompt=prompt,
        session_id=session_id,
        on_result=on_result,
        queue_max=MESSAGE_QUEUE_MAX,
        label=session_name,
        owner_id=owner_id,
    )

    if result["status"] == "queue_full":
        for path in media.cleanup_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                pass
        await status_msg.edit_text("Очередь заполнена. Дождись завершения текущих задач.")
        return

    save_message(owner_id, "user", text, session_id)
    learn_preferences_from_text(owner_id, text)
    record_request(owner_id)

    request_id = result.get("request_id")
    if result["status"] == "queued":
        try:
            await status_msg.edit_text(
                f"Qwen занят. Сообщение в очереди ({result['position']}/{MESSAGE_QUEUE_MAX}).\nID задачи: <code>{request_id}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=build_task_keyboard(request_id),
            )
        except TelegramBadRequest:
            pass
    else:
        try:
            await status_msg.edit_text(
                f"{status_text}\n\nID задачи: <code>{request_id}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=build_task_keyboard(request_id),
            )
        except TelegramBadRequest:
            pass


# ==================== Helpers ====================

async def _send_status(chat_id: int, edit_message=None):
    owner_id = _owner_id(chat_id)
    if not owner_id:
        return

    sessions = get_active_sessions(owner_id)
    devices = get_pc_devices(owner_id)
    active = [s for s in sessions if s["status"] == "active"]
    idle = [s for s in sessions if s["status"] == "idle"]
    tasks = get_task_snapshot(owner_id)
    running = [task for task in tasks if task["status"] == "running"]
    queued = [task for task in tasks if task["status"] == "queued"]

    focus_id = user_focus.get(chat_id)
    focus_session = get_session(owner_id, focus_id) if focus_id and focus_id != "__force_new__" else None
    remaining, used = quota_remaining(owner_id, USER_REQUEST_LIMIT, USER_REQUEST_WINDOW_HOURS)

    text = f"<b>Статус</b>\n\n"
    text += f"Профиль: <code>{escape(owner_id)}</code>\n"
    text += f"Активных диалогов: {len(active)}\n"
    text += f"Ожидают: {len(idle)}\n"
    text += f"ПК устройств: {len(devices)}\n"
    text += f"В работе: {len(running)}\n"
    text += f"В очереди: {len(queued)}\n"
    text += f"Лимит: {used}/{USER_REQUEST_LIMIT} за {USER_REQUEST_WINDOW_HOURS}ч\n"
    text += f"Осталось: {remaining}\n\n"
    text += f"Текущий: <b>{focus_session['name']}</b>\n" if focus_session else "Текущий: <i>не выбран</i>\n"
    text += f"Голос: {'on (Groq)' if config.GROQ_API_KEY else 'off'}\n"
    text += f"Занят: {'да' if is_busy() else 'нет'}"

    if running:
        text += "\n\n<b>Выполняется</b>\n"
        for task in running[:4]:
            text += f"• <code>{task['request_id']}</code> {md_to_telegram_html(task['label'][:40] or 'без названия')}\n"
    if queued:
        text += "\n<b>Очередь</b>\n"
        for task in queued[:4]:
            text += f"• <code>{task['request_id']}</code> {md_to_telegram_html(task['label'][:40] or 'без названия')}\n"

    if edit_message:
        await edit_message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=build_main_menu())
    else:
        await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=build_main_menu())


async def _run_assistant_text_action(message: Message, fn, *args):
    try:
        result = await fn(*args)
        await message.reply(md_to_telegram_html(result), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
    except AssistantActionError as exc:
        await message.reply(f"Ошибка: {md_to_telegram_html(str(exc))}", parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())


async def _run_assistant_json_action(message: Message, title: str, fn):
    try:
        payload = await fn()
        await message.reply(format_json_block(title, payload), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
    except AssistantActionError as exc:
        await message.reply(f"Ошибка: {md_to_telegram_html(str(exc))}", parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())


def _command_args(message: Message) -> str:
    parts = (message.text or "").split(maxsplit=1)
    return parts[1].strip() if len(parts) > 1 else ""


def _help_text() -> str:
    return (
        "<b>Справка</b>\n\n"
        "Основной режим: отправляй текст, фото, голосовое, кружок, видео или файл с изображением.\n\n"
        "Меню сделано под кнопки, но команды тоже работают: /menu, /new, /sessions, /tasks, /status, /setup, /pc.\n\n"
        "В этой сборке добавлены многопользовательский вход по паролю, отдельные сессии по профилям, лимиты 500 запросов за 24 часа и relay-подключение ПК через отдельный python-клиент."
    )


def _mode_text(current_mode: str) -> str:
    labels = {
        "normal": "Обычный",
        "brief": "Коротко",
        "deep": "Подробно",
        "plan": "План",
        "code": "Код",
    }
    return (
        "<b>Режим ответа</b>\n\n"
        f"Сейчас: <b>{labels.get(current_mode, current_mode)}</b>\n\n"
        "Если выбран текущий диалог, режим закрепляется за ним. Иначе режим применяется к следующим новым сообщениям в этом чате."
    )


def _get_current_mode(chat_id: int, session_id: str | None = None) -> str:
    if session_id and session_id in session_reply_mode:
        return session_reply_mode[session_id]
    focus_id = user_focus.get(chat_id)
    if focus_id and focus_id != "__force_new__" and focus_id in session_reply_mode:
        return session_reply_mode[focus_id]
    return chat_reply_mode.get(chat_id, DEFAULT_REPLY_MODE)


def _derive_session_name(text: str) -> str:
    cleaned = " ".join(text.replace("\n", " ").split()).strip()
    return cleaned[:50] if cleaned else "Новый диалог"


def _refresh_session_name(owner_id: str, session_id: str, user_text: str, result_text: str):
    session = get_session(owner_id, session_id)
    if not session:
        return
    current_name = session.get("name", "")
    if current_name and current_name != "Новый диалог" and len(current_name) > 10 and not current_name.lower().startswith(("помоги", "сделай", "напиши", "расскажи")):
        return
    candidate = _derive_session_name(user_text)
    if candidate == "Новый диалог" and result_text.strip():
        candidate = _derive_session_name(result_text.splitlines()[0])
    if candidate and candidate != current_name:
        update_session(owner_id, session_id, name=candidate[:50])


async def _send_home(chat_id: int, edit_message=None):
    owner_id = _owner_id(chat_id)
    if not owner_id:
        if edit_message:
            await edit_message.edit_text(_auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
        else:
            await bot.send_message(chat_id, _auth_text(), parse_mode=ParseMode.HTML, reply_markup=build_auth_menu())
        return

    sessions = get_active_sessions(owner_id)
    favorites = get_favorite_sessions(owner_id)
    devices = get_pc_devices(owner_id)
    focus_id = user_focus.get(chat_id)
    focus_session = get_session(owner_id, focus_id) if focus_id and focus_id != "__force_new__" else None
    tasks = get_task_snapshot(owner_id)
    running = sum(1 for task in tasks if task["status"] == "running")
    queued = sum(1 for task in tasks if task["status"] == "queued")
    remaining, used = quota_remaining(owner_id, USER_REQUEST_LIMIT, USER_REQUEST_WINDOW_HOURS)

    text = "<b>QwenClaw</b>\n\n"
    text += f"Профиль: <code>{escape(owner_id)}</code>\n"
    text += f"Текущий диалог: <b>{focus_session['name']}</b>\n" if focus_session else "Текущий диалог: <i>не выбран</i>\n"
    text += f"Режим: {_get_current_mode(chat_id, focus_id) if focus_id and focus_id != '__force_new__' else _get_current_mode(chat_id)}\n"
    text += f"Избранных: {len(favorites)}\n"
    text += f"Диалогов: {len(sessions)}\n"
    text += f"ПК: {len(devices)}\n"
    text += f"Задач: {running} в работе, {queued} в очереди\n"
    text += f"Лимит: {used}/{USER_REQUEST_LIMIT} за {USER_REQUEST_WINDOW_HOURS}ч\n"
    text += f"Осталось: {remaining}"

    if edit_message:
        await edit_message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=build_main_menu())
    else:
        await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=build_main_menu())


async def _send_current_session(chat_id: int, edit_message=None):
    owner_id = _owner_id(chat_id)
    if not owner_id:
        return
    focus_id = user_focus.get(chat_id)
    if not focus_id or focus_id == "__force_new__":
        text = "<b>Текущий диалог</b>\n\nНе выбран. Нажми «Новый диалог» или открой список диалогов."
        markup = build_main_menu()
    else:
        session = get_session(owner_id, focus_id)
        if not session or session["status"] == "done":
            text = "<b>Текущий диалог</b>\n\nТекущий диалог уже закрыт."
            markup = build_main_menu()
        else:
            created = datetime.fromisoformat(session["created_at"]).strftime("%d.%m %H:%M")
            summary = session.get("summary", "") or "Без краткого описания"
            favorite = "да" if session.get("favorite") else "нет"
            text = (
                f"<b>{session['name']}</b>\n\n"
                f"Статус: {session['status']}\n"
                f"Создан: {created}\n\n"
                f"Режим: {_get_current_mode(chat_id, focus_id)}\n\n"
                f"Избранное: {favorite}\n\n"
                f"<i>{md_to_telegram_html(summary[:200])}</i>\n\n"
                "Просто отправь следующее сообщение, и бот продолжит этот диалог."
            )
            markup = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🎛 Режим", callback_data="reply_mode")],
                [InlineKeyboardButton(text="⭐ Переключить избранное", callback_data=f"favorite:{focus_id}")],
                [InlineKeyboardButton(text="📋 Все диалоги", callback_data="sessions:0")],
                [InlineKeyboardButton(text="🏠 Меню", callback_data="menu")],
            ])

    if edit_message:
        await edit_message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=markup)
    else:
        await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=markup)


async def _maybe_handle_pc_chat(message: Message, owner_id: str, text: str) -> bool:
    device_id = pc_chat_device.get(message.chat.id)
    if not device_id:
        return False

    if text.strip().lower() in {"выйти из чата с пк", "выход из пк", "стоп пк"}:
        pc_chat_device.pop(message.chat.id, None)
        await message.reply("Режим чата с ПК выключен.", reply_markup=build_pc_menu(owner_id, pc_selected_device.get(message.chat.id)))
        return True

    device = get_pc_device(owner_id, device_id)
    if not device:
        pc_chat_device.pop(message.chat.id, None)
        await message.reply("Выбранный ПК уже недоступен.", reply_markup=build_pc_menu(owner_id, pc_selected_device.get(message.chat.id)))
        return True

    save_message(owner_id, "user", text, None)
    learn_preferences_from_text(owner_id, text)
    learn_device_profile_from_text(owner_id, device_id, text)
    lowered = text.strip().lower()
    if any(token in lowered for token in {"скинь камеру", "сделай снимок камеры", "покажи камеру", "camera snapshot", "send camera"}):
        command = queue_pc_camera(owner_id, device_id, text, describe=False)
        title = "Снимок камеры запрошен"
    elif any(token in lowered for token in {"опиши камеру", "что видно на камере", "что ты видишь с камеры", "describe camera", "what do you see on camera"}):
        command = queue_pc_camera(owner_id, device_id, text, describe=True)
        title = "Описание камеры запрошено"
    else:
        clarification = build_pc_clarification_request(text)
        if clarification:
            save_message(owner_id, "assistant", clarification, None)
            await message.reply(
                clarification,
                reply_markup=build_pc_chat_keyboard(device_id),
            )
            return True
        command = queue_pc_chat(owner_id, device_id, text)
        title = "Задача отправлена на ПК"
    await message.reply(
        f"<b>{title}</b>\n\n"
        f"Устройство: <b>{md_to_telegram_html(device.get('name') or device_id)}</b>\n"
        f"Команда: <code>{command['command_id']}</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_chat_keyboard(device_id),
    )
    return True


async def _maybe_handle_local_assistant(message: Message, text: str) -> bool:
    normalized = text.strip().lower()
    try:
        if normalized in {"статус телефона", "телефон статус", "phone status"}:
            await message.reply(await phone_status(), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
            return True
        if normalized in {"батарея", "заряд"}:
            await message.reply(format_json_block("Батарея", await battery_status()), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
            return True
        if normalized in {"локация", "геолокация", "местоположение", "где ты"}:
            await message.reply(format_json_block("Локация", await location_info()), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
            return True
        if normalized in {"включи фонарик", "фонарик включи", "torch on"}:
            await message.reply(await torch_set(True), reply_markup=build_assistant_menu())
            return True
        if normalized in {"выключи фонарик", "фонарик выключи", "torch off"}:
            await message.reply(await torch_set(False), reply_markup=build_assistant_menu())
            return True
        if normalized in {"включи wifi", "включи wi-fi", "wifi on", "включи вайфай"}:
            await message.reply(await wifi_set(True), reply_markup=build_assistant_menu())
            return True
        if normalized in {"выключи wifi", "выключи wi-fi", "wifi off", "выключи вайфай"}:
            await message.reply(await wifi_set(False), reply_markup=build_assistant_menu())
            return True
        if normalized.startswith("скажи "):
            await message.reply(md_to_telegram_html(await speak_text(text[6:])), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
            return True
        if normalized.startswith("открой "):
            await message.reply(md_to_telegram_html(await open_url(text[7:])), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
            return True
        if normalized.startswith("скопируй "):
            await message.reply(md_to_telegram_html(await clipboard_set(text[9:])), parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
            return True
    except AssistantActionError as exc:
        await message.reply(f"Ошибка: {md_to_telegram_html(str(exc))}", parse_mode=ParseMode.HTML, reply_markup=build_assistant_menu())
        return True
    return False


async def _send_tasks_panel(chat_id: int, edit_message=None):
    owner_id = _owner_id(chat_id)
    if not owner_id:
        return
    tasks = get_task_snapshot(owner_id)
    if not tasks:
        text = "<b>Задачи</b>\n\nНет активных или ожидающих задач."
        markup = build_main_menu()
    else:
        lines = ["<b>Задачи</b>", ""]
        buttons = []
        for task in tasks[:8]:
            label = md_to_telegram_html(task["label"][:36] or "без названия")
            status = "в работе" if task["status"] == "running" else "ждёт"
            lines.append(f"<code>{task['request_id']}</code> [{status}] {label}")
            buttons.append([InlineKeyboardButton(text=f"⏹ {task['request_id']} {status}", callback_data=f"cancel_task:{task['request_id']}")])
        buttons.append([InlineKeyboardButton(text="🏠 Меню", callback_data="menu")])
        text = "\n".join(lines)
        markup = InlineKeyboardMarkup(inline_keyboard=buttons)

    if edit_message:
        await edit_message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=markup)
    else:
        await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=markup)


async def _notify_pc_connected(device: dict):
    owner_id = device.get("owner_id")
    chat_id = device.get("chat_id")
    if not owner_id or not chat_id:
        return
    selected_device_id = device["device_id"]
    pc_selected_device[chat_id] = selected_device_id
    await bot.send_message(
        chat_id,
        f"<b>Устройство подключено</b>\n\n"
        f"Имя: <b>{md_to_telegram_html(device.get('name') or selected_device_id)}</b>\n"
        f"ID: <code>{selected_device_id}</code>\n"
        f"Платформа: {md_to_telegram_html(device.get('platform') or '—')}",
        parse_mode=ParseMode.HTML,
        reply_markup=build_pc_menu(owner_id, selected_device_id),
    )


async def _notify_pc_result(device: dict, command: dict):
    owner_id = device.get("owner_id")
    chat_id = device.get("chat_id")
    if not owner_id or not chat_id:
        return
    ok = command.get("status") == "done"
    header = "✅ ПК выполнил задачу" if ok else "❌ ПК вернул ошибку"
    body = command.get("result_text") if ok else command.get("error_text") or command.get("result_text")
    body = body or "Пустой ответ от клиента."
    save_message(owner_id, "assistant", body, None)
    attachment_path = (command.get("attachment_path") or "").strip()
    attachment_kind = (command.get("attachment_kind") or "").strip().lower()
    if attachment_path:
        file_path = Path(attachment_path)
        if file_path.exists():
            caption = (
                f"{header}\n"
                f"Устройство: {device.get('name') or device['device_id']}\n"
                f"Команда: {command['command_id']}"
            )
            try:
                if attachment_kind == "image":
                    await bot.send_photo(chat_id, FSInputFile(str(file_path)), caption=caption)
                else:
                    await bot.send_document(chat_id, FSInputFile(str(file_path)), caption=caption)
            except TelegramBadRequest as exc:
                logger.warning("Failed to send PC attachment: %s", exc)
    html = (
        f"<b>{header}</b>\n\n"
        f"Устройство: <b>{md_to_telegram_html(device.get('name') or device['device_id'])}</b>\n"
        f"Команда: <code>{command['command_id']}</code>\n\n"
        f"{md_to_telegram_html(body)}"
    )
    for chunk in split_message(html):
        await bot.send_message(chat_id, chunk, parse_mode=ParseMode.HTML, reply_markup=build_pc_chat_keyboard(device["device_id"]))


async def _notify_pc_progress(device: dict, progress: dict):
    chat_id = device.get("chat_id")
    if not chat_id:
        return
    command_id = str(progress.get("command_id") or "")
    stage_raw = str(progress.get("stage") or "")
    message_raw = str(progress.get("message") or "")
    now = datetime.utcnow()
    if command_id:
        prev = pc_progress_cache.get(command_id)
        if prev:
            prev_stage, prev_message, prev_ts = prev
            if prev_stage == stage_raw and prev_message == message_raw and (now - prev_ts).total_seconds() < 8:
                return
        pc_progress_cache[command_id] = (stage_raw, message_raw, now)
    stage = md_to_telegram_html(progress.get("stage") or "progress")
    message = md_to_telegram_html(progress.get("message") or "")
    text = (
        f"<b>⏳ ПК выполняет миссию</b>\n\n"
        f"Устройство: <b>{md_to_telegram_html(device.get('name') or device['device_id'])}</b>\n"
        f"Команда: <code>{command_id}</code>\n"
        f"Этап: <b>{stage}</b>\n"
    )
    if message:
        text += f"\n{message}"
    await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=build_pc_chat_keyboard(device["device_id"]))


async def _send_favorites(chat_id: int, edit_message=None):
    owner_id = _owner_id(chat_id)
    if not owner_id:
        return
    sessions = get_favorite_sessions(owner_id)
    if not sessions:
        text = "<b>Избранные</b>\n\nПока пусто."
        markup = build_main_menu()
    else:
        text = "<b>Избранные</b>\n\n" + "\n".join(f"⭐ <b>{md_to_telegram_html(s['name'])}</b>" for s in sessions[:10])
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Все диалоги", callback_data="sessions:0")],
            [InlineKeyboardButton(text="🏠 Меню", callback_data="menu")],
        ])
    if edit_message:
        await edit_message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=markup)
    else:
        await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=markup)


async def _send_search_results(chat_id: int, query: str, edit_message=None):
    owner_id = _owner_id(chat_id)
    if not owner_id:
        return
    results = search_history(owner_id, query)
    if not results:
        text = f"<b>Поиск</b>\n\nПо запросу <code>{escape(query)}</code> ничего не найдено."
        markup = build_main_menu()
    else:
        lines = ["<b>Поиск</b>", "", f"Запрос: <code>{escape(query)}</code>", ""]
        for item in results:
            name = item.get("name") or "Без диалога"
            snippet = escape((item.get("text") or "").replace("\n", " ")[:120])
            lines.append(f"• <b>{escape(name)}</b> — {snippet}")
        text = "\n".join(lines)
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Диалоги", callback_data="sessions:0")],
            [InlineKeyboardButton(text="🏠 Меню", callback_data="menu")],
        ])
    if edit_message:
        await edit_message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=markup)
    else:
        await bot.send_message(chat_id, text, parse_mode=ParseMode.HTML, reply_markup=markup)


async def main():
    await start_runtime(
        bot=bot,
        dp=dp,
        on_connected=_notify_pc_connected,
        on_result=_notify_pc_result,
        on_progress=_notify_pc_progress,
        client_version="1.1",
    )


if __name__ == "__main__":
    asyncio.run(main())
