"""Startup helpers for the Telegram bot runtime."""

from __future__ import annotations

import logging

import config
from aiogram import Bot, Dispatcher
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import BotCommand

from config import LEGACY_ADMIN_CHAT_ID
from db import init_db
from formatting import md_to_telegram_html, split_message
from pc_relay import start_pc_relay
from qwen_runner import run_qwen
from scheduler import run_scheduler

logger = logging.getLogger("bot")


async def setup_bot_commands(bot: Bot):
    commands = [
        BotCommand(command="menu", description="🎛 Панель управления"),
        BotCommand(command="help", description="❓ Справка"),
        BotCommand(command="mode", description="🎛 Режим ответа"),
        BotCommand(command="favorites", description="⭐ Избранные диалоги"),
        BotCommand(command="find", description="🔎 Поиск по истории"),
        BotCommand(command="assistant", description="🧠 Ассистент телефона"),
        BotCommand(command="pc", description="🖥 Управление ПК"),
        BotCommand(command="sessions", description="📋 Список диалогов"),
        BotCommand(command="new", description="➕ Новая сессия"),
        BotCommand(command="status", description="📊 Статус системы"),
        BotCommand(command="tasks", description="⚙️ Задачи и очередь"),
        BotCommand(command="setup", description="⚙️ Настройки"),
    ]
    await bot.set_my_commands(commands)


async def scheduler_send_result(bot: Bot, text: str, description: str):
    if not LEGACY_ADMIN_CHAT_ID:
        return
    header = f"<b>[Scheduled] {md_to_telegram_html(description)}</b>\n\n"
    html = header + md_to_telegram_html(text)
    for chunk in split_message(html):
        try:
            await bot.send_message(LEGACY_ADMIN_CHAT_ID, chunk, parse_mode="HTML")
        except TelegramBadRequest:
            await bot.send_message(LEGACY_ADMIN_CHAT_ID, f"[Scheduled] {description}\n\n{text[:3900]}")


async def start_runtime(
    *,
    bot: Bot,
    dp: Dispatcher,
    on_connected,
    on_result,
    on_progress,
    client_version: str,
):
    init_db()
    await setup_bot_commands(bot)
    from pc_relay import set_event_handlers  # local import to avoid circular import

    set_event_handlers(on_connected=on_connected, on_result=on_result, on_progress=on_progress)
    logger.info("QwenBot starting...")
    logger.info("Legacy admin chat: %s", LEGACY_ADMIN_CHAT_ID or "off")
    logger.info("Password auth: %s", "on" if config.password_auth_enabled() else "off")
    logger.info("Password security mode: %s", config.password_security_mode())
    if config.has_insecure_plaintext_passwords():
        logger.warning("USER_PASSWORDS contains plain-text passwords. This is insecure; prefer pbkdf2_sha256 hashes.")
    logger.info("Voice: %s", "Groq" if config.GROQ_API_KEY else "disabled")
    await start_pc_relay(client_version=client_version)
    import asyncio
    asyncio.create_task(run_scheduler(
        run_qwen_fn=run_qwen,
        send_result_fn=lambda text, description: scheduler_send_result(bot, text, description),
    ))
    logger.info("Scheduler started")
    await dp.start_polling(bot)
