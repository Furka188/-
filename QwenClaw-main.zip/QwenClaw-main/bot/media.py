"""Telegram media preparation for QwenClaw.

Prepares photos, image documents, voice/audio, and video/video_note messages
for Qwen Code CLI with minimal overhead.
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import config
from voice import transcribe_file

logger = logging.getLogger("media")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
AUDIO_EXTS = {".ogg", ".oga", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".webm"}
VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}


@dataclass
class MediaPayload:
    text: str | None
    attachments: list[str] = field(default_factory=list)
    cleanup_paths: list[Path] = field(default_factory=list)
    transcript: str | None = None
    warnings: list[str] = field(default_factory=list)
    media_kind: str = "text"

    @property
    def primary_attachment(self) -> str | None:
        return self.attachments[0] if self.attachments else None


async def prepare_message_media(message, bot) -> MediaPayload:
    """Prepare incoming Telegram message for Qwen CLI.

    Supports text, captions, photos, image documents, voice/audio, video notes,
    and regular videos. For videos, extracts one representative frame and, when
    possible, an audio track for transcription.
    """
    payload = MediaPayload(text=None)
    config.WORK_DIR.mkdir(parents=True, exist_ok=True)

    base_text = (message.text or message.caption or "").strip() or None
    payload.text = base_text

    # Photos
    if getattr(message, "photo", None):
        photo = message.photo[-1]
        image_path = await _download_file(bot, photo.file_id, prefix="image", fallback_ext=".jpg")
        payload.attachments.append(str(image_path))
        payload.cleanup_paths.append(image_path)
        payload.media_kind = "image"

    # Image documents / audio documents / video documents
    document = getattr(message, "document", None)
    if document:
        mime = (document.mime_type or "").lower()
        name = document.file_name or "document"
        ext = Path(name).suffix.lower() or _ext_from_mime(mime) or ".bin"
        doc_path = await _download_file(bot, document.file_id, prefix="document", fallback_ext=ext)
        payload.cleanup_paths.append(doc_path)
        if mime.startswith("image/") or ext in IMAGE_EXTS:
            payload.attachments.append(str(doc_path))
            payload.media_kind = "image"
        elif mime.startswith("audio/") or ext in AUDIO_EXTS:
            payload.media_kind = "audio"
            payload.transcript = await transcribe_file(doc_path)
        elif mime.startswith("video/") or ext in VIDEO_EXTS:
            payload.media_kind = "video"
            await _enrich_video_payload(payload, doc_path)
        else:
            payload.warnings.append(f"Документ {name} не поддерживается для анализа как медиа.")

    # Voice / audio
    voice = getattr(message, "voice", None)
    audio = getattr(message, "audio", None)
    if voice or audio:
        obj = voice or audio
        suffix = ".ogg" if voice else Path(getattr(audio, "file_name", "") or "audio").suffix.lower() or ".mp3"
        audio_path = await _download_file(bot, obj.file_id, prefix="audio", fallback_ext=suffix)
        payload.cleanup_paths.append(audio_path)
        payload.media_kind = "audio"
        payload.transcript = await transcribe_file(audio_path)

    # Video note / regular video
    video_note = getattr(message, "video_note", None)
    video = getattr(message, "video", None)
    if video_note or video:
        obj = video_note or video
        video_path = await _download_file(bot, obj.file_id, prefix="video", fallback_ext=".mp4")
        payload.cleanup_paths.append(video_path)
        payload.media_kind = "video"
        await _enrich_video_payload(payload, video_path)

    payload.text = _compose_final_text(payload.text, payload.transcript, payload.media_kind, bool(payload.attachments), payload.warnings)
    return payload


async def _download_file(bot, file_id: str, *, prefix: str, fallback_ext: str) -> Path:
    file = await bot.get_file(file_id)
    file_path = file.file_path or ""
    ext = Path(file_path).suffix.lower() or fallback_ext
    save_path = config.WORK_DIR / f"{prefix}_{file_id[-8:]}{ext}"
    await bot.download_file(file_path, destination=str(save_path))
    logger.info("Saved media %s", save_path)
    return save_path


async def _enrich_video_payload(payload: MediaPayload, video_path: Path):
    frame_path = await extract_video_frame(video_path)
    if frame_path:
        payload.attachments.append(str(frame_path))
        payload.cleanup_paths.append(frame_path)
    else:
        payload.warnings.append("Не удалось извлечь кадр из видео/кружка.")

    audio_path = await extract_video_audio(video_path)
    if audio_path:
        payload.cleanup_paths.append(audio_path)
        transcript = await transcribe_file(audio_path)
        if transcript:
            payload.transcript = _join_texts([payload.transcript, transcript])
    elif not payload.transcript:
        if not _has_ffmpeg():
            payload.warnings.append("ffmpeg не найден: транскрипция видео недоступна.")


async def extract_video_frame(video_path: Path) -> Path | None:
    if not _has_ffmpeg():
        return None
    out = Path(tempfile.gettempdir()) / f"qwenclaw_frame_{video_path.stem}.jpg"
    cmd = [
        config.FFMPEG_BIN,
        "-y",
        "-i",
        str(video_path),
        "-vf",
        "thumbnail,scale='min(1280,iw)':-2",
        "-frames:v",
        "1",
        str(out),
    ]
    ok = await _run_ffmpeg(cmd)
    return out if ok and out.exists() else None


async def extract_video_audio(video_path: Path) -> Path | None:
    if not _has_ffmpeg():
        return None
    out = Path(tempfile.gettempdir()) / f"qwenclaw_audio_{video_path.stem}.wav"
    cmd = [
        config.FFMPEG_BIN,
        "-y",
        "-i",
        str(video_path),
        "-vn",
        "-ac",
        "1",
        "-ar",
        "16000",
        str(out),
    ]
    ok = await _run_ffmpeg(cmd)
    return out if ok and out.exists() and out.stat().st_size > 44 else None


async def _run_ffmpeg(cmd: list[str]) -> bool:
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.communicate(), timeout=config.MEDIA_TOOL_TIMEOUT)
        return proc.returncode == 0
    except (asyncio.TimeoutError, FileNotFoundError):
        return False


def _has_ffmpeg() -> bool:
    return bool(config.FFMPEG_BIN and shutil.which(config.FFMPEG_BIN))


def _compose_final_text(base_text: str | None, transcript: str | None, media_kind: str, has_attachment: bool, warnings: Iterable[str]) -> str | None:
    pieces: list[str] = []
    if base_text:
        pieces.append(base_text)

    if transcript:
        if media_kind == "video":
            pieces.append(f"Транскрипция аудио из видео/кружка: {transcript}")
        else:
            pieces.append(f"Транскрипция голосового/аудио: {transcript}")

    if has_attachment and not base_text:
        if media_kind == "image":
            pieces.append("Опиши изображение и ответь по нему.")
        elif media_kind == "video":
            pieces.append("Проанализируй видео/кружок по извлечённому кадру и доступной транскрипции.")

    for warning in warnings:
        pieces.append(f"Техническая заметка: {warning}")

    text = _join_texts(pieces)
    return text or None


def _join_texts(parts: Iterable[str | None]) -> str | None:
    clean = [p.strip() for p in parts if p and p.strip()]
    return "\n\n".join(clean) if clean else None


def _ext_from_mime(mime: str) -> str:
    mapping = {
        "image/jpeg": ".jpg",
        "image/png": ".png",
        "image/webp": ".webp",
        "audio/ogg": ".ogg",
        "audio/mpeg": ".mp3",
        "audio/mp4": ".m4a",
        "video/mp4": ".mp4",
        "video/webm": ".webm",
    }
    return mapping.get(mime, "")
