"""Voice and audio transcription via Groq Whisper API."""

from __future__ import annotations

import logging
import asyncio
import tempfile
from pathlib import Path

import httpx

import config

logger = logging.getLogger("voice")

GROQ_API_URL = "https://api.groq.com/openai/v1/audio/transcriptions"


async def transcribe_voice(voice, bot) -> str | None:
    """Backward-compatible Telegram voice/audio transcription helper."""
    if not config.GROQ_API_KEY:
        return None

    tmp_path = None
    try:
        file = await bot.get_file(voice.file_id)
        suffix = Path(file.file_path or "voice.ogg").suffix or ".ogg"
        tmp_path = Path(tempfile.gettempdir()) / f"qwenbot_voice_{voice.file_id}{suffix}"
        await bot.download_file(file.file_path, destination=str(tmp_path))
        return await transcribe_file(tmp_path)
    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


async def transcribe_file(path: str | Path) -> str | None:
    """Transcribe a local audio file via Groq Whisper API.

    Returns:
        text if recognized,
        bracketed user-facing error string when configured but failed,
        None if transcription is not configured.
    """
    if not config.GROQ_API_KEY:
        return None

    file_path = Path(path)
    if not file_path.exists():
        return "[Файл для распознавания не найден]"

    prepared_path = await _prepare_audio_for_stt(file_path)
    cleanup_path = prepared_path if prepared_path != file_path else None
    try:
        response = await _call_groq_transcription(prepared_path, language=config.GROQ_LANGUAGE or None)
        if _should_retry_without_language(response):
            response = await _call_groq_transcription(prepared_path, language=None)

        if response.status_code == 200:
            data = response.json()
            text = _clean_transcript((data.get("text") or "").strip())
            if text:
                logger.info("Transcribed %s: %s...", prepared_path.name, text[:60])
                return text[: config.VOICE_TEXT_MAX_CHARS]
            return "[Пустая запись]"
        if response.status_code == 429:
            logger.warning("Groq rate limit hit")
            return "[Слишком много аудио/голосовых, подожди минуту]"
        if response.status_code == 401:
            logger.error("Invalid Groq API key")
            return "[Неверный GROQ_API_KEY, проверь настройки]"

        logger.error("Groq API error %s: %s", response.status_code, response.text[:200])
        return "[Не удалось распознать аудио, попробуй текстом]"
    except httpx.TimeoutException:
        logger.error("Groq API timeout")
        return "[Таймаут распознавания, попробуй текстом]"
    except Exception as exc:
        logger.error("Voice transcription error: %s", exc, exc_info=True)
        return "[Ошибка распознавания, попробуй текстом]"
    finally:
        if cleanup_path and cleanup_path.exists():
            try:
                cleanup_path.unlink()
            except OSError:
                pass


async def _call_groq_transcription(file_path: Path, *, language: str | None):
    data = {"model": config.GROQ_MODEL}
    if language:
        data["language"] = language
    async with httpx.AsyncClient(timeout=config.GROQ_TIMEOUT) as client:
        with file_path.open("rb") as f:
            return await client.post(
                GROQ_API_URL,
                headers={"Authorization": f"Bearer {config.GROQ_API_KEY}"},
                files={"file": (file_path.name, f, _guess_mime(file_path))},
                data=data,
            )


def _should_retry_without_language(response: httpx.Response) -> bool:
    if not config.GROQ_AUTO_LANGUAGE:
        return False
    if response.status_code != 200:
        return False
    try:
        text = _clean_transcript((response.json().get("text") or "").strip())
    except Exception:
        return False
    return len(text) < 8


async def _prepare_audio_for_stt(file_path: Path) -> Path:
    if not config.FFMPEG_BIN:
        return file_path
    temp_out = Path(tempfile.gettempdir()) / f"qwenclaw_stt_{file_path.stem}.wav"
    cmd = [
        config.FFMPEG_BIN,
        "-y",
        "-i",
        str(file_path),
        "-vn",
        "-ac",
        "1",
        "-ar",
        "16000",
        "-af",
        "highpass=f=120,lowpass=f=3800",
        str(temp_out),
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.communicate(), timeout=config.MEDIA_TOOL_TIMEOUT)
        if proc.returncode == 0 and temp_out.exists() and temp_out.stat().st_size > 44:
            return temp_out
    except Exception:
        pass
    if temp_out.exists():
        try:
            temp_out.unlink()
        except OSError:
            pass
    return file_path


def _clean_transcript(text: str) -> str:
    compact = " ".join(text.replace("\n", " ").split()).strip()
    if not compact:
        return ""
    fillers = {
        "[музыка]",
        "[music]",
        "[шум]",
        "[noise]",
    }
    if compact.lower() in fillers:
        return ""
    return compact


def _guess_mime(path: Path) -> str:
    suffix = path.suffix.lower()
    mapping = {
        ".ogg": "audio/ogg",
        ".oga": "audio/ogg",
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
        ".m4a": "audio/mp4",
        ".aac": "audio/aac",
        ".flac": "audio/flac",
        ".webm": "audio/webm",
    }
    return mapping.get(suffix, "application/octet-stream")
