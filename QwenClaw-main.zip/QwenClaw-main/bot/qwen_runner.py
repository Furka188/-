"""Qwen Code CLI runner with bounded concurrency and task introspection."""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from collections.abc import Callable
from datetime import datetime
from typing import Optional

from config import QWEN_BIN, QWEN_CONCURRENCY, QWEN_TIMEOUT, WORK_DIR

logger = logging.getLogger("qwen_runner")

_semaphore = asyncio.Semaphore(QWEN_CONCURRENCY)
_tasks: dict[str, dict] = {}


def is_busy() -> bool:
    return active_count() > 0


def active_count() -> int:
    return sum(1 for task in _tasks.values() if task["status"] == "running")


def queue_length(owner_id: str | None = None) -> int:
    return sum(
        1
        for task in _tasks.values()
        if task["status"] == "queued" and (owner_id is None or task.get("owner_id") == owner_id)
    )


def get_task_snapshot(owner_id: str | None = None) -> list[dict]:
    tasks = []
    for task in sorted(_tasks.values(), key=lambda item: item["created_at"]):
        if owner_id is not None and task.get("owner_id") != owner_id:
            continue
        tasks.append({
            "request_id": task["request_id"],
            "session_id": task.get("session_id"),
            "label": task.get("label", ""),
            "status": task["status"],
            "created_at": task["created_at"],
            "owner_id": task.get("owner_id"),
        })
    return tasks


def cancel_task(request_id: str, owner_id: str | None = None) -> str | None:
    task = _tasks.get(request_id)
    if not task:
        return None
    if owner_id is not None and task.get("owner_id") != owner_id:
        return None
    state = task["status"]
    task["task"].cancel()
    return state


async def run_qwen(
    prompt: str,
    session_id: Optional[str] = None,
    on_result: Optional[Callable] = None,
    max_turns: Optional[int] = None,
    queue_max: int = 5,
    label: str = "",
    owner_id: str | None = None,
) -> dict:
    queued_now = queue_length(owner_id)
    if queued_now >= queue_max:
        return {"status": "queue_full"}

    request_id = uuid.uuid4().hex[:8]
    initial_status = "started" if active_count() < QWEN_CONCURRENCY and queued_now == 0 else "queued"

    task_meta = {
        "request_id": request_id,
        "prompt": prompt,
        "session_id": session_id,
        "callback": on_result,
        "max_turns": max_turns,
        "label": label,
        "owner_id": owner_id,
        "status": "queued",
        "created_at": datetime.utcnow().isoformat(),
        "proc": None,
        "task": None,
    }
    _tasks[request_id] = task_meta
    task_meta["task"] = asyncio.create_task(_process_task(request_id))

    result = {"status": initial_status, "request_id": request_id}
    if initial_status == "queued":
        result["position"] = queued_now + 1
    return result


async def _process_task(request_id: str):
    task_meta = _tasks.get(request_id)
    if not task_meta:
        return

    try:
        async with _semaphore:
            if request_id not in _tasks:
                return

            task_meta["status"] = "running"
            result = await _execute_qwen(
                request_id=request_id,
                prompt=task_meta["prompt"],
                session_id=task_meta["session_id"],
                max_turns=task_meta["max_turns"],
            )

            callback = task_meta.get("callback")
            if callback:
                result_text = _normalize_result_text(result)
                new_session_id = result.get("session_id", task_meta["session_id"]) if result else task_meta["session_id"]
                await callback(result_text, new_session_id)

    except asyncio.CancelledError:
        proc = task_meta.get("proc")
        if proc and proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        raise
    except Exception as exc:
        logger.error("Error in _process_task %s: %s", request_id, exc, exc_info=True)
        callback = task_meta.get("callback")
        if callback:
            await callback(f"Error: {exc}", task_meta["session_id"])
    finally:
        _tasks.pop(request_id, None)


async def _execute_qwen(
    prompt: str,
    session_id: Optional[str] = None,
    max_turns: Optional[int] = None,
    request_id: Optional[str] = None,
) -> Optional[dict]:
    del max_turns
    cmd = [QWEN_BIN, "-p", prompt, "--output-format", "json", "--yolo", "--auth-type", "qwen-oauth"]
    if session_id:
        cmd += ["--resume", session_id]

    logger.info("Running request=%s session=%s prompt=%s", request_id, session_id, prompt[:80])

    try:
        WORK_DIR.mkdir(parents=True, exist_ok=True)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(WORK_DIR),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        if request_id in _tasks:
            _tasks[request_id]["proc"] = proc

        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=QWEN_TIMEOUT)

    except asyncio.TimeoutError:
        logger.error("Qwen timed out after %ss", QWEN_TIMEOUT)
        proc = _tasks.get(request_id, {}).get("proc")
        if proc and proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        return {"result": f"[Qwen превысил таймаут {QWEN_TIMEOUT}с. Попробуй сократить запрос или повторить позже.]", "session_id": session_id}
    except asyncio.CancelledError:
        logger.info("Qwen request %s canceled", request_id)
        raise
    except FileNotFoundError:
        logger.error("Qwen binary not found: %s", QWEN_BIN)
        return {"result": f"[Не найден бинарник Qwen: {QWEN_BIN}. Проверь QWEN_BIN и установку CLI.]", "session_id": session_id}

    raw = stdout.decode("utf-8", errors="replace").strip()
    result = _parse_output(raw)
    error = stderr.decode("utf-8", errors="replace").strip()

    if request_id in _tasks:
        _tasks[request_id]["proc"] = None

    if result is None:
        if error:
            logger.error("Qwen stderr: %s", error[:300])
        if raw:
            logger.warning("No JSON in output, wrapping raw stdout as result")
            return {"result": raw, "session_id": session_id}
        return {"result": f"[Qwen не вернул результат. stderr: {error[:500] or 'пусто'}]", "session_id": session_id}

    if error and not result.get("result"):
        result["result"] = f"[Qwen завершился с предупреждением]\n{error[:1000]}"

    logger.info(
        "Qwen done: request=%s turns=%s session=%s",
        request_id,
        result.get("num_turns", "?"),
        result.get("session_id", "?"),
    )
    return result


def _parse_output(raw: str) -> Optional[dict]:
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            for item in reversed(data):
                if isinstance(item, dict) and item.get("type") == "result":
                    return item
    except json.JSONDecodeError:
        pass

    for line in raw.strip().split("\n"):
        line = line.strip()
        if not line or not (line.startswith("{") or line.startswith("[")):
            continue
        try:
            data = json.loads(line)
            if isinstance(data, list):
                for item in reversed(data):
                    if isinstance(item, dict) and item.get("type") == "result":
                        return item
            elif isinstance(data, dict) and "result" in data:
                return data
        except json.JSONDecodeError:
            continue

    return None


def _normalize_result_text(result: Optional[dict]) -> str:
    if not result:
        return "[Qwen не вернул результат.]"
    text = (result.get("result") or "").strip()
    if text:
        return text
    error = (result.get("error") or "").strip()
    if error:
        return f"[Ошибка Qwen]\n{error}"
    return "[Qwen завершился без текста результата.]"
