"""QwenBot configuration — loaded from .env."""

from __future__ import annotations

import os
import hashlib
import hmac
import secrets
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_PATH = PROJECT_ROOT / ".env"
load_dotenv(ENV_PATH)

# Telegram
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
LEGACY_ADMIN_CHAT_ID = int(os.getenv("TELEGRAM_CHAT_ID", "0") or "0")

# Multi-user auth
USER_PASSWORDS_RAW = os.getenv("USER_PASSWORDS", "")

# Qwen CLI
QWEN_BIN = os.getenv("QWEN_BIN", "qwen")
QWEN_MAX_TURNS = int(os.getenv("QWEN_MAX_TURNS", "15"))
QWEN_TIMEOUT = int(os.getenv("QWEN_TIMEOUT", "600"))
QWEN_CONCURRENCY = max(1, int(os.getenv("QWEN_CONCURRENCY", "2")))

# Working directory for Qwen Code
WORK_DIR = Path(os.getenv("QWEN_WORK_DIR", str(PROJECT_ROOT / "workspace")))

# Groq Whisper API (optional, for voice and audio messages)
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "whisper-large-v3")
GROQ_LANGUAGE = os.getenv("GROQ_LANGUAGE", "ru")
GROQ_TIMEOUT = float(os.getenv("GROQ_TIMEOUT", "60"))
GROQ_AUTO_LANGUAGE = os.getenv("GROQ_AUTO_LANGUAGE", "1") == "1"
VOICE_TEXT_MAX_CHARS = int(os.getenv("VOICE_TEXT_MAX_CHARS", "4000"))

# Media preprocessing
FFMPEG_BIN = os.getenv("FFMPEG_BIN", "ffmpeg")
MEDIA_TOOL_TIMEOUT = int(os.getenv("MEDIA_TOOL_TIMEOUT", "30"))

# Database
DB_PATH = PROJECT_ROOT / "data" / "bot.db"

# Limits
MESSAGE_QUEUE_MAX = int(os.getenv("MESSAGE_QUEUE_MAX", "5"))
SESSION_IDLE_TIMEOUT_HOURS = int(os.getenv("SESSION_IDLE_TIMEOUT_HOURS", "48"))
USER_REQUEST_LIMIT = int(os.getenv("USER_REQUEST_LIMIT", "500"))
USER_REQUEST_WINDOW_HOURS = int(os.getenv("USER_REQUEST_WINDOW_HOURS", "24"))

# PC relay
PC_RELAY_ENABLED = os.getenv("PC_RELAY_ENABLED", "1") == "1"
PC_RELAY_HOST = os.getenv("PC_RELAY_HOST", "0.0.0.0")
PC_RELAY_PORT = int(os.getenv("PC_RELAY_PORT", "8765"))
PC_PUBLIC_BASE_URL = (os.getenv("PC_PUBLIC_BASE_URL", "") or "").rstrip("/")


def set_env_var(key: str, value: str):
    """Write or update a variable in .env file and apply to current process."""
    lines: list[str] = []
    found = False

    if ENV_PATH.exists():
        lines = ENV_PATH.read_text(encoding="utf-8").splitlines()
        for i, line in enumerate(lines):
            if line.startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                found = True
                break

    if not found:
        lines.append(f"{key}={value}")

    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.environ[key] = value


def reload_groq_key():
    """Reload GROQ_API_KEY from .env into module-level variable."""
    global GROQ_API_KEY
    load_dotenv(ENV_PATH, override=True)
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")


def parse_user_passwords() -> dict[str, str]:
    """Parse USER_PASSWORDS=user:secret,user2:secret2 into a dict."""
    result: dict[str, str] = {}
    raw = (os.getenv("USER_PASSWORDS", USER_PASSWORDS_RAW) or "").strip()
    if not raw:
        return result

    for chunk in raw.split(","):
        part = chunk.strip()
        if not part or ":" not in part:
            continue
        user_id, password = part.split(":", 1)
        user_id = user_id.strip()
        password = password.strip()
        if user_id and password:
            result[user_id] = password
    return result


def password_auth_enabled() -> bool:
    return bool(parse_user_passwords())


def has_insecure_plaintext_passwords() -> bool:
    return any(not (value or "").strip().startswith("pbkdf2_sha256$") for value in parse_user_passwords().values())


def password_security_mode() -> str:
    passwords = parse_user_passwords()
    if not passwords:
        return "disabled"
    return "mixed_or_plaintext" if has_insecure_plaintext_passwords() else "hashed_only"


def hash_password(password: str, *, iterations: int = 120_000) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations)
    return f"pbkdf2_sha256${iterations}${salt}${digest.hex()}"


def verify_password(password: str, expected: str) -> bool:
    target = (expected or "").strip()
    if not target:
        return False
    if target.startswith("pbkdf2_sha256$"):
        try:
            _, iterations_raw, salt, digest_hex = target.split("$", 3)
            digest = hashlib.pbkdf2_hmac(
                "sha256",
                password.encode("utf-8"),
                salt.encode("utf-8"),
                int(iterations_raw),
            ).hex()
            return hmac.compare_digest(digest, digest_hex)
        except Exception:
            return False
    return hmac.compare_digest(password, target)


def resolve_user_by_password(password: str) -> str | None:
    candidate = (password or "").strip()
    if not candidate:
        return None
    for user_id, expected in parse_user_passwords().items():
        if verify_password(candidate, expected):
            return user_id
    return None
