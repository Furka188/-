"""Prompt and context builders for PC tasks."""

from __future__ import annotations

import textwrap

from config import PC_PUBLIC_BASE_URL
from db import get_recent_history, get_user_preferences
from pc_supervisor import format_pc_mission_contract
from pc_task_router import route_pc_task
from user_profile import get_device_profile_summary, get_profile_summary


def build_pc_clarification_request(prompt: str) -> str:
    text = " ".join((prompt or "").split()).strip()
    if not text:
        return "Уточни задачу для ПК: что именно нужно открыть, найти или сделать?"

    lowered = text.lower()
    routed = route_pc_task(text)
    if routed.task_type in {"inspect"}:
        return ""

    vague_markers = {
        "что-нибудь", "что нибудь", "что то", "что-то", "как-нибудь", "как нибудь",
        "нормально", "хорошо", "прикольное", "интересное", "любое", "сам реши",
    }
    action_only_markers = {
        "открой", "зайди", "найди", "включи", "сделай", "запусти", "переключи",
        "посмотри", "покажи", "выбери",
    }
    has_vague = any(marker in lowered for marker in vague_markers)
    words = [word for word in lowered.replace(",", " ").replace(".", " ").split() if word]
    if len(words) <= 2 and any(word in action_only_markers for word in words):
        has_vague = True
    if not has_vague and routed.task_type == "browser":
        browser_targets = ("youtube", "ютуб", "chrome", "брауз", "сайт", "вклад", "url", "ссылка", "google", "гугл")
        content_targets = ("видео", "ролик", "музык", "плейлист", "канал", "поиск", "запрос")
        if not any(token in lowered for token in browser_targets + content_targets):
            has_vague = True
    if not has_vague and routed.task_type == "desktop":
        desktop_targets = ("roblox", "chrome", "брауз", "окно", "прилож", "проводник", "explorer", "finder", "рабочий стол")
        if not any(token in lowered for token in desktop_targets):
            has_vague = True
    if not has_vague and routed.task_type == "general":
        broad_verbs = sum(1 for word in words if word in action_only_markers)
        specific_nouns = ("youtube", "ютуб", "roblox", "chrome", "брауз", "файл", "папк", "сайт", "окно", "видео", "музык", "игр", "камера", "экран")
        if broad_verbs and not any(token in lowered for token in specific_nouns):
            has_vague = True

    if not has_vague:
        return ""

    if routed.task_type == "browser":
        return (
            "Уточни browser-задачу: какой сайт или сервис открыть, что именно найти или включить, "
            "и по какому критерию выбрать результат."
        )
    if routed.task_type == "desktop":
        return (
            "Уточни desktop-задачу: с каким приложением или окном работать и какой точный результат нужен "
            "(открыть, свернуть, переключить, закрыть, настроить)."
        )
    if routed.task_type == "shell":
        return "Уточни shell-задачу: какую именно команду, файл или действие нужно выполнить на ПК?"
    return (
        "Уточни задачу для ПК: что именно нужно сделать, в каком приложении или сайте, "
        "и какой результат считать успешным."
    )


def build_pc_task_prompt(owner_id: str, prompt: str, device_id: str = "") -> str:
    routed = route_pc_task(prompt)
    context = build_preference_context(owner_id, routed.task_type)
    profile = get_profile_summary(owner_id, limit=4)
    device_profile = get_device_profile_summary(owner_id, device_id, limit=3) if device_id else ""
    contract = format_pc_mission_contract(prompt)
    instruction = build_pc_instruction_block(routed.task_type)
    chunks = [
        instruction,
        f"Тип задачи: {routed.task_type}",
        f"Маршрут выполнения: {routed.guidance}",
        contract,
        build_pc_quality_rules(routed.task_type),
        "Формат ответа: План:, Действия:, Проверка:, Итог:.",
    ]
    if context:
        chunks.append("Недавний контекст:\n" + context)
    if profile:
        chunks.append("Профиль пользователя:\n" + profile)
    if device_profile:
        chunks.append("Профиль для этого ПК:\n" + device_profile)
    chunks.append("Задача пользователя:\n" + prompt.strip())
    return "\n\n".join(chunks)


def build_pc_instruction_block(task_type: str) -> str:
    variants = {
        "browser": textwrap.dedent(
            """\
            Browser mission:
            1. Сначала определи состояние браузера и доступность browser/CDP слоя.
            2. Предпочитай URL, вкладки, browser-status и browser-tabs вместо OCR и координат.
            3. Если browser-layer недоступен, переходи к хоткеям и только затем к GUI fallback.
            4. После важного шага подтверждай, что открыта нужная страница, поиск или видео.
            """
        ).strip(),
        "desktop": textwrap.dedent(
            """\
            Desktop mission:
            1. Сначала пойми, какое окно активно и что мешает выполнению задачи.
            2. Предпочитай системные хоткеи, window management и inspect.
            3. Избегай лишних кликов по экрану, пока состояние окна не подтверждено.
            4. После каждого шага проверяй, что нужное окно или приложение действительно в фокусе.
            """
        ).strip(),
        "shell": textwrap.dedent(
            """\
            Shell mission:
            1. Предпочитай терминал и команды вместо GUI.
            2. Следи за exit code, stdout и stderr.
            3. Если команда не сработала, корректируй команду, а не повторяй её без изменений.
            4. В конце дай короткий итог и способ проверки.
            """
        ).strip(),
        "inspect": textwrap.dedent(
            """\
            Inspect mission:
            1. Собери максимально полезное структурированное состояние экрана.
            2. Определи активное окно, URL, видимый текст, приложения и препятствия.
            3. Не пытайся выполнять задачу, если запрос был именно на осмотр.
            """
        ).strip(),
        "general": textwrap.dedent(
            """\
            General PC mission:
            1. Сначала пойми текущую обстановку на ПК.
            2. Выбери самый надёжный способ: browser layer, shell, hotkeys, GUI fallback.
            3. Выполняй шаги только с проверкой результата.
            4. Не повторяй один и тот же сбойный шаг без новой тактики.
            5. Если задача сформулирована достаточно чётко, доводи её до результата.
            """
        ).strip(),
    }
    return variants.get(task_type, variants["general"])


def build_pc_quality_rules(task_type: str) -> str:
    base = (
        "Правила качества: предпочитай детерминированные действия; проверяй URL, активное окно, экран, OCR или вывод команд; "
        "не выдавай предположение за факт."
    )
    extras = {
        "browser": "Для browser-задач главным доказательством успеха считаются URL, вкладка, заголовок страницы и состояние браузера.",
        "desktop": "Для desktop-задач главным доказательством успеха считаются активное окно, изменение интерфейса и отсутствие прежнего препятствия.",
        "shell": "Для shell-задач главным доказательством успеха считаются exit code и содержимое stdout/stderr.",
        "inspect": "Для inspect-задач успех означает качественное описание состояния, а не выполнение действий.",
        "general": "Если путь неочевиден, начни с inspect и выбери более устойчивый маршрут.",
    }
    return base + " " + extras.get(task_type, extras["general"])


def build_preference_context(owner_id: str, task_type: str) -> str:
    if task_type not in {"browser", "desktop"}:
        return ""
    stored = get_user_preferences(owner_id, limit=4)
    rows = get_recent_history(owner_id, role="user", limit=8)
    seen: set[str] = set()
    snippets: list[str] = []
    for item in stored:
        label = shrink_text(f"[{item['category']}] {item['value']}", 80)
        norm = label.lower()
        if norm in seen:
            continue
        seen.add(norm)
        snippets.append(label)
        if len(snippets) >= 2:
            break
    for row in rows:
        text = shrink_text(row.get("text") or "", 110)
        if not text:
            continue
        normalized = " ".join(text.lower().split())
        if normalized in seen:
            continue
        seen.add(normalized)
        snippets.append(text)
        if len(snippets) >= 4:
            break
    if not snippets:
        return ""
    return "\n".join(f"- {item}" for item in snippets)


def shrink_text(text: str, limit: int) -> str:
    text = " ".join((text or "").split()).strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "…"


def build_pc_bootstrap_caption(device: dict, relay_url: str) -> str:
    lines = [
        "<b>Подключение ПК</b>",
        "",
        f"ID устройства: <code>{device['device_id']}</code>",
        "Этот python-клиент привязан только к текущему профилю бота и создаётся заново для конкретного подключения.",
        "",
        "1. Скачай файл ниже на ПК.",
        "2. Запусти: <code>python qwenclaw_pc_*.py</code>",
        "3. На ПК откроется терминал с подтверждением доступа.",
        "4. Введи <code>y</code>, чтобы разрешить подключение, или <code>c</code>, чтобы запретить и удалить клиент.",
        "5. После подключения бот работает как пульт: ты даёшь задачу в Telegram, а ИИ выполняет её на этом ПК.",
        "6. Для полноценного computer-use режима на ПК желательно иметь <code>pyautogui</code>, <code>Pillow</code> и <code>tesseract</code>.",
        "7. Клиент умеет GUI-инструменты и системные хоткеи вроде <code>Win+D</code>, переключения окон и фокуса на браузере.",
        "",
        f"Relay URL: <code>{relay_url}</code>",
    ]
    if not PC_PUBLIC_BASE_URL:
        lines.extend([
            "",
            "Сейчас используется локальный relay URL по умолчанию. Для подключения с другого ПК укажи внешний адрес в <code>PC_PUBLIC_BASE_URL</code>.",
        ])
    return "\n".join(lines)
