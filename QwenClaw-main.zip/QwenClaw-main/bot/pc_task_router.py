"""Routing heuristics for PC tasks."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RoutedTask:
    task_type: str
    guidance: str


def route_pc_task(prompt: str) -> RoutedTask:
    text = (prompt or "").lower()

    if any(token in text for token in ["что на экране", "inspect", "осмотри экран", "что сейчас открыто"]):
        return RoutedTask(
            task_type="inspect",
            guidance="Начни с inspect и верни структурированное состояние экрана, окна, текста и препятствий.",
        )

    if any(token in text for token in ["youtube", "ютуб", "сайт", "браузер", "вкладк", "url", "ссылка"]):
        return RoutedTask(
            task_type="browser",
            guidance=(
                "Это browser-задача. Сначала попробуй открыть или сфокусировать браузер системными средствами, "
                "затем используй address-bar, поиск, URL и inspect. Избегай слепых кликов, пока не проверил состояние."
            ),
        )

    if any(token in text for token in ["окно", "сверни", "разверни", "рабочий стол", "roblox", "приложение", "explorer", "finder"]):
        return RoutedTask(
            task_type="desktop",
            guidance=(
                "Это desktop-задача. Предпочитай window-management хоткеи, active window checks и inspect после каждого шага."
            ),
        )

    if any(token in text for token in ["git ", "python ", "pip ", "npm ", "терминал", "команд", "shell:", "cmd:", "bash:"]):
        return RoutedTask(
            task_type="shell",
            guidance="Это shell-задача. Предпочитай терминал/команды и проверяй stdout, stderr и код возврата.",
        )

    return RoutedTask(
        task_type="general",
        guidance="Выбери между desktop/browser/shell после начального inspect и действуй по наименее хрупкому пути.",
    )
