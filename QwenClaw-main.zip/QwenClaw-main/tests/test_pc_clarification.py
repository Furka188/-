import sys
import unittest


sys.path.insert(0, "bot")

from pc_prompting import build_pc_clarification_request  # noqa: E402


class PcClarificationTests(unittest.TestCase):
    def test_accepts_specific_browser_request(self):
        text = "Открой YouTube и найди летсплей по Minecraft"
        self.assertEqual(build_pc_clarification_request(text), "")

    def test_requests_clarification_for_vague_browser_request(self):
        text = "Найди что-нибудь интересное и включи"
        self.assertIn("Уточни", build_pc_clarification_request(text))

    def test_requests_clarification_for_short_action_only(self):
        text = "открой"
        self.assertIn("Уточни", build_pc_clarification_request(text))


if __name__ == "__main__":
    unittest.main()
