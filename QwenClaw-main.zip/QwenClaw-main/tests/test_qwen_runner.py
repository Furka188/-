import sys
import types
import unittest


m = types.ModuleType("dotenv")
m.load_dotenv = lambda *args, **kwargs: None
sys.modules.setdefault("dotenv", m)
sys.path.insert(0, "bot")

import qwen_runner  # noqa: E402


class QwenRunnerTests(unittest.TestCase):
    def test_parse_output_from_json_list(self):
        raw = '[{"type":"log","message":"x"},{"type":"result","result":"done","session_id":"abc"}]'
        parsed = qwen_runner._parse_output(raw)
        self.assertEqual(parsed["result"], "done")
        self.assertEqual(parsed["session_id"], "abc")

    def test_normalize_empty_result(self):
        text = qwen_runner._normalize_result_text({"result": ""})
        self.assertIn("без текста результата", text)


if __name__ == "__main__":
    unittest.main()
