import sys
import types
import unittest


m = types.ModuleType("dotenv")
m.load_dotenv = lambda *args, **kwargs: None
sys.modules.setdefault("dotenv", m)
sys.path.insert(0, "bot")

import pc_control  # noqa: E402


class PcClientBuilderTests(unittest.TestCase):
    def test_generated_client_contains_local_task_profiles(self):
        script = pc_control._build_client_script({
            "device_id": "dev1",
            "device_token": "tok",
            "pair_token": "pair",
            "relay_base_url": "http://127.0.0.1:8765",
        })
        self.assertIn("def local_agent_profile(task_type):", script)
        self.assertIn("Локальный browser-профиль", script)
        self.assertIn("Локальный desktop-профиль", script)
        self.assertIn("Локальный shell-профиль", script)
        self.assertIn("Тип локальной миссии:", script)


if __name__ == "__main__":
    unittest.main()
