import sys
import types
import unittest
from unittest.mock import patch


m = types.ModuleType("dotenv")
m.load_dotenv = lambda *args, **kwargs: None
sys.modules.setdefault("dotenv", m)
sys.path.insert(0, "bot")

import chat_prompting  # noqa: E402
import pc_prompting  # noqa: E402


class _Media:
    attachments = []


class PromptingTests(unittest.TestCase):
    def test_chat_system_prompt_varies_by_intent(self):
        code_prompt = chat_prompting.build_chat_system_prompt("code", compact=False)
        explain_prompt = chat_prompting.build_chat_system_prompt("explain", compact=False)
        self.assertIn("технический ассистент", code_prompt)
        self.assertIn("ассистент-объяснитель", explain_prompt)

    def test_pc_instruction_block_varies_by_task_type(self):
        browser_block = pc_prompting.build_pc_instruction_block("browser")
        shell_block = pc_prompting.build_pc_instruction_block("shell")
        self.assertIn("Browser mission", browser_block)
        self.assertIn("Shell mission", shell_block)

    @patch("chat_prompting.get_recent_history", return_value=[])
    @patch("chat_prompting.get_profile_summary", return_value="- [style] brief")
    @patch("chat_prompting.get_user_preferences", return_value=[])
    def test_chat_prompt_uses_compact_wrapper_for_short_requests(self, *_mocks):
        prompt = chat_prompting.build_chat_prompt("u1", "какая погода", "normal", None, _Media())
        self.assertIn("Ты ассистент пользователя в Telegram.", prompt)
        self.assertNotIn("Ты основной ассистент пользователя", prompt)
        self.assertIn("Автоанализ запроса:", prompt)
        self.assertIn("Профиль пользователя:", prompt)
        self.assertIn("Правила ответа:", prompt)
        self.assertIn("Формат:", prompt)

    @patch("chat_prompting.get_recent_history")
    @patch("chat_prompting.get_user_preferences")
    def test_chat_prompt_trims_context_items(self, pref_mock, history_mock):
        pref_mock.return_value = [{"category": "games", "value": "minecraft " * 20}]
        history_mock.return_value = [{"text": "очень длинный текст " * 20}]
        context = chat_prompting.recent_user_context("u1", limit=2, item_chars=40)
        for line in context.splitlines():
            self.assertLessEqual(len(line), 42)

    @patch("pc_prompting.get_recent_history", return_value=[])
    @patch("pc_prompting.get_profile_summary", return_value="- [interest] youtube")
    @patch("pc_prompting.get_user_preferences", return_value=[])
    def test_pc_prompt_skips_preference_context_for_shell_tasks(self, *_mocks):
        prompt = pc_prompting.build_pc_task_prompt("u1", "shell: git status")
        self.assertIn("Тип задачи: shell", prompt)
        self.assertNotIn("Контекст:\n", prompt)
        self.assertIn("Профиль пользователя:", prompt)
        self.assertIn("Формат ответа: План:, Действия:, Проверка:, Итог:.", prompt)
        self.assertIn("Правила качества:", prompt)
        self.assertIn("Shell mission:", prompt)

    @patch("pc_prompting.get_recent_history")
    @patch("pc_prompting.get_user_preferences")
    def test_pc_context_is_short_for_browser_tasks(self, pref_mock, history_mock):
        pref_mock.return_value = [{"category": "content", "value": "youtube letsplay minecraft " * 10}]
        history_mock.return_value = [{"text": "найди длинное видео " * 20}]
        context = pc_prompting.build_preference_context("u1", "browser")
        self.assertLessEqual(len(context.splitlines()), 4)
        for line in context.splitlines():
            self.assertLessEqual(len(line), 112)


if __name__ == "__main__":
    unittest.main()
