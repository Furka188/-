import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch


m = types.ModuleType("dotenv")
m.load_dotenv = lambda *args, **kwargs: None
sys.modules.setdefault("dotenv", m)
sys.path.insert(0, "bot")

import db  # noqa: E402
import user_profile  # noqa: E402


class UserProfileTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "test.sqlite3"
        self.db_patch = patch.object(db, "DB_PATH", self.db_path)
        self.db_patch.start()
        db.init_db()

    def tearDown(self):
        self.db_patch.stop()
        self.tmp.cleanup()

    def test_learn_profile_from_text_persists_facts(self):
        user_profile.learn_profile_from_text("u1", "Люблю Minecraft, YouTube и ответы коротко, без воды")
        facts = db.get_user_profile_facts("u1", limit=10)
        pairs = {(item["aspect"], item["value"]) for item in facts}
        self.assertIn(("interest", "minecraft"), pairs)
        self.assertIn(("interest", "youtube"), pairs)
        self.assertIn(("style", "brief"), pairs)

    def test_profile_summary_is_compact(self):
        db.upsert_user_profile_fact("u1", "interest", "minecraft")
        db.upsert_user_profile_fact("u1", "style", "brief")
        summary = user_profile.get_profile_summary("u1", limit=2)
        self.assertIn("[interest] minecraft", summary)
        self.assertLessEqual(len(summary.splitlines()), 2)


if __name__ == "__main__":
    unittest.main()
