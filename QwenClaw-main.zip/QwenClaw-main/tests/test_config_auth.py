import sys
import types
import unittest


m = types.ModuleType("dotenv")
m.load_dotenv = lambda *args, **kwargs: None
sys.modules.setdefault("dotenv", m)
sys.path.insert(0, "bot")

import config  # noqa: E402


class ConfigAuthTests(unittest.TestCase):
    def test_pbkdf2_password_roundtrip(self):
        hashed = config.hash_password("secret-pass")
        self.assertTrue(config.verify_password("secret-pass", hashed))
        self.assertFalse(config.verify_password("wrong-pass", hashed))

    def test_plain_text_password_still_supported(self):
        self.assertTrue(config.verify_password("plain", "plain"))
        self.assertFalse(config.verify_password("plain", "other"))


if __name__ == "__main__":
    unittest.main()
