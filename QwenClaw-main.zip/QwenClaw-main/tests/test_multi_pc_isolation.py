import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch


m = types.ModuleType("dotenv")
m.load_dotenv = lambda *args, **kwargs: None
sys.modules.setdefault("dotenv", m)
sys.path.insert(0, "bot")

import db  # noqa: E402
import pc_prompting  # noqa: E402
import pc_trace  # noqa: E402
import user_profile  # noqa: E402


class MultiPcIsolationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "test.sqlite3"
        self.root = Path(self.tmp.name) / "project"
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_patch = patch.object(db, "DB_PATH", self.db_path)
        self.trace_patch = patch.object(pc_trace, "TRACE_DIR", self.root / "workspace" / "pc_traces")
        self.db_patch.start()
        self.trace_patch.start()
        db.init_db()

    def tearDown(self):
        self.trace_patch.stop()
        self.db_patch.stop()
        self.tmp.cleanup()

    def test_device_profile_summary_is_scoped_to_device(self):
        user_profile.learn_device_profile_from_text("u1", "pc-a", "люблю youtube и minecraft")
        user_profile.learn_device_profile_from_text("u1", "pc-b", "нужны ответы коротко без воды")
        summary_a = user_profile.get_device_profile_summary("u1", "pc-a", limit=5)
        summary_b = user_profile.get_device_profile_summary("u1", "pc-b", limit=5)
        self.assertIn("youtube", summary_a)
        self.assertNotIn("brief", summary_a)
        self.assertIn("brief", summary_b)
        self.assertNotIn("youtube", summary_b)

    def test_pc_prompt_includes_only_current_device_profile(self):
        db.upsert_user_profile_fact("u1", "interest", "general")
        db.upsert_user_device_profile_fact("u1", "pc-a", "task_preference", "browser_automation")
        prompt = pc_prompting.build_pc_task_prompt("u1", "Открой YouTube", device_id="pc-a")
        self.assertIn("Профиль для этого ПК:", prompt)
        self.assertIn("browser_automation", prompt)

    def test_trace_is_written_under_owner_and_device(self):
        pc_trace.append_trace("cmd1", "queued", {"x": 1}, owner_id="user-1", device_id="pc-1")
        path = self.root / "workspace" / "pc_traces" / "user-1" / "pc-1" / "cmd1.jsonl"
        self.assertTrue(path.exists())
        payload = json.loads(path.read_text(encoding="utf-8").splitlines()[0])
        self.assertEqual(payload["event"], "queued")


if __name__ == "__main__":
    unittest.main()
