import sys
import unittest


sys.path.insert(0, "bot")

from chat_intelligence import analyze_chat_request  # noqa: E402


class ChatIntelligenceTests(unittest.TestCase):
    def test_code_request_switches_to_code_mode(self):
        analysis = analyze_chat_request("Исправь ошибку Python traceback и дай команды")
        self.assertEqual(analysis.intent, "code")
        self.assertEqual(analysis.suggested_mode, "code")

    def test_ambiguous_request_requires_clarification(self):
        analysis = analyze_chat_request("сделай что-нибудь нормально")
        self.assertEqual(analysis.intent, "ambiguous")
        self.assertIn("Уточни", analysis.clarification_request)

    def test_short_request_prefers_brief_mode(self):
        analysis = analyze_chat_request("как дела с wifi")
        self.assertEqual(analysis.suggested_mode, "brief")


if __name__ == "__main__":
    unittest.main()
