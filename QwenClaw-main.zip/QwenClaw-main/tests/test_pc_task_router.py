import sys
import unittest


sys.path.insert(0, "bot")

from pc_task_router import route_pc_task  # noqa: E402


class PcTaskRouterTests(unittest.TestCase):
    def test_routes_browser_task(self):
        routed = route_pc_task("Открой YouTube и найди летсплей по Minecraft")
        self.assertEqual(routed.task_type, "browser")

    def test_routes_shell_task(self):
        routed = route_pc_task("shell: git status")
        self.assertEqual(routed.task_type, "shell")


if __name__ == "__main__":
    unittest.main()
