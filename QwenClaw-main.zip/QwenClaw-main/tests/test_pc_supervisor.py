import sys
import unittest


sys.path.insert(0, "bot")

from pc_supervisor import build_pc_mission_contract, format_pc_mission_contract  # noqa: E402


class PcSupervisorTests(unittest.TestCase):
    def test_browser_contract_prefers_browser_tools(self):
        contract = build_pc_mission_contract("Открой YouTube и найди летсплей")
        self.assertEqual(contract.task_type, "browser")
        self.assertIn("ensure-browser", contract.preferred_tools)
        self.assertTrue(contract.requires_visual_context)

    def test_shell_contract_skips_visual_context(self):
        contract = build_pc_mission_contract("shell: git status")
        self.assertEqual(contract.task_type, "shell")
        self.assertFalse(contract.requires_visual_context)

    def test_formatted_contract_contains_success_checks(self):
        text = format_pc_mission_contract("Открой браузер")
        self.assertIn("Success checks:", text)
        self.assertIn("Preferred tools:", text)


if __name__ == "__main__":
    unittest.main()
